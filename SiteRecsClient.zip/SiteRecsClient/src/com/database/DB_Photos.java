package com.database;
 
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;
 
public class DB_Photos {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_WAKTU,
            COLUMN_TANGGAL,
            COLUMN_NAMA,
            COLUMN_DESKRIPSI,
            COLUMN_URL,
            COLUMN_LATITUDE,
            COLUMN_LONGITUDE,
            COLUMN_ID_TRACKS            
            };
    
    public DB_Photos(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    public int updatePhoto(Model_Photos photo, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_WAKTU, photo.getWaktu());
        values.put(COLUMN_TANGGAL, photo.getTanggal());
        values.put(COLUMN_NAMA, photo.getNama());
        values.put(COLUMN_DESKRIPSI, photo.getDeskripsi());
        values.put(COLUMN_URL, photo.getUrl());
        values.put(COLUMN_LATITUDE, photo.getLat());
        values.put(COLUMN_LONGITUDE, photo.getLong());
        values.put(COLUMN_ID_TRACKS, photo.getIdtracks());
 
        int rowsPengaruh = db.update(TABLE_PHOTO, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deletePhoto(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();        
        db.delete(TABLE_PHOTO, COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }
    
    public void deletePhotoByTracks(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();        
        db.delete(TABLE_PHOTO, COLUMN_ID_TRACKS + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    

    public Model_Photos createPhoto(String waktu, String tanggal, String nama, String desk, String url, String latitude, String longitude, int idPlanToGbr) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_WAKTU, waktu);
        values.put(COLUMN_TANGGAL, tanggal);
        values.put(COLUMN_NAMA, nama);
        values.put(COLUMN_DESKRIPSI, desk);
        values.put(COLUMN_URL, url);
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        values.put(COLUMN_ID_TRACKS, idPlanToGbr);
        long insertId = database.insert(TABLE_PHOTO, null, values); 
        Cursor cursor = database.query(TABLE_PHOTO,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Photos newPhoto = cursorToPhoto(cursor);
        cursor.close();
        return newPhoto;
      }
    
    private Model_Photos cursorToPhoto(Cursor cursor)
    {
        Model_Photos photo = new Model_Photos(0, null, null, null, null, null, 0, 0, 0);
        Log.d("info", "id_tracks= "+cursor.getString(8)+", "+cursor.getString(3)+", "+cursor.getString(6)+", "+cursor.getString(7));
        photo.setId(Integer.valueOf(cursor.getString(0)));
        photo.setWaktu(cursor.getString(1));
        photo.setTanggal(cursor.getString(2));
        photo.setNama(cursor.getString(3));
        photo.setDeskripsi(cursor.getString(4));
        photo.setUrl(cursor.getString(5));
        photo.setLat(cursor.getDouble(6));
        photo.setLong(cursor.getDouble(7));
        photo.setIdtracks(cursor.getInt(8));
        return photo;
    }
    
    public ArrayList<Model_Photos> getAllPhoto() {
        ArrayList<Model_Photos> daftarPhoto = new ArrayList<Model_Photos>();
        Cursor cursor = database.query(TABLE_PHOTO,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Photos photo = cursorToPhoto(cursor);
          daftarPhoto.add(photo);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarPhoto;
    }
    
    public Model_Photos getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_PHOTO, new String[] { 
        				COLUMN_ID,
        				COLUMN_WAKTU,
        				COLUMN_TANGGAL, 
        				COLUMN_NAMA, 
        				COLUMN_DESKRIPSI,
        				COLUMN_URL,
        				COLUMN_LATITUDE,
        				COLUMN_LONGITUDE,
        				COLUMN_ID_TRACKS
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Photos photo = new Model_Photos (id, null, null, null, null, null, 0, 0, 0);
        photo.setId(Integer.valueOf(cursor.getString(0)));
        photo.setWaktu(cursor.getString(1));
        photo.setTanggal(cursor.getString(2));
        photo.setNama(cursor.getString(3));
        photo.setDeskripsi(cursor.getString(4));
        photo.setUrl(cursor.getString(5));
        photo.setLat(cursor.getDouble(6));
        photo.setLong(cursor.getDouble(7));
        photo.setIdtracks(Integer.valueOf(cursor.getString(8)));
        return photo;
	}
    
    public Model_Photos getPhotoByName(String name)
    {		
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
//        ArrayList<Model_Photos> daftarPhoto = new ArrayList<Model_Photos>();
		String selectQuery = 
				"SELECT * FROM "+TABLE_PHOTO+" WHERE "+COLUMN_NAMA+"= '"+ name+"'";
		Log.e("LOG", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
		
		 if (cursor != null)
	            cursor.moveToFirst();
	     
	        Model_Photos photo = new Model_Photos (0, null, null, name, null, null, 0, 0, 0);
	        photo.setId(Integer.valueOf(cursor.getString(0)));
	        photo.setWaktu(cursor.getString(1));
	        photo.setTanggal(cursor.getString(2));
	        photo.setNama(cursor.getString(3));
	        photo.setDeskripsi(cursor.getString(4));
	        photo.setUrl(cursor.getString(5));
	        photo.setLat(cursor.getDouble(6));
	        photo.setLong(cursor.getDouble(7));
	        photo.setIdtracks(Integer.valueOf(cursor.getString(8)));
	        return photo;   
    }

    
    public static final String TABLE_PHOTO = "tb_photo";
    public static final String COLUMN_ID = "id_photo";
    public static final String COLUMN_WAKTU = "waktu_photo";
    public static final String COLUMN_TANGGAL = "tgl_photo";
    public static final String COLUMN_NAMA = "nm_photo";
    public static final String COLUMN_DESKRIPSI = "desk_photo";
    public static final String COLUMN_URL = "url";
    public static final String COLUMN_LATITUDE = "lat_photo";
    public static final String COLUMN_LONGITUDE = "long_photo";
    public static final String COLUMN_ID_TRACKS = "id_tracks";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_PHOTO + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY AUTOINCREMENT, "//
  				+ "[" + COLUMN_WAKTU + "] TIME, "//
  				+ "[" + COLUMN_TANGGAL + "] DATE, "//
  				+ "[" + COLUMN_NAMA + "] CHAR (25), "//
  				+ "[" + COLUMN_DESKRIPSI + "] VARCHAR (50), "//
  				+ "[" + COLUMN_URL + "] VARCHAR (25), "//
  				+ "[" + COLUMN_LATITUDE + "] VARCHAR (20), "//
  				+ "[" + COLUMN_LONGITUDE + "] VARCHAR (20), "//
  				+ "[" + COLUMN_ID_TRACKS + "] INTEGER"//
  				+ ");");

  	}
}