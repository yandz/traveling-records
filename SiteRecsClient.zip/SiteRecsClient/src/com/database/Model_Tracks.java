package com.database;

import android.app.Activity;

public class Model_Tracks extends Activity {

	private int id;
    private String longitude;
    private String latitude;
    private int id_plan;
 
    public Model_Tracks(int id, String latitude, String longitude, int id_plan)
    {
    	super();
    	this.id = id;
    	this.longitude = longitude;
    	this.latitude = latitude;
    	this.id_plan = id_plan; 
    }

    public long getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public String getLatitude() {
        return latitude;
    }
 
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
 
    public String getLongitude() {
        return longitude;
    }
 
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
 
    public long getIdplan() {
        return id_plan;
    }
 
    public void setIdplan(int idplan) {
        this.id_plan = idplan;
    }
 
}