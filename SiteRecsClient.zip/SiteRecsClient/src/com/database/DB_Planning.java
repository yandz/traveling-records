package com.database;
 
import java.util.ArrayList;
import java.util.List;

import com.database.Model_Planning;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_Planning {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    
    public static String[] idPlan;
    public static String[] idTracks;
    
    public static String[] NamaDest;
    public static String[] LatDest;
    public static String[] LongDest;
    
    public static String Nama, LatDestinasi, LongDestinasi;
    
    
    
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_NAME,
            COLUMN_WAKTU,
            COLUMN_TANGGAL,
            COLUMN_JLM_DEST,
            COLUMN_KENDARAAN
            };
    public DB_Planning(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    
//MENDAPATKAN SEMUA DATA PADA TABEL PLANNING (in use)
    public ArrayList<Model_Planning> getAllPlanning() {
        ArrayList<Model_Planning> daftarPlan = new ArrayList<Model_Planning>();
        Cursor cursor = database.query(TABLE_PLANNING,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Planning plan = cursorToPlanning(cursor);
          daftarPlan.add(plan);
          cursor.moveToNext();
        }
//        cursor.close();
        return daftarPlan;
    }
    
//Mendapatkan Semua data Planning yang SUDAH Tracking (In Use)
    public ArrayList<Model_Planning> getAllPlanTracked() {
        ArrayList<Model_Planning> daftarPlan = new ArrayList<Model_Planning>();        
        String selectQuery = 
				 "SELECT * FROM "+ TABLE_PLANNING +" a JOIN "+ DB_Tracks.TABLE_TRACKS +" b ON a.id_plan=b.id_plan GROUP BY a.id_plan";
		Log.e("LOG", selectQuery);
		Cursor cursor = database.rawQuery(selectQuery, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Planning plan = cursorToPlanning(cursor);
          daftarPlan.add(plan);
          cursor.moveToNext();
        }
//        cursor.close();
        return daftarPlan;
    }
    
  //Mendapatkan Semua data Planning yang BELUM Tracking (In Use)
    public ArrayList<Model_Planning> getAllPlanNoTracked() {
        ArrayList<Model_Planning> daftarPlan = new ArrayList<Model_Planning>();        
//        String selectQuery = 
//				 "SELECT * FROM "+ TABLE_PLANNING +" a JOIN "+ DB_Tracks.TABLE_TRACKS +" b ON a.id_plan=b.id_plan GROUP BY a.id_plan";
        String selectQuery ="SELECT * FROM "+TABLE_PLANNING+" WHERE "
        					+"id_plan NOT IN (SELECT id_plan FROM "+DB_Tracks.TABLE_TRACKS+")";
        Log.e("LOG", selectQuery);
		Cursor cursor = database.rawQuery(selectQuery, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Planning plan = cursorToPlanning(cursor);
          daftarPlan.add(plan);
          cursor.moveToNext();
        }
//        cursor.close();
        return daftarPlan;
    }

//Mendapatkan semua data Destinasi yang dipilih PLANNING
    public Cursor getDestinasiFromIdPlanCursor(int id) {
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		String selectQuery = 
				 "SELECT * "
				+"FROM "+ TABLE_PLANNING +" PL, "+ DB_ObjWisata.TABLE_OBJEK +" OB, "+ DB_Destinasi.TABLE_DESTINASI +" DS "
				+"WHERE PL.id_plan = DS.id_plan AND OB.id_obj = DS.id_obj AND PL.id_plan = "+ id;
		Log.e("LOG", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
        	idPlan = new String[cursor.getCount()];
        	LatDest = new String[cursor.getCount()];
        	LongDest = new String[cursor.getCount()];
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	idPlan[i] = cursor.getString(1).toString();
            	LatDest[i] = cursor.getString(9).toString();
            	LongDest[i] = cursor.getString(10).toString();            	
            	Log.d("Objek Wisatanya", cursor.getString(7).toString()+" "+cursor.getString(9).toString()+" "+cursor.getString(10).toString());
            }        
        }
		cursor.close();
//		db.close();
        return cursor;   
    }

//Mendapatkan semua data Destinasi yang dipilih PLANNING
    public List<String> getDestinasiFromIdPlan(int id) {
        List<String> objek = new ArrayList<String>();
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		String selectQuery = 
				 "SELECT * "
				+"FROM "+ TABLE_PLANNING +" PL, "+ DB_ObjWisata.TABLE_OBJEK +" OB, "+ DB_Destinasi.TABLE_DESTINASI +" DS "
				+"WHERE PL.id_plan = DS.id_plan AND OB.id_obj = DS.id_obj AND PL.id_plan = "+ id;
		Log.e("LOG", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
        	idPlan = new String[cursor.getCount()];
        	NamaDest = new String[cursor.getCount()];
        	LatDest = new String[cursor.getCount()];
        	LongDest = new String[cursor.getCount()];
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	idPlan[i] = cursor.getString(1).toString();
            	NamaDest[i] = cursor.getString(7).toString();
            	LatDest[i] = cursor.getString(9).toString();
            	LongDest[i] = cursor.getString(10).toString();
            	

            	Nama = cursor.getString(7).toString();
            	LatDestinasi = cursor.getString(9).toString();
            	LongDestinasi = cursor.getString(10).toString(); 
            	Log.d("Objek Wisatanya", cursor.getString(7).toString()+" "+cursor.getString(9).toString()+" "+cursor.getString(10).toString());
            	
            }        
        }
		cursor.close();
//		db.close();
        return objek;   
    }

//Mendapatkan semua data Destinasi yang dipilih PLANNING
    public String getDestinasiFromIdPlanString(int id) {
		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
		String selectQuery = 
				 "SELECT * "
				+"FROM "+ TABLE_PLANNING +" PL, "+ DB_ObjWisata.TABLE_OBJEK +" OB, "+ DB_Destinasi.TABLE_DESTINASI +" DS "
				+"WHERE PL.id_plan = DS.id_plan AND OB.id_obj = DS.id_obj AND PL.id_plan = "+ id;
		Log.e("LOG", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
		cursor.moveToFirst();
      return cursor.getString(7);   
  }
    
    
//Mendapatkan Semua Data Hasil RECORDING (in use)
      public Cursor getPlayRecordCursor(int id) {
  		SQLiteDatabase db = this.dbHelper.getReadableDatabase();
  		String selectQuery = 
  				"SELECT PL.`nm_plan`, TR.`latitude`, TR.`longitude` " +
  				"FROM "+TABLE_PLANNING+ " PL, "+ DB_Tracks.TABLE_TRACKS +" TR " +
  				"WHERE PL.`id_plan` = TR.`id_plan` AND PL.id_plan = "+ id;
  		Log.e("LOG", selectQuery);
  		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	idPlan = new String[cursor.getCount()];
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	idPlan[i] = cursor.getString(0).toString();
            	
            	Log.d("Records", cursor.getString(1).toString()+" "+cursor.getString(2).toString());
            }        
        }
  		cursor.close();
//  		db.close();
        return cursor;   
    }
      

    //GET ID PLANNING YANG TERAKHIR (in use)
    public String getIdTerakhir(){
    	SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        String selectQuery = "SELECT MAX(id_plan) FROM tb_planning";
        Cursor cursor = db.rawQuery(selectQuery, null);
        cursor.moveToFirst();
		return cursor.getString(0);
    }
    
    //(in use)
    public int updatePlan(Model_Planning plan, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, plan.getNama_trip());
        values.put(COLUMN_WAKTU, plan.getWktPerjalanan());
        values.put(COLUMN_TANGGAL, plan.getTglplan());
        values.put(COLUMN_JLM_DEST, plan.getJml_destinasi());
        values.put(COLUMN_KENDARAAN, plan.getKendaraan());
 
        // updating row
        int rowsPengaruh = db.update(TABLE_PLANNING, values,  COLUMN_ID+ " = ?",
                new String[] { String.valueOf(position) });
//        db.close();
        
        return rowsPengaruh;
    }
    
    //(in use)
    public void deletePlan(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        db.delete(TABLE_PLANNING, COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    
    //in use
    public Model_Planning createPlan(String nama, String waktu, String tanggal, String jml, int kendaraan) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, nama);
        values.put(COLUMN_WAKTU, waktu);
        values.put(COLUMN_TANGGAL, tanggal);
        values.put(COLUMN_JLM_DEST, jml);
        values.put(COLUMN_KENDARAAN, kendaraan);
        long insertId = database.insert(TABLE_PLANNING, null, values); 
        Cursor cursor = database.query(TABLE_PLANNING,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Planning newPlan = cursorToPlanning(cursor);
        cursor.close();
        return newPlan;
    }
    
    private Model_Planning cursorToPlanning(Cursor cursor)
    {
        Model_Planning plan = new Model_Planning(0, null, null, null, null, null);
        Log.v("info", "The getLONG "+cursor.getString(1));
        Log.v("info", "The setLatLng "+cursor.getLong(0)+", "+cursor.getString(2)+", "+cursor.getString(3)+", "+cursor.getString(4));
        plan.setId(Integer.valueOf(cursor.getString(0)));
        plan.setNama_trip(cursor.getString(1));
        plan.setWktPerjalanan(cursor.getString(2));
        plan.setTglplan(cursor.getString(3));
        plan.setJml_destinasi(cursor.getString(4));
        plan.setKendaraan(cursor.getString(5));
        return plan;
    }
    
    public Model_Planning getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_PLANNING, new String[] { 
        				COLUMN_ID,
        				COLUMN_NAME,  
        				COLUMN_WAKTU, 
        				COLUMN_TANGGAL,
        				COLUMN_JLM_DEST, 
        				COLUMN_KENDARAAN 
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Planning contact = new Model_Planning(id, null, null, null, null, null);
        contact.setId(Integer.valueOf(cursor.getString(0)));
        contact.setNama_trip(cursor.getString(1));
        contact.setWktPerjalanan(cursor.getString(2));
        contact.setTglplan(cursor.getString(3));
        contact.setJml_destinasi(cursor.getString(4));
        contact.setKendaraan(cursor.getString(5));
        return contact;
	}


    public static final String TABLE_PLANNING = "tb_planning";
    public static final String COLUMN_ID = "id_plan";
    public static final String COLUMN_NAME = "nm_plan";
    public static final String COLUMN_WAKTU = "waktu_perjalanan";
    public static final String COLUMN_TANGGAL = "tgl_perjalanan";
    public static final String COLUMN_JLM_DEST = "jml_destinasi";
    public static final String COLUMN_KENDARAAN = "jns_kendaraan";
 
      
      public static void createTable(SQLiteDatabase db) {
  		db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_PLANNING + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY AUTOINCREMENT, "//
  				+ "[" + COLUMN_NAME + "] VARCHAR(25), "//
  				+ "[" + COLUMN_WAKTU + "] TIME, "//
  				+ "[" + COLUMN_TANGGAL + "] DATE, "//
  				+ "[" + COLUMN_JLM_DEST + "] INT, "//
  				+ "[" + COLUMN_KENDARAAN + "] INT "//
  				+ ");");

  	}
}