package com.database;

import android.app.Activity;

public class Model_ObjWisata extends Activity {

	private int id_obj;
    private String nama_obj;
    private String kategori;
    private double latitude;
    private double longitude;
    private int id_kabupaten;
    
 
    public Model_ObjWisata(int id, String nama, String kategori, double latitude, double longitude, int id_kabupaten)
    {
		super();
		this.id_obj = id;
		this.nama_obj = nama;
		this.kategori = kategori;
		this.latitude = latitude;
		this.longitude = longitude;
		this.id_kabupaten = id_kabupaten; 
    }
 
    public long getId() {
        return id_obj;
    }
 
    public void setId(int id) {
        this.id_obj = id;
    }

    public String getNama() {
        return nama_obj;
    }
 
       public void setNama(String nama) {
        this.nama_obj= nama;
    }
 
    public String getKategori() {
        return kategori;
    }
 
       public void setKategori(String kategori) {
        this.kategori= kategori;
    }
 
    public double getLat() {
        return latitude;
    }
 
    public void setLat(double latitude) {
        this.latitude = latitude;
    }
 
    public double getLong() {
        return longitude;
    }
 
    public void setLong(double longitude) {
        this.longitude = longitude;
    }
 
    public int getIdKabupaten() {
        return id_kabupaten;
    }
 
    public void setIdKabupaten(int id_kabupaten) {
        this.id_kabupaten = id_kabupaten;
    }
}