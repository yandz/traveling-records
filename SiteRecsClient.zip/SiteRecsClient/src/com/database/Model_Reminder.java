package com.database;

import android.app.Activity;

public class Model_Reminder extends Activity {

	private long id;
    private String tentang;
    private String tanggal;
    private String waktu;
 
    public Model_Reminder(long id, String tentang, String tangal, String waktu)
    {
    	super();
    	this.id = id;
    	this.tentang= tentang;
    	this.tanggal = tangal;
    	this.waktu = waktu; 
    }

    public long getId() {
        return id;
    }
 
    public void setId(long id) {
        this.id = id;
    }
 
    public String getTentang() {
        return tentang;
    }
 
    public void setTentang(String tentang) {
        this.tentang = tentang;
    }
 
    public String getTanggal() {
        return tanggal;
    }
 
    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }
 
    public String getWaktu() {
        return waktu;
    }
 
    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }
 
}