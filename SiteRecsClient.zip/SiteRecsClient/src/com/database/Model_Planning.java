package com.database;

import android.app.Activity;

public class Model_Planning extends Activity {

	private int id;
    private String nama_trip;
    private String waktu_perjalanan;
    private String tgl_plan;
    private String jml_destinasi;
    private String kendaraan;
 
    public Model_Planning(int id, String nama, String wkt_perjalanan, String tanggal, String jumlah, String Kendaraan)
    {
    		super();
    		this.id = id;
    		this.nama_trip = nama;
    		this.waktu_perjalanan = wkt_perjalanan;
    		this.tgl_plan = tanggal;
    		this.jml_destinasi = jumlah;
    		this.kendaraan = Kendaraan;
    }
 
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }
 
    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
 
    /**
     * @return the nama_trip
     */
    public String getNama_trip() {
        return nama_trip;
    }
 
    /**
     * @param nama_trip the nama_trip to set
     */
    public void setNama_trip(String nama) {
        this.nama_trip = nama;
    }
 
    /**
     * @return the tgl_plan
     */
    public String getWktPerjalanan() {
        return waktu_perjalanan;
    }
 
    /**
     * @param tgl_plan the tgl_plan to set
     */
    public void setWktPerjalanan(String waktu) {
        this.waktu_perjalanan = waktu;
    }
 
    /**
     * @return the tgl_plan
     */
    public String getTglplan() {
        return tgl_plan;
    }
 
    /**
     * @param tgl_plan the tgl_plan to set
     */
    public void setTglplan(String tanggal) {
        this.tgl_plan = tanggal;
    }
 
    /**
     * @return the jml_dest
     */
    public String getJml_destinasi() {
        return jml_destinasi;
    }
 
    /**
     * @param jml_destinasi the jml_destinasi to set
     */
    public void setJml_destinasi(String jumlah) {
        this.jml_destinasi = jumlah;
    }
 
    /**
     * @return the jml_dest
     */
    public String getKendaraan() {
        return kendaraan;
    }
 
    /**
     * @param jml_destinasi the jml_destinasi to set
     */
    public void setKendaraan(String kendaraan) {
        this.kendaraan = kendaraan;
    }
 
    @Override
    public String toString()
    {
        return nama_trip +" | "+ tgl_plan + " \n"+ jml_destinasi + " Destinasi"+" | "+ kendaraan;
    }
}