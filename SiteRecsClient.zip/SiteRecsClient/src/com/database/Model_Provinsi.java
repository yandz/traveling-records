package com.database;

import android.app.Activity;

public class Model_Provinsi extends Activity {

	private int id_provinsi;
    private String nm_provinsi;
 
    public Model_Provinsi(int id, String prov)
    {
    	super();
    	this.id_provinsi = id;
    	this.nm_provinsi = prov;
    }
 
    public int getId() {
        return id_provinsi;
    }
 
    public void setId(int id) {
        this.id_provinsi = id;
    }
 
    public String getProvinsi() {
        return nm_provinsi;
    }
 
    public void setProvinsi(String provinsi) {
        this.nm_provinsi= provinsi;
    }
}