package com.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {
	private static final String DB_NAME = "db_clientsiterecs.db";
	private static final int DB_VERSION = 1;

	public DBHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// DB_Alamat.createTable(db);
		DB_Artikel.createTable(db);
		DB_Destinasi.createTable(db);
		DB_Kabupaten.createTable(db);
		DB_ObjWisata.createTable(db);
		DB_Photos.createTable(db);
		DB_Planning.createTable(db);
		DB_Provinsi.createTable(db);
		DB_Tracks.createTable(db);

	}

	public void deleteProvinsi() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(DB_Provinsi.TABLE_PROVINSI, null, null);
		db.close();

		Log.d("SQLite ", "Deleted all user info from sqlite");
	}

	public void deleteKabupaten() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(DB_Kabupaten.TABLE_KABUPATEN, null, null);
		db.close();

		Log.d("SQLite ", "Deleted all user info from sqlite");
	}

	public void deleteObjekWisata() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(DB_ObjWisata.TABLE_OBJEK, null, null);
		db.close();

		Log.d("SQLite ", "Deleted all user info from sqlite");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.w(DBHelper.class.getName(), "Upgrading database from version "
				+ oldVersion + " to " + newVersion
				+ ", which will destroy all old data");
		db.execSQL("DROP TABLE IF EXISTS " + DB_Artikel.TABLE_ARTIKEL);
		db.execSQL("DROP TABLE IF EXISTS " + DB_Destinasi.TABLE_DESTINASI);
		db.execSQL("DROP TABLE IF EXISTS " + DB_Kabupaten.TABLE_KABUPATEN);
		db.execSQL("DROP TABLE IF EXISTS " + DB_ObjWisata.TABLE_OBJEK);
		db.execSQL("DROP TABLE IF EXISTS " + DB_Photos.TABLE_PHOTO);
		db.execSQL("DROP TABLE IF EXISTS " + DB_Planning.TABLE_PLANNING);
		db.execSQL("DROP TABLE IF EXISTS " + DB_Provinsi.TABLE_PROVINSI);
		db.execSQL("DROP TABLE IF EXISTS " + DB_Tracks.TABLE_TRACKS);
		onCreate(db);
	}

}