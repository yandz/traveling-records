package com.database;
 
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_ObjWisata {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    
    public static String[] idObjek;
    
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_NAME,
            COLUMN_KATEGORI,
            COLUMN_LATITUDE,
            COLUMN_LONGITUDE,
            COLUMN_ID_KABUPATEN};
    public DB_ObjWisata(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    
    public List<String> getAllObjById(String id){
        List<String> objek = new ArrayList<String>();      
        String selectQuery = "SELECT  * FROM " + TABLE_OBJEK + " where "+ COLUMN_ID_KABUPATEN +" = "+id;
        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);      
        if (cursor.moveToFirst()) {
        	idObjek = new String[cursor.getCount()];
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	idObjek[i] = cursor.getString(0).toString();
            	objek.add(cursor.getString(1).toString());
            	Log.d("Objek Wisatanya", cursor.getString(1).toString());
            }        
        }
        cursor.close();        // closing connection
        db.close();
        return objek;        // returning kabupaten
    }
    
    public List<String> getAllObj(){
        List<String> objek = new ArrayList<String>();         
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_OBJEK;
        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);      
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
            	objek.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }         
        // closing connection
        cursor.close();
        db.close();
        // returning kabupaten
        return objek;
    }
    
    public List<String> getObjWhere(String id){
        List<String> objek = new ArrayList<String>();         
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_OBJEK + "WHERE " + COLUMN_ID_KABUPATEN + " = ?" +
                new String[] { String.valueOf(id) };
        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);      
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
            	objek.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }         
        // closing connection
        cursor.close();
        db.close();
        // returning kabupaten
        return objek;
    }
    
    public int updateLokasi(Model_ObjWisata objek, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, objek.getNama());
        values.put(COLUMN_KATEGORI, objek.getKategori());
        values.put(COLUMN_LATITUDE, objek.getLat());
        values.put(COLUMN_LONGITUDE, objek.getLong());
        values.put(COLUMN_ID_KABUPATEN, objek.getKategori());
 
        // updating row
        int rowsPengaruh = db.update(TABLE_OBJEK, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deleteLokasi(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        
        db.delete(TABLE_OBJEK, COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    
    public void deleteUsers() {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        // Delete All Rows
        db.delete(TABLE_OBJEK, null, null);
        db.close();
 
        Log.d("Databas", "Deleted all user info from sqlite");
    }

    public Model_ObjWisata createLokasi(int id, String nama, String kategori, String latitude, String longitude, int id_kabupaten) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, id);
        values.put(COLUMN_NAME, nama);
        values.put(COLUMN_KATEGORI, kategori);
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        values.put(COLUMN_ID_KABUPATEN, id_kabupaten);
        long insertId = database.insert(TABLE_OBJEK, null, values); 
        Cursor cursor = database.query(TABLE_OBJEK,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_ObjWisata newLokasi = cursorToLokasi(cursor);
        cursor.close();
        return newLokasi;
      }

 
    private Model_ObjWisata cursorToLokasi(Cursor cursor)
    {
        Model_ObjWisata objek = new Model_ObjWisata(0, null, null, 0, 0, 0);
        Log.v("info", "The getLONG "+cursor.getLong(0));
        Log.v("info", "The setLatLng "+cursor.getString(1)+", "+cursor.getString(2)+", "+cursor.getString(3)+", "+cursor.getString(4)+", "+cursor.getString(5));
        objek.setId(Integer.valueOf(cursor.getString(0)));
        objek.setNama(cursor.getString(1));
        objek.setKategori(cursor.getString(2));
        objek.setLat(cursor.getDouble(3));
        objek.setLong(cursor.getDouble(4));
        objek.setIdKabupaten(Integer.valueOf(cursor.getString(5)));
        return objek;
    }

    public ArrayList<Model_ObjWisata> getAllObjek() {
        ArrayList<Model_ObjWisata> daftarObjek = new ArrayList<Model_ObjWisata>();
        Cursor cursor = database.query(TABLE_OBJEK,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_ObjWisata objek = cursorToLokasi(cursor);
          daftarObjek.add(objek);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarObjek;
    }
    
    public ArrayList<Model_ObjWisata> getAllObjekById(int id) {
        ArrayList<Model_ObjWisata> daftarObjek = new ArrayList<Model_ObjWisata>();
        Cursor cursor = database.query(
        		TABLE_OBJEK, new String[] { 
        				COLUMN_ID,
        				COLUMN_NAME, 
        				COLUMN_KATEGORI, 
        				COLUMN_LATITUDE, 
        				COLUMN_LONGITUDE, 
        				COLUMN_ID_KABUPATEN
        				}, 
        				COLUMN_ID_KABUPATEN + "=?",
                new String[] { String.valueOf(id) }, null, null, COLUMN_NAME, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_ObjWisata objek = cursorToLokasi(cursor);
          daftarObjek.add(objek);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarObjek;
      }   
    
    
    public Model_ObjWisata getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_OBJEK, new String[] { 
        				COLUMN_ID,
        				COLUMN_NAME, 
        				COLUMN_KATEGORI, 
        				COLUMN_LATITUDE, 
        				COLUMN_LONGITUDE, 
        				COLUMN_ID_KABUPATEN
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_ObjWisata contact = new Model_ObjWisata(id, null, null, 0, 0, 0);
        contact.setId(Integer.valueOf(cursor.getString(0)));
        contact.setNama(cursor.getString(1));
        contact.setKategori(cursor.getString(2));
        contact.setLat(cursor.getDouble(3));
        contact.setLong(cursor.getDouble(4));
        contact.setIdKabupaten(Integer.valueOf(cursor.getString(5)));
        return contact;
	}

    public static final String TABLE_OBJEK = "tb_obj_wisata";
    public static final String COLUMN_ID = "id_obj";
    public static final String COLUMN_NAME = "nm_obj";
    public static final String COLUMN_KATEGORI = "kategori";
    public static final String COLUMN_LATITUDE = "lat_obj";
    public static final String COLUMN_LONGITUDE = "long_obj";
    public static final String COLUMN_ID_KABUPATEN = "id_kabupaten";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_OBJEK + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY, "//
  				+ "[" + COLUMN_NAME + "] VARCHAR (25), "//
  				+ "[" + COLUMN_KATEGORI + "] INT, "//
  				+ "[" + COLUMN_LATITUDE + "] VARCHAR (20), "//
  				+ "[" + COLUMN_LONGITUDE + "] VARCHAR (20),"//
  				+ "[" + COLUMN_ID_KABUPATEN + "] INTEGER"//
  				+ ");");

  	}
}