package com.database;

import android.app.Activity;

public class Model_Photos extends Activity {

	private int id;
    private String waktu;
    private String tanggal;
    private String nama;
    private String deskripsi;
    private String url;
    private double latitude;
    private double longitude;
    private int id_tracks;
 
    public Model_Photos(int id, String waktu, String tanggal, String nm_photo, String des, String url, double latitude, double longitude, int idtracks)
    {
    	super();
    	this.id = id;
    	this.waktu = waktu;
    	this.tanggal = tanggal;
    	this.nama = nm_photo;
    	this.deskripsi = des;
    	this.url = url;
    	this.longitude = longitude;
    	this.latitude = latitude;
    	this.id_tracks = idtracks;
    	
    }

    public long getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public String getWaktu() {
        return waktu;
    }
 
    public void setWaktu(String waktuu) {
        this.waktu = waktuu;
    }
 
    public String getTanggal() {
        return tanggal;
    }
 
    public void setTanggal(String Tgl) {
        this.tanggal = Tgl;
    }
 
     public String getNama() {
        return nama;
    }
 
    public void setNama(String nm_photo) {
        this.nama = nm_photo;
    }
 
    public String getDeskripsi() {
        return deskripsi;
    }
 
    public void setDeskripsi(String des) {
        this.deskripsi = des;
    }
 
    public String getUrl() {
        return url;
    }
 
    public void setUrl(String url) {
        this.url = url;
    }
 
    public double getLong() {
        return longitude;
    }
 
    public void setLong(double longitude) {
        this.longitude = longitude;
    }
 
    public double getLat() {
        return latitude;
    }
 
    public void setLat(double latitude) {
        this.latitude = latitude;
    }
 
    public long getIdtracks() {
        return id_tracks;
    }
 
    public void setIdtracks(int idtracks) {
        this.id_tracks = idtracks;
    }
 
}