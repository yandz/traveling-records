package com.database;
 
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_Tracks {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_LATITUDE,
            COLUMN_LONGITUDE,
            COLUMN_ID_PLAN};
    public DB_Tracks(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    public int updateTracks(Model_Tracks tracks, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_LATITUDE, tracks.getLatitude());
        values.put(COLUMN_LONGITUDE, tracks.getLongitude());
        values.put(COLUMN_ID_PLAN, tracks.getIdplan());
 
        int rowsPengaruh = db.update(TABLE_TRACKS, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deleteTracks(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        
        db.delete(TABLE_TRACKS, COLUMN_ID_PLAN + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    

    public Model_Tracks createTracks(String latitude, String longitude, int id_plan) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        values.put(COLUMN_ID_PLAN, id_plan);
        long insertId = database.insert(TABLE_TRACKS, null, values); 
        Cursor cursor = database.query(TABLE_TRACKS,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Tracks newTracks = cursorToTracks(cursor);
        cursor.close();
        return newTracks;
      }
    
    private Model_Tracks cursorToTracks(Cursor cursor)
    {
        Model_Tracks tracks = new Model_Tracks(0, null, null, 0);
        Log.v("info", "The getLONG "+cursor.getLong(0));
        Log.v("info", "The setLatLng "+cursor.getString(1)+", "+cursor.getString(2)+", "+cursor.getString(3));
        tracks.setId(Integer.valueOf(cursor.getString(0)));
        tracks.setLatitude(cursor.getString(1));
        tracks.setLongitude(cursor.getString(2));
        tracks.setIdplan(Integer.valueOf(cursor.getString(3)));
        return tracks;
    }
    
    public String getIdTerakhir(){
    	SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        String selectQuery = "SELECT MAX(id_tracks) FROM "+TABLE_TRACKS;
        Cursor cursor = db.rawQuery(selectQuery, null);
        cursor.moveToFirst();
		return cursor.getString(0);
    }
    
    public ArrayList<Model_Tracks> getAllTracks() {
        ArrayList<Model_Tracks> daftarTracks = new ArrayList<Model_Tracks>();
        Cursor cursor = database.query(TABLE_TRACKS,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Tracks tracks = cursorToTracks(cursor);
          daftarTracks.add(tracks);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarTracks;
    }
    
    public Model_Tracks getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_TRACKS, new String[] { 
        				COLUMN_ID,
        				COLUMN_LATITUDE, 
        				COLUMN_LONGITUDE,
        				COLUMN_ID_PLAN
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Tracks tracks = new Model_Tracks(id, null, null, id);
        tracks.setId(Integer.valueOf(cursor.getString(0)));
        tracks.setLatitude(cursor.getString(1));
        tracks.setLongitude(cursor.getString(2));
        tracks.setIdplan(Integer.valueOf(cursor.getString(3)));
        return tracks;
	}
    
    public static final String TABLE_TRACKS = "tb_tracks";
    public static final String COLUMN_ID = "id_tracks";
    public static final String COLUMN_LATITUDE = "latitude";
    public static final String COLUMN_LONGITUDE = "longitude";
    public static final String COLUMN_ID_PLAN = "id_plan";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_TRACKS + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY AUTOINCREMENT, "//
  				+ "[" + COLUMN_LATITUDE + "] VARCHAR (20), "//
  				+ "[" + COLUMN_LONGITUDE + "] VARCHAR (20), "//
  				+ "[" + COLUMN_ID_PLAN + "] INTEGER"//
  				+ ");");

  	}
}