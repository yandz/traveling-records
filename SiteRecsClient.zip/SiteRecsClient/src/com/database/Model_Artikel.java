package com.database;

import android.app.Activity;

public class Model_Artikel extends Activity {

	private int id;
    private String waktu;
    private String tanggal;
    private String judul;
    private String deskripsi;
    private double latitude;
    private double longitude;
    private int id_tracks;
 
    public Model_Artikel(int id, String waktu, String tanggal, String judul, String deskripsi, double latitude, double longitude, int id_tracks)
    {
    	super();
    	this.id = id;
    	this.waktu = waktu;
    	this.tanggal = tanggal;
    	this.judul = judul;
    	this.deskripsi = deskripsi;
    	this.latitude = latitude;
    	this.longitude = longitude;
    	this.id_tracks = id_tracks;
    }

    public int getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public String getWaktu() {
        return waktu;
    }
 
    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }
 
    public String getTanggal() {
        return tanggal;
    }
 
    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }
 
    public String getJudul() {
        return judul;
    }
 
    public void setJudul(String judul) {
        this.judul = judul;
    }
 
    public String getDeskripsi() {
        return deskripsi;
    }
 
    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }
 
    public double getLatitude() {
        return latitude;
    }
 
    public void setLatitude(double latit) {
        this.latitude = latit;
    }
 
    public double getLongitude() {
        return longitude;
    }
 
    public void setLangit(double longit) {
        this.longitude = longit;
    }
 
    public double getIdTracks() {
        return id_tracks;
    }
 
    public void setIdTracks(int idTracks) {
        this.id_tracks = idTracks;
    }
 
}