package com.database;
 
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_Reminder {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_TENTANG,
            COLUMN_TANGGAL,
            COLUMN_WAKTU};
    public DB_Reminder(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    public int updateReminder(Model_Reminder reminder, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_TENTANG, reminder.getTentang());
        values.put(COLUMN_TANGGAL, reminder.getTanggal());
        values.put(COLUMN_WAKTU, reminder.getWaktu());
 
        // updating row
        int rowsPengaruh = db.update(TABLE_REMINDER, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deleteReminder(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        
        db.delete(TABLE_REMINDER, COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    

    public Model_Reminder createReminder(String kategori, String tanggal, String waktu) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_TENTANG, kategori);
        values.put(COLUMN_TANGGAL, tanggal);
        values.put(COLUMN_WAKTU, waktu);
        long insertId = database.insert(TABLE_REMINDER, null, values); 
        Cursor cursor = database.query(TABLE_REMINDER,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Reminder newReminder = cursorToReminder(cursor);
        cursor.close();
        return newReminder;
      }
    
    private Model_Reminder cursorToReminder(Cursor cursor)
    {
        Model_Reminder reminder = new Model_Reminder(0, null, null, null);
        Log.v("info", "The getLONG "+cursor.getLong(0));
        Log.v("info", "The setLatLng "+cursor.getString(1)+", "+cursor.getString(2)+", "+cursor.getString(3));
        reminder.setId(cursor.getLong(0));
        reminder.setTentang(cursor.getString(1));
        reminder.setTanggal(cursor.getString(2));
        reminder.setWaktu(cursor.getString(3));
        return reminder;
    }
    
    public ArrayList<Model_Reminder> getAllReminder() {
        ArrayList<Model_Reminder> daftarReminders = new ArrayList<Model_Reminder>();
        Cursor cursor = database.query(TABLE_REMINDER,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Reminder reminder = cursorToReminder(cursor);
          daftarReminders.add(reminder);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarReminders;
    }
    
    public Model_Reminder getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_REMINDER, new String[] { 
        				COLUMN_ID,
        				COLUMN_TENTANG, 
        				COLUMN_TANGGAL,
        				COLUMN_WAKTU
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Reminder reminder = new Model_Reminder(id, null, null, null);
        reminder.setId(cursor.getLong(0));
        reminder.setTentang(cursor.getString(1));
        reminder.setTanggal(cursor.getString(2));
        reminder.setWaktu(cursor.getString(3));
        return reminder;
	}

    public static final String TABLE_REMINDER = "tb_reminder";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TENTANG = "tentang";
    public static final String COLUMN_TANGGAL = "tanggal";
    public static final String COLUMN_WAKTU = "waktu";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_REMINDER + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY AUTOINCREMENT, "//
  				+ "[" + COLUMN_TENTANG + "] VARCHAR (50), "//
  				+ "[" + COLUMN_TANGGAL + "] DATE, "//
  				+ "[" + COLUMN_WAKTU + "] DATETIME"//
  				+ ");");

  	}
}