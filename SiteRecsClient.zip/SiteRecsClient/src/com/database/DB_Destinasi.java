package com.database;
 
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_Destinasi {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_ID_PLAN,
            COLUMN_ID_OBJ};
    public DB_Destinasi(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    
    public void spinProv(){
    	
    }
    
    public String getDetailPlan(){
        	SQLiteDatabase db = this.dbHelper.getReadableDatabase();
            String selectQuery = 
              "SELECT PL.nama, PL.tanggal, PL.waktu, "
            		+"DS.nama, DS.latit, DS.longi "
            		+"FROM "+DB_Planning.TABLE_PLANNING+" PL, "+ DB_Destinasi.TABLE_DESTINASI +" DS "
            		+"WHERE PL.ID = OJ.ID";
            Cursor cursor = db.rawQuery(selectQuery, null);
            cursor.moveToFirst();
    		return cursor.getString(0);        
    }
    
    public int updatePilihan(Model_Destinasi pilih, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID_PLAN, pilih.getIdplan());
        values.put(COLUMN_ID_OBJ, pilih.getIdobj());
 
        int rowsPengaruh = db.update(TABLE_DESTINASI, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deletePilihan(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        
        db.delete(TABLE_DESTINASI, COLUMN_ID_PLAN + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    

    public Model_Destinasi createPilihan(int idObj, int idPlan) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID_PLAN, idPlan);
        values.put(COLUMN_ID_OBJ, idObj);
        long insertId = database.insert(TABLE_DESTINASI, null, values); 
        Cursor cursor = database.query(TABLE_DESTINASI,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Destinasi newPilih = cursorToPilihan(cursor);
        cursor.close();
        return newPilih;
    }
    
    private Model_Destinasi cursorToPilihan(Cursor cursor)
    {
        Model_Destinasi pilih = new Model_Destinasi(0, 0, 0);
        Log.v("info", "The getLONG "+cursor.getLong(0));
        Log.v("info", "The setLatLng "+cursor.getString(1)+", "+cursor.getString(2));
        pilih.setId(Integer.valueOf(cursor.getString(0)));
        pilih.setIdplan(Integer.valueOf(cursor.getString(1)));
        pilih.setIdobj(Integer.valueOf(cursor.getString(2)));
        return pilih;
    }
    
    public ArrayList<Model_Destinasi> getAllTracks() {
        ArrayList<Model_Destinasi> daftarPilihan = new ArrayList<Model_Destinasi>();
        Cursor cursor = database.query(TABLE_DESTINASI,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Destinasi pilihan = cursorToPilihan(cursor);
          daftarPilihan.add(pilihan);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarPilihan;
    }
    
    public Model_Destinasi getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_DESTINASI, new String[] { 
        				COLUMN_ID, 
        				COLUMN_ID_PLAN,
        				COLUMN_ID_OBJ
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Destinasi pilih = new Model_Destinasi(id, 0, 0);
        pilih.setId(Integer.valueOf(cursor.getString(0)));
        pilih.setIdplan(Integer.valueOf(cursor.getString(1)));
        pilih.setIdobj(Integer.valueOf(cursor.getString(2)));
        return pilih;
	}
    
    public static final String TABLE_DESTINASI = "tb_destinasi";
    public static final String COLUMN_ID = "id_destinasi";
    public static final String COLUMN_ID_OBJ = "id_obj";
    public static final String COLUMN_ID_PLAN = "id_plan";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_DESTINASI + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY AUTOINCREMENT, "//
  				+ "[" + COLUMN_ID_PLAN + "] INTEGER, "//
  				+ "[" + COLUMN_ID_OBJ + "] INTEGER"//
  				+ ");");

  	}
}