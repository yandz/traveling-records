package com.database;

import android.app.Activity;

public class Model_Destinasi extends Activity {

	private int id;
    private int id_plan;
    private int id_obj;
 
    public Model_Destinasi(int id, int id_plan, int id_obj)
    {
    		super();
    		this.id = id;
    		this.id_plan = id_plan;
    		this.id_obj = id_obj;
    }
 
    /**
     * @return the id
     */
    public long getId() {
        return id;
    }
 
    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
 
    /**
     * @return the nama_trip
     */
    public int getIdobj() {
        return id_obj;
    }
 
    /**
     * @param nama_trip the nama_trip to set
     */
    public void setIdobj(int idObj) {
        this.id_obj = idObj;
    }
 
    /**
     * @return the jml_dest
     */
    public int getIdplan() {
        return id_plan;
    }
 
    /**
     * @param jml_destinasi the jml_destinasi to set
     */
    public void setIdplan(int idPlan) {
        this.id_plan = idPlan;
    }
 
}