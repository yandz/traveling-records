package com.database;

import android.app.Activity;

public class Model_Kabupaten extends Activity {

	private int id_kabupaten;
    private String nm_kabupaten;
    private int id_provinsi;
 
    public Model_Kabupaten(int id, String kab, int id_prov)
    {
    	super();
    	this.id_kabupaten = id;
    	this.nm_kabupaten = kab;
    	this.id_provinsi = id_prov;
    }
 
    public int getId() {
        return id_kabupaten;
    }
 
    public void setId(int id) {
        this.id_kabupaten = id;
    }
 
    public String getKabupaten() {
        return nm_kabupaten;
    }
 
    public void setKabupaten(String kabupaten) {
        this.nm_kabupaten= kabupaten;
    }
 
    public int getIdProv() {
        return id_provinsi;
    }
 
    public void setIdProv(int id_prov) {
        this.id_provinsi= id_prov;
    }
}