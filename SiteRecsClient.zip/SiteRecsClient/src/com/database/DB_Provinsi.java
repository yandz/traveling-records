package com.database;
 
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_Provinsi {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    public static String[] idProv;    
    
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_PROV
            };
    public DB_Provinsi(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    
    public ArrayList<Model_Provinsi> getProvinsi() {
        ArrayList<Model_Provinsi> daftarArtikel = new ArrayList<Model_Provinsi>();
        Cursor cursor = database.query(TABLE_PROVINSI,
            allColumns, null, null, null, null, COLUMN_PROV);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Provinsi artikel = cursorToProv(cursor);
          daftarArtikel.add(artikel);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarArtikel;
    }
    
//    public ArrayList<Model_Provinsi> getNameProv(){
//        ArrayList<Model_Provinsi> provinsi = new ArrayList<Model_Provinsi>();        
//        String selectQuery = "SELECT nm_provinsi FROM " + TABLE_PROVINSI;
//        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
//        Cursor cursor = db.rawQuery(selectQuery, null);        
//        if (cursor.moveToFirst()) {
//        	idProv = new String[cursor.getCount()];
//        	for (int i = 0; i < cursor.getCount(); i++ ){
//            	cursor.moveToPosition(i);            	
//            	idProv[i] = cursor.getString(0).toString();
//            	provinsi.add(cursor.getString(1).toString());            	
//            	Log.d("Isi Provinsi", cursor.getString(1).toString());
//            }        
//        }
//        // closing connection
//        cursor.close();
//        db.close();         
//        // returning lables
//        return provinsi;
//    }
    
    public List<String> getAllProv(){
        List<String> provinsi = new ArrayList<String>();        
        String selectQuery = "SELECT * FROM " + TABLE_PROVINSI;
        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);        
        if (cursor.moveToFirst()) {
        	idProv = new String[cursor.getCount()];
        	for (int i = 0; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);            	
            	idProv[i] = cursor.getString(0).toString();
            	provinsi.add(cursor.getString(1).toString());            	
            	Log.d("Isi Provinsi", cursor.getString(1).toString());
            }        
        }
        // closing connection
        cursor.close();
        db.close();         
        // returning lables
        return provinsi;
    }
    
    public int updateProv(Model_Provinsi provinsi, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_PROV, provinsi.getProvinsi());
 
        // updating row
        int rowsPengaruh = db.update(TABLE_PROVINSI, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deleteLokasi(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        
        db.delete(TABLE_PROVINSI, COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    
    public void deleteAll(final String TABLE_NAME){
    	SQLiteDatabase db = this.dbHelper.getWritableDatabase();
    	db.execSQL("drop table if exists "+TABLE_NAME, null);
    	db.close();
    }
    

    public Model_Provinsi createProvinsi(int id, String provinsi) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, id);
        values.put(COLUMN_PROV, provinsi);
        long insertId = database.insert(TABLE_PROVINSI, null, values); 
        Cursor cursor = database.query(TABLE_PROVINSI,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Provinsi newProv = cursorToProv(cursor);
        cursor.close();
        return newProv;
        
    }
    
    
    private Model_Provinsi cursorToProv(Cursor cursor)
    {
        Model_Provinsi alamat = new Model_Provinsi(0, null);
        Log.v("info", "The getLONG "+cursor.getLong(0));
        Log.v("info", "The setLatLng "+cursor.getString(1));
        alamat.setId(cursor.getInt(0));
        alamat.setProvinsi(cursor.getString(1));
        return alamat;
    }

    public Model_Provinsi getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_PROVINSI, new String[] { 
        				COLUMN_ID,
        				COLUMN_PROV
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Provinsi alamat = new Model_Provinsi(id, null);
        alamat.setId(cursor.getInt(0));
        alamat.setProvinsi(cursor.getString(1));
        return alamat;
	}

    public static final String TABLE_PROVINSI = "tb_provinsi";
    public static final String COLUMN_ID = "id_provinsi";
    public static final String COLUMN_PROV = "nm_provinsi";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_PROVINSI + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY, "//
  				+ "[" + COLUMN_PROV + "] VARCHAR (25) "//
  				+ ");");

  	}
}