package com.database;
 
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_Artikel {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_WAKTU,
            COLUMN_TANGGAL,
            COLUMN_JUDUL,
            COLUMN_DESKRIPSI,
            COLUMN_LATITUDE,
            COLUMN_LONGITUDE,
            COLUMN_IDTRACKS};
    public DB_Artikel(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    public int updateArtikel(Model_Artikel artikel, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_WAKTU, artikel.getWaktu());
        values.put(COLUMN_TANGGAL, artikel.getTanggal());
        values.put(COLUMN_JUDUL, artikel.getJudul());
        values.put(COLUMN_DESKRIPSI, artikel.getDeskripsi());
        values.put(COLUMN_LATITUDE, artikel.getLatitude());
        values.put(COLUMN_LONGITUDE, artikel.getLongitude());
        values.put(COLUMN_IDTRACKS, artikel.getIdTracks());
 
        int rowsPengaruh = db.update(TABLE_ARTIKEL, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deleteArtikel(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        
        db.delete(TABLE_ARTIKEL, COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    

    public Model_Artikel createArtikel(String waktu, String tanggal, String judul, String deskripsi, String latitude, String longitude, int idTracks) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_WAKTU, waktu);
        values.put(COLUMN_TANGGAL, tanggal);
        values.put(COLUMN_JUDUL, judul);
        values.put(COLUMN_DESKRIPSI, deskripsi);
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        values.put(COLUMN_IDTRACKS, idTracks);
        long insertId = database.insert(TABLE_ARTIKEL, null, values); 
        Cursor cursor = database.query(TABLE_ARTIKEL,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Artikel newArtikel= cursorToArtikel(cursor);
        cursor.close();
        return newArtikel;
      }
    
    private Model_Artikel cursorToArtikel(Cursor cursor)
    {
        Model_Artikel artikel = new Model_Artikel(0, null, null, null, null, 0, 0, 0);
        Log.d("info", "id_tracks="+cursor.getString(7)+", "+cursor.getString(3)+", "+cursor.getString(5)+", "+cursor.getString(6));
        artikel.setId(Integer.valueOf(cursor.getString(0)));
        artikel.setWaktu(cursor.getString(1));
        artikel.setTanggal(cursor.getString(2));
        artikel.setJudul(cursor.getString(3));
        artikel.setDeskripsi(cursor.getString(4));
        artikel.setLatitude(cursor.getDouble(5));
        artikel.setLangit(cursor.getDouble(6));
        artikel.setIdTracks(Integer.valueOf(cursor.getString(7)));
        return artikel;
    }
    
    public ArrayList<Model_Artikel> getAllArtikel() {
        ArrayList<Model_Artikel> daftarArtikel = new ArrayList<Model_Artikel>();
        Cursor cursor = database.query(TABLE_ARTIKEL,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Artikel artikel = cursorToArtikel(cursor);
          daftarArtikel.add(artikel);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarArtikel;
    }
    
    public ArrayList<Model_Artikel> getArtikelByIdPlan(int id)
    {		
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        ArrayList<Model_Artikel> daftarArtikel = new ArrayList<Model_Artikel>();
		String selectQuery = 
				"SELECT * FROM `tb_planning` PL, `tb_tracks` TR, `tb_artikel` AR "+
				"WHERE pl.`id_plan` = tr.`id_plan` AND tr.`id_tracks` = ar.`id_tracks` AND PL.id_plan = "+ id;
		Log.e("LOG", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
		cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Artikel artikel = cursorToArtikel(cursor);
          daftarArtikel.add(artikel);
          cursor.moveToNext();
      	  Log.d("Artikel By ID", cursor.getString(13).toString()+" "+cursor.getString(15).toString());
        }
		cursor.close();
        return daftarArtikel;   

    }
    public Model_Artikel getDetailArtikel(String name) {    	 
        Cursor cursor = database.query(
        		TABLE_ARTIKEL, new String[] { 
        				COLUMN_ID,
        				COLUMN_WAKTU, 
        				COLUMN_TANGGAL, 
        				COLUMN_JUDUL, 
        				COLUMN_DESKRIPSI, 
        				COLUMN_LATITUDE,
        				COLUMN_LONGITUDE,
        				COLUMN_IDTRACKS
        				}, 
        				COLUMN_JUDUL + "=?",
                new String[] { name }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Artikel artikel = new Model_Artikel(0, null, null, name, null, 0, 0, 0);
        artikel.setId(Integer.valueOf(cursor.getString(0)));
        artikel.setWaktu(cursor.getString(1));
        artikel.setTanggal(cursor.getString(2));
        artikel.setJudul(cursor.getString(3));
        artikel.setDeskripsi(cursor.getString(4));
        artikel.setLangit(cursor.getDouble(5));
        artikel.setLatitude(cursor.getDouble(6));
//        artikel.setIdTracks(Integer.valueOf(cursor.getString(7)));
        return artikel;
	}
    public Model_Artikel getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_ARTIKEL, new String[] { 
        				COLUMN_ID,
        				COLUMN_WAKTU, 
        				COLUMN_TANGGAL, 
        				COLUMN_JUDUL, 
        				COLUMN_DESKRIPSI, 
        				COLUMN_LATITUDE,
        				COLUMN_LONGITUDE,
        				COLUMN_IDTRACKS
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Artikel artikel = new Model_Artikel(id, null, null, null, null, 0,0, id);
        artikel.setId(Integer.valueOf(cursor.getString(0)));
        artikel.setWaktu(cursor.getString(1));
        artikel.setTanggal(cursor.getString(2));
        artikel.setJudul(cursor.getString(3));
        artikel.setDeskripsi(cursor.getString(4));
        artikel.setLangit(cursor.getDouble(5));
        artikel.setLatitude(cursor.getDouble(6));
        artikel.setIdTracks(Integer.valueOf(cursor.getString(7)));
        return artikel;
	}

    public static final String TABLE_ARTIKEL = "tb_artikel";
    public static final String COLUMN_ID = "id_artikel";
    public static final String COLUMN_WAKTU = "waktu_artikel";
    public static final String COLUMN_TANGGAL = "tgl_artikel";
    public static final String COLUMN_JUDUL = "judul";
    public static final String COLUMN_DESKRIPSI = "desk_artikel";
    public static final String COLUMN_LATITUDE = "lat_artikel";
    public static final String COLUMN_LONGITUDE = "long_artikel";
    public static final String COLUMN_IDTRACKS = "id_tracks";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_ARTIKEL + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY AUTOINCREMENT, "//
  				+ "[" + COLUMN_WAKTU + "] TIME, "//
  				+ "[" + COLUMN_TANGGAL + "] DATE, "//
  				+ "[" + COLUMN_JUDUL + "] VARCHAR (25), "//
  				+ "[" + COLUMN_DESKRIPSI + "] VARCHAR (100),"//
  				+ "[" + COLUMN_LATITUDE + "] VARCHAR (20),"//
  				+ "[" + COLUMN_LONGITUDE + "] VARCHAR (20),"//
  				+ "[" + COLUMN_IDTRACKS + "] INTEGER"//
  				+ ");");

  	}
}