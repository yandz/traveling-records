package com.database;
 
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
 
public class DB_Kabupaten {
 
    private SQLiteDatabase database;
    private DBHelper dbHelper;    
    public static String[] idKab;
    
    private String[] allColumns = { 
    		COLUMN_ID,
            COLUMN_KAB,
            COLUMN_ID_PROV
            };
    public DB_Kabupaten(Context context){
        dbHelper = new DBHelper(context);
    }
    public void openWrite() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }    
    public void openRead() {
		database = dbHelper.getReadableDatabase();
	}
    public void close() {
        dbHelper.close();
    }
    
    public ArrayList<Model_Kabupaten> getKabupaten() {
        ArrayList<Model_Kabupaten> daftarKAbupaten = new ArrayList<Model_Kabupaten>();
        Cursor cursor = database.query(TABLE_KABUPATEN,
            allColumns, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
          Model_Kabupaten kab = cursorToKab(cursor);
          daftarKAbupaten.add(kab);
          cursor.moveToNext();
        }
        cursor.close();
        return daftarKAbupaten;
    }
    
    public ArrayList<Model_Kabupaten> getAllKabId(String id) {
//        ArrayList<Model_Kabupaten> daftarKAbupaten = new ArrayList<Model_Kabupaten>();
//        Cursor cursor = database.query(TABLE_KABUPATEN,
//            allColumns, null, null, null, null, null);
//        cursor.moveToFirst();
//        while (!cursor.isAfterLast()) {
//          Model_Kabupaten kab = cursorToKab(cursor);
//          daftarKAbupaten.add(kab);
//          cursor.moveToNext();
//        }
//        cursor.close();
//        return daftarKAbupaten;

        ArrayList<Model_Kabupaten> kabupaten = new ArrayList<Model_Kabupaten>();      
        String selectQuery = "SELECT  * FROM " + TABLE_KABUPATEN + " where "+ COLUMN_ID_PROV +" = "+id;
        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);      
        if (cursor.moveToFirst()) {
        	idKab = new String[cursor.getCount()];
        	for (int i=0; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	idKab[i] = cursor.getString(0).toString();
            	Model_Kabupaten kab = cursorToKab(cursor);
            	kabupaten.add(kab);
            	Log.d("Kabupatennya", cursor.getString(1).toString());
            }        
        }
        cursor.close();        // closing connection
        db.close();
        return kabupaten;        // returning kabupaten
        
        
    }
    
    public List<String> getAllKabById(String id){
        List<String> kabupaten = new ArrayList<String>();      
        String selectQuery = "SELECT  * FROM " + TABLE_KABUPATEN + " where "+ COLUMN_ID_PROV +" = "+id;
        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);      
        if (cursor.moveToFirst()) {
        	idKab = new String[cursor.getCount()];
        	for (int i=0; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	idKab[i] = cursor.getString(0).toString();
            	kabupaten.add(cursor.getString(1).toString());
            	Log.d("Kabupatennya", cursor.getString(1).toString());
            }        
        }
        cursor.close();        // closing connection
        db.close();
        return kabupaten;        // returning kabupaten
    }
    
    public List<String> getKabWhere(String id){
        List<String> kabupaten = new ArrayList<String>();         
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_KABUPATEN + "WHERE " + COLUMN_ID_PROV + " = ?" +
                new String[] { String.valueOf(id) };
        SQLiteDatabase db = this.dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);      
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
            	kabupaten.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }         
        // closing connection
        cursor.close();
        db.close();
        // returning kabupaten
        return kabupaten;
    }
    
    public int updateProv(Model_Kabupaten kab, String position) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(COLUMN_KAB, kab.getKabupaten());
        values.put(COLUMN_ID_PROV, kab.getIdProv());
 
        // updating row
        int rowsPengaruh = db.update(TABLE_KABUPATEN, values,  COLUMN_ID + " = ?",
                new String[] { String.valueOf(position) });
        db.close();
        
        return rowsPengaruh;
    }
    
    public void deleteKabupaten(String id) {
        SQLiteDatabase db = this.dbHelper.getWritableDatabase();
        
        db.delete(TABLE_KABUPATEN, COLUMN_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }  
    

    public Model_Kabupaten createKabupaten(int id, String kabupaten, int id_prov) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, id);
        values.put(COLUMN_KAB, kabupaten);
        values.put(COLUMN_ID_PROV, id_prov);
        long insertId = database.insert(TABLE_KABUPATEN, null, values); 
        Cursor cursor = database.query(TABLE_KABUPATEN,
            allColumns, COLUMN_ID + " = " + insertId, null, null, null, null);
        cursor.moveToFirst();
        Model_Kabupaten newKab = cursorToKab(cursor);
        cursor.close();
        return newKab;
        
    }
    
    
    private Model_Kabupaten cursorToKab(Cursor cursor)
    {
        Model_Kabupaten kab = new Model_Kabupaten(0, null, 0);
        Log.v("info", "The getLONG "+cursor.getLong(0));
        Log.v("info", "The setLatLng "+cursor.getString(1)+", "+cursor.getString(2));
        kab.setId(Integer.valueOf(cursor.getString(0)));
        kab.setKabupaten(cursor.getString(1));
        kab.setIdProv(Integer.valueOf(cursor.getString(2)));
        return kab;
//		return null;
    }
    
    public Model_Kabupaten getDetail(int id) {    	 
        Cursor cursor = database.query(
        		TABLE_KABUPATEN, new String[] { 
        				COLUMN_ID,
        				COLUMN_KAB,
        				COLUMN_ID_PROV
        				}, 
        				COLUMN_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
     
        Model_Kabupaten kab = new Model_Kabupaten(id, null, 0);
        kab.setId(Integer.valueOf(cursor.getString(0)));
        kab.setKabupaten(cursor.getString(1));
        kab.setIdProv(Integer.valueOf(cursor.getString(2)));
        return kab;
	}

    public static final String TABLE_KABUPATEN = "tb_kabupaten";
    public static final String COLUMN_ID = "id_kabupaten";
    public static final String COLUMN_KAB = "nm_kabupaten";
    public static final String COLUMN_ID_PROV = "id_provinsi";
 
    public static void createTable(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS[" + TABLE_KABUPATEN + "] ("//
  				+ "[" + COLUMN_ID + "] INTEGER PRIMARY KEY, "//
  				+ "[" + COLUMN_KAB + "] VARCHAR (25), "//
  				+ "[" + COLUMN_ID_PROV + "] INTEGER "//
  				+ ");");

  	}
}