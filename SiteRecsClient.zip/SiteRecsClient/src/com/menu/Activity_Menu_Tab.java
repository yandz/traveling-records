package com.menu;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.Client.R;
import com.activity.update.Connection;
import com.activity.update.JSONParser;
import com.activity.update.Model_Adapter_Kabupaten;
import com.activity.update.Model_Adapter_Objek_Wisata;
import com.activity.update.Model_Adapter_Provinsi;
import com.activity.update.ServiceHandler;
import com.activity.client.Activity_Lokasi_History;
import com.activity.client.Activity_Menu_List;
import com.activity.client.Activity_Plan_List;
import com.activity.client.Activity_Records_List;
import com.activity.client.Help;
import com.database.DBHelper;
import com.database.DB_Kabupaten;
import com.database.DB_ObjWisata;
import com.database.DB_Provinsi;
import android.os.AsyncTask;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.TabActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
 
@SuppressLint("InflateParams")
@SuppressWarnings("deprecation")
public class Activity_Menu_Tab extends TabActivity {

	private DBHelper dbHelper;
	private DB_ObjWisata dbObj;
	private DB_Kabupaten dbKab;
	private DB_Provinsi dbProv;
    
	// JSON parser class
	JSONParser jsonParser = new JSONParser();
	JSONParser jsonParserTambah = new JSONParser();

	// JSON Node names
	private static final String TAG_OBJEKWISATA = "data";
	private static final String TAG_IDOBJEKWISATA = "ow_id";
	private static final String TAG_NAMAWISATA = "ow_namawisata";
	private static final String TAG_LATITUDE = "ow_latitude";
	private static final String TAG_LONGITUDE = "ow_longitude";
	private static final String TAG_KATEGORI = "ow_kategori";
	
	private static final String TAG_PROVINSI = "data";
	private static final String TAG_IDPROVINSI = "p_id";
	private static final String TAG_NAMAPROVINSI = "p_namaprovinsi";
	
	private static final String TAG_KABUPATEN = "data";
	private static final String TAG_IDKABUPATEN = "k_id";
	private static final String TAG_NAMAKABUPATEN = "k_namakabupaten";

	JSONObject json;
	JSONArray objekwisata = null, objekprovinsi = null, objekkabupaten = null;
	ProgressDialog pDialog;
	String[] idwisata, namawisata, latitude, longitude, kategori, idkabupaten,
			namakabupaten, Getnamakabupaten, 
			idprovinsi, namaprovinsi;
	String jsonStr, jsonStrProvinsi, jsonStrKabupaten;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_menu);
        
        // SqLite database handler
        dbHelper = new DBHelper(getApplicationContext());
        dbObj = new DB_ObjWisata(this);	dbObj.openRead();
        dbKab = new DB_Kabupaten(this);	dbKab.openRead();
        dbProv = new DB_Provinsi(this);	dbProv.openRead();
                 
        TabHost tabhost = getTabHost();
        TabHost.TabSpec spec;
        Intent intent;
        Resources res = getResources();
        
        intent = new Intent().setClass(this, Activity_Plan_List.class);
        spec = tabhost.newTabSpec("home").setIndicator("",res.getDrawable(R.drawable.black_home)).setContent(intent);//mengeset nama tab dan mengisi content pada menu tab anda.
        tabhost.addTab(spec);
         
        intent = new Intent().setClass(this, Activity_Lokasi_History.class);
        spec = tabhost.newTabSpec("maps").setIndicator("",res.getDrawable(R.drawable.black_maps)).setContent(intent);
        tabhost.addTab(spec);
         
        intent = new Intent().setClass(this, Activity_Records_List.class);
        spec = tabhost.newTabSpec("play").setIndicator("",res.getDrawable(R.drawable.black_play)).setContent(intent);
        tabhost.addTab(spec);

        intent = new Intent().setClass(this, Activity_Menu_List.class);
        spec = tabhost.newTabSpec("more").setIndicator("",res.getDrawable(R.drawable.black_more)).setContent(intent);
        tabhost.addTab(spec);
        
        //int lt = 0;
//		for (int i=0; i<tabhost.getTabWidget().getChildCount(); i++){
//        	tabhost.getTabWidget().getChildAt(i).setBackgroundColor(Color.parseColor("#fff000"));
//        }
        //tabhost.getTabWidget().setCurrentTab(3);
    	
        //pakai >> tabhost.getTabWidget().getChildAt(3).setBackgroundColor(Color.parseColor("#3D3D3D"));
        		
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_main_action, menu);
        
        return super.onCreateOptionsMenu(menu);
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        
        switch (item.getItemId())
        {
//        case R.id.action_search:
//        	// Single menu item is selected do something
//        	// Ex: launching new activity/screen or show alert message
//        	/*new ProgressMenu().execute();
//        	startActivity(new Intent(this, ProfilTravel.class));*/
//            return true;
//        case R.id.action_refresh:
//        	/*new ProgressMenu().execute();
//        	new showAlert().execute();*/
//        	return true;
        
        case R.id.action_location_found:
        	/*new ProgressMenu().execute();
        	startActivity(new Intent(this, Informasi.class));*/
        	return true;
        case R.id.action_help:
//        	new ProgressMenu().execute();
        	startActivity(new Intent(this, Help.class));
        	return true;
        case R.id.action_check_updates:

        	//Alert On Update Database ========================
      		AlertDialog.Builder UpdateDB = new AlertDialog.Builder(this);
      		UpdateDB.setTitle("Update Database");
      		UpdateDB.setMessage("Dengan Update Database, Anda Akan "
      				+ "Mendapat Rekomendasi Objek Wisata Baru "
      				+ "Atau Belum Ada Pada Database Sebelumnya.\n"
      				+ "Apakah Anda Yakin Ingin Update Database?");
      		UpdateDB.setPositiveButton("Ya", new DialogInterface.OnClickListener() {	
      			@Override
      			public void onClick(DialogInterface arg0, int arg1) {
      				dbHelper.deleteProvinsi();
      	        	dbHelper.deleteKabupaten();
      	        	dbHelper.deleteObjekWisata();  	            
      	        	new Getdatarefresh().execute();
      			}
      		});
      		UpdateDB.setNegativeButton("Tidak",	new DialogInterface.OnClickListener() {
      			@Override
      			public void onClick(DialogInterface arg0, int arg1) {
      								
      			}
      		});
      		final AlertDialog DialogUpdateDB = UpdateDB.create();
      		DialogUpdateDB.show();
      		
        	return true;
        default:
            return super.onOptionsItemSelected(item);
        }
    }
    
    public class Getdatarefresh extends AsyncTask<String, String, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			// Showing progress dialog
			pDialog = new ProgressDialog(Activity_Menu_Tab.this);
			pDialog.setMessage("Please wait updating ...");
			pDialog.setCancelable(false);
			pDialog.show();

		}

		@Override
		protected String doInBackground(String... arg0) {
			// Creating service handler class instance

			try {
				ServiceHandler sh = new ServiceHandler();

				// Making a request to url and getting response
				jsonStr = sh.makeServiceCall(Connection.url
						+ "/getobjekwisata.php", ServiceHandler.GET);
				
				jsonStrProvinsi = sh.makeServiceCall(Connection.url
						+ "/getprovinsi.php", ServiceHandler.GET);
				
				jsonStrKabupaten = sh.makeServiceCall(Connection.url
						+ "/getkabupaten.php", ServiceHandler.GET);

				Log.d("Response: ", "> " + jsonStr);
			} catch (Exception e) {
				Log.d("Exception ", e.toString());
				showAlertFailed();
			}

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			// Dismiss the progress dialog
			if (pDialog.isShowing())
				pDialog.dismiss();
			/**
			 * Refresh data dari parsed JSON
			 * */
			
			if (jsonStr != null && jsonStrProvinsi != null && jsonStrKabupaten != null) {
				try {
					JSONObject jsonObj = new JSONObject(jsonStr);
					JSONObject jsonObjProvinsi = new JSONObject(jsonStrProvinsi);
					JSONObject jsonObjKabupaten = new JSONObject(jsonStrKabupaten);

					 /*=========== Getting JSON Array OBJEK WISATA =============*/
					objekwisata = jsonObj.getJSONArray(TAG_OBJEKWISATA);
					idwisata = new String[objekwisata.length()];
					kategori = new String[objekwisata.length()];
					namawisata = new String[objekwisata.length()];
					latitude = new String[objekwisata.length()];
					longitude = new String[objekwisata.length()];
					idkabupaten = new String[objekwisata.length()];
					Getnamakabupaten = new String[objekwisata.length()];

					// looping through All News
					for (int i = 0; i < objekwisata.length(); i++) {
						JSONObject c = objekwisata.getJSONObject(i);

						int no = i + 1;
						idwisata[i] = c.getString(TAG_IDOBJEKWISATA);
						kategori[i] = c.getString(TAG_KATEGORI);
						namawisata[i] = c.getString(TAG_NAMAWISATA);
						latitude[i] = c.getString(TAG_LATITUDE);
						longitude[i] = c.getString(TAG_LONGITUDE);
						idkabupaten[i] = c.getString(TAG_IDKABUPATEN);
						Getnamakabupaten[i] = c.getString(TAG_NAMAKABUPATEN);

						Model_Adapter_Objek_Wisata wp = new Model_Adapter_Objek_Wisata(
								String.valueOf(no),idwisata[i], kategori[i], namawisata[i],latitude[i], longitude[i], idkabupaten[i], Getnamakabupaten[i]);
						
						Log.d("SQLite OW", wp.getNamakabupaten());
						dbObj.createLokasi(Integer.parseInt(wp.getidWisata()), wp.getNamawisata(), wp.getKategori(), wp.getLatitude(), wp.getLongitude(), Integer.parseInt(wp.getIDkabupaten()));
					}
					
					
					/* ========== Getting JSON Array PROVINSI =================*/
					objekprovinsi = jsonObjProvinsi.getJSONArray(TAG_PROVINSI);
					idprovinsi = new String[objekprovinsi.length()];
					namaprovinsi = new String[objekprovinsi.length()];
					
					// looping through All News
					for (int i = 0; i < objekprovinsi.length(); i++) {
						JSONObject c = objekprovinsi.getJSONObject(i);

						int no = i + 1;
						idprovinsi[i] = c.getString(TAG_IDPROVINSI);
						namaprovinsi[i] = c.getString(TAG_NAMAPROVINSI);

						Model_Adapter_Provinsi wp = new Model_Adapter_Provinsi(
								String.valueOf(no), idprovinsi[i], namaprovinsi[i]);
						Log.d("SQLite PROV", wp.getNamaprovinsi());
						dbProv.createProvinsi(Integer.parseInt(wp.getID()), wp.getNamaprovinsi());
					}
					
					
					/* ========== Getting JSON Array KABUPATEN =================*/
					objekkabupaten = jsonObjKabupaten.getJSONArray(TAG_KABUPATEN);

					idkabupaten = new String[objekkabupaten.length()];
					namakabupaten = new String[objekkabupaten.length()];
					idprovinsi = new String[objekkabupaten.length()];
					namaprovinsi = new String[objekkabupaten.length()];
					
					// looping through All News
					for (int i = 0; i < objekkabupaten.length(); i++) {
						JSONObject c = objekkabupaten.getJSONObject(i);

						int no = i + 1;
						idkabupaten[i] = c.getString(TAG_IDKABUPATEN);
						namakabupaten[i] = c.getString(TAG_NAMAKABUPATEN);
						idprovinsi[i] = c.getString(TAG_IDPROVINSI);
						namaprovinsi[i] = c.getString(TAG_NAMAPROVINSI);
						
						Model_Adapter_Kabupaten wp = new Model_Adapter_Kabupaten(
								String.valueOf(no), idkabupaten[i], namakabupaten[i], idprovinsi[i], namaprovinsi[i]);
						Log.d("SQLite KAB", wp.getNamaKabupaten());
						dbKab.createKabupaten(Integer.parseInt(wp.getidKabupaten()), wp.getNamaKabupaten(), Integer.parseInt(wp.getidProvinsi()));
					}
					
					Toast.makeText(Activity_Menu_Tab.this, "Updating Success",Toast.LENGTH_SHORT).show();
				} catch (JSONException e) {
					showAlertFailed();
				}
			} else {
				showAlertFailed();
			}			
		}
	}
    
    private void showAlertFailed() {
		Activity_Menu_Tab.this.runOnUiThread(new Runnable() {
			public void run() {
				LayoutInflater inflater = getLayoutInflater();
				View dialoglayout = inflater.inflate(
						R.layout.activity_alert_failed, null);

				TextView txttAlertitlekoneksifailed = (TextView) dialoglayout
						.findViewById(R.id.textpesan);
				txttAlertitlekoneksifailed.setText("Koneksi");

				Button btnIcon = (Button) dialoglayout.findViewById(R.id.iconn);
				btnIcon.setBackgroundResource(android.R.drawable.ic_dialog_alert);

				AlertDialog.Builder builder = new AlertDialog.Builder(Activity_Menu_Tab.this);
				builder.setCancelable(false);
				builder.setView(dialoglayout).setPositiveButton(
						R.string.string_input_yes,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								// Kondisi Button Click
								finish();
							}
						});
				AlertDialog a = builder.create();
				a.show();
				Button bp = a.getButton(DialogInterface.BUTTON_POSITIVE);
				Button bn = a.getButton(DialogInterface.BUTTON_NEGATIVE);
				bp.setBackgroundColor(Color.parseColor("#FFFFFF"));
				bn.setBackgroundColor(Color.parseColor("#FFFFFF"));
			}
		});
	}
}