package com.activity.update;

public class Model_Adapter_Provinsi {
	private String no;
	private String id;
	private String namaprovinsi;

	public Model_Adapter_Provinsi(String no, String id, String namaprovinsi) {
		this.no = no;
		this.id = id;
		this.namaprovinsi = namaprovinsi;
	}

	public String getNo() {
		return this.no;
	}

	public String getID() {
		return this.id;
	}
	
	public String getNamaprovinsi() {
		return this.namaprovinsi;
	}

}
