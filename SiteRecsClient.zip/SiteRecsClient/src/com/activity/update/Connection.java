package com.activity.update;

public class Connection {
//	public static String url = "http://siterecs.amelistore.com/";
	public static String url = "http://siterecs.luphitshop.com/";
}
