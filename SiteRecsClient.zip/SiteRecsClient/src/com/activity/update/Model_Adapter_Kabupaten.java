package com.activity.update;

public class Model_Adapter_Kabupaten {
	private String no;
	private String idkabupaten;
	private String namakabupaten;
	private String idprovinsi;
	private String namaprovinsi;
	

	public Model_Adapter_Kabupaten(String no, String idkabupaten, String namakabupaten, String idprovinsi, String namaprovinsi) {
		this.no = no;
		this.idkabupaten = idkabupaten;
		this.namakabupaten = namakabupaten;
		this.idprovinsi = idprovinsi;
		this.namaprovinsi = namaprovinsi;
	}

	public String getNo() {
		return this.no;
	}
	
	public String getidKabupaten() {
		return this.idkabupaten;
	}

	public String getNamaKabupaten() {
		return this.namakabupaten;
	}
	
	public String getidProvinsi() {
		return this.idprovinsi;
	}

	public String getNamaProvinsi() {
		return this.namaprovinsi;
	}
}
