package com.activity.update;

public class Model_Adapter_Objek_Wisata {
	private String No;
	private String idwisata;
	private String namawisata;
	private String latitude;
	private String longitude;
	private String kategori;
	private String idkabupaten;
	private String namakabupaten;

	public Model_Adapter_Objek_Wisata(String no, String idwisata, String kategori, String namawisata, String latitude, String longitude, String idkabupaten, String namakabupaten) {
		this.No = no;
		this.idwisata = idwisata;
		this.kategori = kategori;
		this.namawisata = namawisata;
		this.latitude = latitude;
		this.longitude = longitude;
		this.idkabupaten = idkabupaten;
		this.namakabupaten = namakabupaten;
	}

	public String getnoWisata() {
		return this.No;
	}
	
	public String getidWisata() {
		return this.idwisata;
	}
	
	public String getKategori() {
		return this.kategori;
	}
	
	public String getNamawisata() {
		return this.namawisata;
	}
	
	public String getLatitude() {
		return this.latitude;
	}

	public String getLongitude() {
		return this.longitude;
	}
	
	public String getIDkabupaten() {
		return this.idkabupaten;
	}
	
	public String getNamakabupaten() {
		return this.namakabupaten;
	}
}
