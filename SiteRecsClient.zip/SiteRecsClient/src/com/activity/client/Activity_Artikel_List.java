package com.activity.client;
 
import java.util.List;

import com.database.DBHelper;
import com.database.DB_Artikel;
import com.database.DB_ObjWisata;
import com.database.Model_Artikel;
import com.database.Model_ObjWisata;
import com.Client.R;

import android.app.ActionBar;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
 
public class Activity_Artikel_List extends ListActivity implements OnItemClickListener,OnItemLongClickListener, Notifier {

	private DB_Artikel db;
	private List<Model_Artikel> data;
	private LazyAdapter adapter;
	Button buttonMake;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.data_view_btn_none);    
          ActionBar actionBar = getActionBar(); 
          actionBar.setDisplayHomeAsUpEnabled(true);    
                              
          db = new DB_Artikel(this);
          db.openRead();
          ListView listView = (ListView) findViewById(android.R.id.list);
          adapter = new LazyAdapter(this);
          listView.setAdapter(adapter);
          listView.setOnItemClickListener(this);
          notifyDataSetChanged();
          
    }
    
	@Override
	public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
		new Activity_Artikel_Detail(this).show(data.get(pos));		
		Log.d("Tes Click", "Posisi ke "+pos);
	}
    

	public class LazyAdapter extends BaseAdapter {

		protected LayoutInflater inflater;

		public LazyAdapter(Context context) {
			inflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return data == null ? 0 : data.size();
		}

		@Override
		public Object getItem(int pos) {
			return pos;
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@Override
		public View getView(int pos, View v, ViewGroup group) {
			if (v == null)
				v = inflater.inflate(R.layout.data_artikel_view, null);
			TextView waktu = (TextView) v.findViewById(R.id.artViewWkt);
			TextView tanggal = (TextView) v.findViewById(R.id.artViewTgl);
			TextView judul = (TextView) v.findViewById(R.id.artViewJudul);
			TextView deskripsi = (TextView) v.findViewById(R.id.artViewDesk);
			TextView latitude = (TextView) v.findViewById(R.id.artViewLat);
			TextView longitude = (TextView) v.findViewById(R.id.artViewLong);
			
			Model_Artikel artikel = data.get(pos);
			waktu.setText(artikel.getWaktu());
			tanggal.setText(artikel.getTanggal());
			judul.setText(artikel.getJudul());
			deskripsi.setText("''"+artikel.getDeskripsi()+"''");
			latitude.setText(""+artikel.getLatitude());
			longitude.setText(""+artikel.getLongitude());
			return v;
		}
	}

	@Override
	public void notifyDataSetChanged() {
		data = db.getAllArtikel();
		adapter.notifyDataSetChanged();
	}
	
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Take appropriate action for each action item click
        switch (item.getItemId()) {
        case android.R.id.home:
        	this.finish();
            return true;
        default:
            return super.onOptionsItemSelected(item);
        }
    }
    
	@Override
	protected void onDestroy() {
		db.close();
		super.onDestroy();
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		Log.d("Tes Click", "Posisi ke"+arg2);
		return false;
	}

}