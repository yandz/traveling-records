package com.activity.client;
 
import java.util.List;

import com.database.DB_Provinsi;
import com.database.Model_Provinsi;
import com.Client.R;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.content.Context;
import android.widget.Button;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
 
@SuppressLint("InflateParams")
public class Activity_Destinasi_List extends ListActivity implements OnItemClickListener,OnItemLongClickListener, Notifier {

	private DB_Provinsi db;
	private List<Model_Provinsi> data;
	private LazyAdapter adapter;
	Button buttonMake;
	public static int idProv;
	List<String> kab;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.data_view_btn_none);    
          ActionBar actionBar = getActionBar(); 
          actionBar.setDisplayHomeAsUpEnabled(true);        
                              
          db = new DB_Provinsi(this); db.openRead();
          ListView listView = (ListView) findViewById(android.R.id.list);
          adapter = new LazyAdapter(this);
          listView.setAdapter(adapter);
          listView.setOnItemClickListener(this);
          notifyDataSetChanged();
          
    }
    
	@Override
	public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
//		new Activity_Artikel_Detail(this).show(data.get(pos));		
//		idKabupaten = DB_Kabupaten.idKab[pos].toString();
		Model_Provinsi prov = data.get(pos);        
		idProv = prov.getId();
 		Log.d("Tes IDProv", String.valueOf(idProv));
		startActivity(new Intent(Activity_Destinasi_List.this, Activity_Destinasi_List_Detail.class));
	}
    

	public class LazyAdapter extends BaseAdapter {

		protected LayoutInflater inflater;

		public LazyAdapter(Context context) {
			inflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return data == null ? 0 : data.size();
		}

		@Override
		public Object getItem(int pos) {
			return pos;
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@Override
		public View getView(int pos, View v, ViewGroup group) {
			if (v == null)
				v = inflater.inflate(R.layout.data_destinasi, null);
				TextView nm_provinsi = (TextView) v.findViewById(R.id.provinsiName);
				
				Model_Provinsi prov = data.get(pos);
				nm_provinsi.setText(prov.getProvinsi());
			return v;
		}
	}

	@Override
	public void notifyDataSetChanged() {
		data = db.getProvinsi();
		adapter.notifyDataSetChanged();
	}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Take appropriate action for each action item click
        switch (item.getItemId()) {
        case android.R.id.home:
        	this.finish();
            return true;
        default:
            return super.onOptionsItemSelected(item);
        }
    }
    
    
	@Override
	protected void onDestroy() {
		db.close();
		super.onDestroy();
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		Log.d("Tes Click", "Posisi ke"+arg2);
		return false;
	}

}