package com.activity.client;


import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.ActionBar;
import android.app.Activity;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View.OnClickListener;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import com.activity.client.*;
import com.database.DB_Artikel;
import com.database.DB_Tracks;
import com.database.Model_Artikel;
import com.menu.Activity_Menu_Tab;
import com.Client.R;
import com.Client.R.layout;

public class Activity_Artikel_Create extends Activity implements OnClickListener{

	private TextView edWaktu;
	private TextView edTanggal;
	private Button buttonSubmit;
	private EditText edJudul;
	private EditText edDeskripsi;
	private TextView edLatitude;
	private TextView edLongitude;
	
	Activity_Lokasi_Tracking lokasi_tracking;
	
	static int idPlanToArt;
	
	private DB_Artikel dataSource;
	private DB_Tracks dbTracks;
	private String[] arrMonth = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_artikel_create);
        ActionBar actionBar = getActionBar(); 
        actionBar.setDisplayHomeAsUpEnabled(true);    
        
        edWaktu = (TextView) findViewById(R.id.artWaktu);
        edTanggal = (TextView) findViewById(R.id.artTanggal);
        edJudul = (EditText) findViewById(R.id.artikelJudul);
        edDeskripsi = (EditText) findViewById(R.id.artikelDeskripsi);
        edLatitude = (TextView) findViewById(R.id.artikellat);
        edLongitude = (TextView) findViewById(R.id.artikellong);
		        
        buttonSubmit = (Button) findViewById(R.id.buttom_submit);
        buttonSubmit.setOnClickListener(this);  
        
        dataSource = new DB_Artikel(this); dataSource.openWrite();
        dbTracks = new DB_Tracks(this); dbTracks.openWrite();
        
        Calendar calender = Calendar.getInstance();
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMM yyyy");
        String strdate1 = sdf1.format(calender.getTime());
        edTanggal.setText(strdate1);
        
        Calendar calender2 = Calendar.getInstance();
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm");
        String strdate2 = sdf2.format(calender2.getTime());
        edWaktu.setText(strdate2);
        
        LocationManager myLocationManager =
        		(LocationManager)getSystemService(Context.LOCATION_SERVICE);
        		LocationListener myLocationListener = new MyLocationListener();
        		myLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
        		0, 0, myLocationListener);
        
        
    }
    
    public class MyLocationListener implements LocationListener {
    	// Dipanggil saat ada perubahan lokasi geografis pengguna
    	@Override
    	public void onLocationChanged(Location location) {
    	// Mendapatkan nilai latitude dari lokasi terbaru
    	double latitude = location.getLatitude();
    	 
    	// Mendapatkan nilai longitude dari lokasi terbaru
    	double longitude = location.getLongitude();
    	 
    	// Menampilkan lokasi terbaru menggunakan Toast
    	edLatitude.setText(String.valueOf(latitude));
    	edLongitude.setText(String.valueOf(longitude));
    	}

    	@Override
    	public void onProviderDisabled(String provider) {
    		
    	Toast.makeText(getApplicationContext(),"GPS disabled", Toast.LENGTH_LONG).show();
    	
    	}
    	 
    	// dipanggil saat provider diaktifkan oleh pengguna
    	@Override
    	public void onProviderEnabled(String provider) {

    	Toast.makeText(getApplicationContext(),"GPS enabled", Toast.LENGTH_LONG).show();

    	}
    	
		@Override
		public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
			// TODO Auto-generated method stub
			
		}
    }

	@Override
	public void onClick(View v) {

		String waktu = null;
		String tanggal = null;
		String judul = null;
		String deskripsi = null;
		String latitude = null;
		String longitude = null;
//		int id_tracks = 0;
		@SuppressWarnings("unused")
				
		Model_Artikel artikel = null; 		
		if(edWaktu.getText()!=null && edTanggal.getText()!=null && edJudul.getText()!=null && edDeskripsi.getText()!=null && edLatitude.getText()!=null && edLongitude.getText()!=null)
		{
			waktu = edWaktu.getText().toString();
			tanggal = edTanggal.getText().toString();
			judul = edJudul.getText().toString();
			deskripsi = edDeskripsi.getText().toString();
			latitude = edLatitude.getText().toString();
			longitude = edLongitude.getText().toString();
//			id_tracks = Integer.valueOf(edIdtracks.getText().toString());
		}		
		switch(v.getId())
		{
			case R.id.buttom_submit:
				Log.d("Ceking", String.valueOf(idPlanToArt));
				dbTracks.createTracks(latitude, longitude, idPlanToArt);
				artikel = dataSource.createArtikel(waktu, tanggal, judul, deskripsi, latitude, longitude, Integer.valueOf(dbTracks.getIdTerakhir()));
//				String waktu, String tanggal, String judul, String konten, String latitude, String longitude, int idTracks
//		        Intent mainIntent = new Intent(Activity_Artikel_Create.this, Activity_Artikel_List.class);
//		        startActivity(mainIntent);
		        this.finish();
		        Toast.makeText(getApplicationContext(), "Berhasil simpan Artikel " + artikel.getJudul(), Toast.LENGTH_SHORT).show();
				break;
		}
		
	}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Take appropriate action for each action item click
        switch (item.getItemId()) {
        case android.R.id.home:
        	this.finish();
            return true;
        default:
            return super.onOptionsItemSelected(item);
        }
    }
    

	@Override
	protected void onDestroy() {
		dataSource.close();
		super.onDestroy();
	}
}
