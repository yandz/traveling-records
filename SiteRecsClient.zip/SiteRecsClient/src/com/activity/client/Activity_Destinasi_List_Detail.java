package com.activity.client;
 
import java.util.ArrayList;
import java.util.List;

import com.database.DBHelper;
import com.database.DB_Kabupaten;
import com.database.DB_ObjWisata;
import com.database.Model_Kabupaten;
import com.database.Model_ObjWisata;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.Client.R;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
 
@SuppressLint("InflateParams")
public class Activity_Destinasi_List_Detail extends ListActivity implements OnItemClickListener,OnItemLongClickListener, Notifier {

	private DB_Kabupaten db;
	private DB_ObjWisata dbObj;
	private List<Model_Kabupaten> data;
	private List<Model_ObjWisata> dataObj;
	private LazyAdapter adapter;
	public static int idKab;
    DBHelper mDbHelper;
    GoogleMap googleMap;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.data_view_destinasi);        
                              
          db = new DB_Kabupaten(this); db.openRead();
          dbObj = new DB_ObjWisata(this); dbObj.openRead();
          ListView listView = (ListView) findViewById(android.R.id.list);
          adapter = new LazyAdapter(this);
          listView.setAdapter(adapter);
          listView.setOnItemClickListener(this);
          notifyDataSetChanged();
          
    }    
    
    
	@Override
	public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
//		new Activity_Artikel_Detail(this).show(data.get(pos));		

		Model_Kabupaten kab = data.get(pos);        
		idKab = kab.getId();
 		Log.d("Tes Kab", String.valueOf(idKab));
 		
 		try { 
          	// Loading map		
          	initilizeMap();

    		googleMap.clear();
    		
          	double latitude = 0;
          	double longitude = 0;
     		dataObj = dbObj.getAllObjekById(idKab);
    		for (int i = 0; i < dataObj.size(); i++) {
	          	Model_ObjWisata objek = dataObj.get(i);
	    		MarkerOptions marker = new MarkerOptions()
	    			.position(new LatLng(objek.getLat(), objek.getLong()))
	    			.title(objek.getNama())
	    			.snippet("''"+objek.getLat()+" , "+objek.getLong()+"''")
	    			.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));
	    		googleMap.addMarker(marker);
	    		
	    		latitude = objek.getLat();
	    		longitude = objek.getLong();
    		}
    		
    		CameraPosition cameraPosition = new CameraPosition.Builder()
          		.target(new LatLng(latitude, longitude)).zoom(10).build();
          	googleMap.animateCamera(CameraUpdateFactory
          		.newCameraPosition(cameraPosition));
          	
  			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); //Tipe Maps
  			googleMap.setMyLocationEnabled(true); //Arahkan Lokasi Saya Saat ini
  			googleMap.getUiSettings().setZoomControlsEnabled(true); //Menampilkan button - +
  			googleMap.getUiSettings().setMyLocationButtonEnabled(true); //Menampilkan button lokasi saya
  			googleMap.getUiSettings().setCompassEnabled(true); //Menampilkan Icon Compass
  			googleMap.getUiSettings().setRotateGesturesEnabled(true); //Lihat Rotate Gesture
  			googleMap.getUiSettings().setZoomGesturesEnabled(true); //zooming gesture
  			googleMap.getUiSettings().setMapToolbarEnabled(true); //maps toolbars

        } catch (Exception e) {
           e.printStackTrace();
        }
 		
 		
	}
	
	private void initilizeMap() {
    	
    	if (googleMap == null) {
			googleMap = ((MapFragment) getFragmentManager()
					.findFragmentById(R.id.mapDestinasi)).getMap();

			// check if map is created successfully or not
			if (googleMap == null) {
				Toast.makeText(getApplicationContext(),
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			}
		}
	}
    

	public class LazyAdapter extends BaseAdapter {

		protected LayoutInflater inflater;

		public LazyAdapter(Context context) {
			inflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return data == null ? 0 : data.size();
		}

		@Override
		public Object getItem(int pos) {
			return pos;
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@Override
		public View getView(int pos, View v, ViewGroup group) {
			if (v == null)
				v = inflater.inflate(R.layout.data_destinasi_detail, null);
				TextView nm_kab = (TextView) v.findViewById(R.id.kabupatenName);
				
				Model_Kabupaten kab = data.get(pos);
				nm_kab.setText(kab.getKabupaten());
			return v;
		}
	}

	@Override
	public void notifyDataSetChanged() {
		data = db.getAllKabId(String.valueOf(Activity_Destinasi_List.idProv));
		adapter.notifyDataSetChanged();
	}
    
	@Override
	protected void onDestroy() {
		db.close();
		super.onDestroy();
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		Log.d("Tes Click", "Posisi ke"+arg2);
		return false;
	}

}