package com.activity.client;

import com.Client.R;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class Help extends Activity {
 
	TextView plan;
	TextView track;
	TextView panduantrack;
	ImageView imgPlan;
	ImageView imgTrack;
	ImageView imgPanduan;
	
	String desPlan, desTrack, desPanduan;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);
        ActionBar actionBar = getActionBar(); 
        actionBar.setDisplayHomeAsUpEnabled(true);
 
        desPlan = "Sebelum melakukan perekaman perjalanan wisata, kamu perlu membuat 'Planning' dahulu "
        		+ "dimana Planning dapat dibuat pada tab menu 'Home' kemudian klik tombol ( + ) seperti "
        		+ "pada Gambar dibawah ini./n"
        		+ "klik ( + ) >> Isikan Data Planning >> Save >> Pilih Destinasi >> Save";
        desTrack = "Setelah Planning berhasil dibuat, kamu sudah bisa merekam "
        		+ "perjalanan wisata. Caranya tekan Planning yang akan ditracking "
        		+ "sampai muncul PopUp seperti pada gambar dibawah ini. "
        		+ "Setelah muncul lalu klik pada button 'Tracking', untuk membatalkan klik 'Cancel'.";
        desPanduan = "Setelah masuk kehalaman Tracking, langkah kamu belum langsung direkam oleh SITE RECS "
        		+ "Jadi kamu harus klik tombol ( START ) dahulu untuk mulai merekaman. "
        		+ "Jika dalam perjalanan diinginkan Sistem sementara tidak melakukan rekaman/Pause, "
        		+ "maka klik tombol ( PAUSE ). Jika perjalanan sudah selesai dan rekaman perjalanan di "
        		+ "akhiri, maka klik tombol ( STOP ) berikut detail gambarnya.";
        
        plan = (TextView) findViewById(R.id.helpPlan); 
        track = (TextView) findViewById(R.id.helpTracking);
        panduantrack = (TextView) findViewById(R.id.panduanTracking);
        imgPlan = (ImageView) findViewById(R.id.imgHelpPlan);
        imgTrack = (ImageView) findViewById(R.id.imgHelpTrack);
        imgPanduan = (ImageView) findViewById(R.id.imgPanduan);
        
        plan.setText(desPlan);
        track.setText(desTrack);
        panduantrack.setText(desPanduan);
        imgPlan.setImageDrawable(getResources().getDrawable(R.drawable.help_plan));
        imgTrack.setImageDrawable(getResources().getDrawable(R.drawable.help_mulai_tracking));
        imgPanduan.setImageDrawable(getResources().getDrawable(R.drawable.help_panduan_tracking));
        

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case android.R.id.home:
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}