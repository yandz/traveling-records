package com.activity.client;
 
import java.util.List;
import com.database.DB_Destinasi;
import com.database.DB_Kabupaten;
import com.database.DB_ObjWisata;
import com.database.DB_Planning;
import com.database.DB_Provinsi;
import com.database.DB_Tracks;
import com.database.Model_Planning;
import com.Client.R;
import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.content.Context;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.util.Log;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
 
public class Activity_Records_List extends ListActivity implements OnItemClickListener, OnItemLongClickListener, Notifier {

	Activity_Plan_Detail detailPlan;
	private DB_Planning dbPlan;
	private DB_ObjWisata dbObj;
	private DB_Kabupaten dbKab;
	private DB_Provinsi dbProv;
	private DB_Destinasi dbDes;
	private DB_Tracks dbTracks;
	
	private List<Model_Planning> dataPlan;
	
	private LazyAdapter adapter;
	Button buttonMake;
	
	public static int idPlan;
	public static String allDetailPlan;
	
	String tes;
		
    @Override
    public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.data_view_btn_none);                
          
          dbPlan = new DB_Planning(this);		dbPlan.openRead();
          dbObj = new DB_ObjWisata(this);	dbObj.openRead();
          dbKab = new DB_Kabupaten(this);	dbKab.openRead();
          dbProv = new DB_Provinsi(this);	dbProv.openRead();
          dbDes = new DB_Destinasi(this);	dbDes.openRead();
          dbTracks = new DB_Tracks(this);	dbTracks.openRead();
          
          ListView listView = (ListView) findViewById(android.R.id.list);
          adapter = new LazyAdapter(this);
          listView.setAdapter(adapter);
          listView.setOnItemClickListener(this);
          listView.setOnItemLongClickListener(this);
          notifyDataSetChanged();
    }
    
    @Override
	public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
    	new Activity_Plan_Detail(this).show(dataPlan.get(pos));
		
	}
    
    
    public boolean onItemLongClick(AdapterView<?> adapter, View v, final int pos, long id) {

    	Model_Planning trans = dataPlan.get(pos);        
		idPlan = trans.getId();
 		Log.d("Tes IDPlan", String.valueOf(idPlan));
 		dbPlan.getDestinasiFromIdPlan(idPlan).toString();
 		dbPlan.getPlayRecordCursor(idPlan).toString();
 		
		Activity_Records_Detail.idPlanToPlay= trans.getId();
        
		Log.d("IDPlan tes", String.valueOf(Activity_Records_Detail.idPlanToPlay = trans.getId()));						

		startActivity(new Intent(Activity_Records_List.this, Activity_Records_Detail.class));
		
		return true;
    	       
    }
	

	public class LazyAdapter extends BaseAdapter {

		protected LayoutInflater inflater;

		public LazyAdapter(Context context) {
			inflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return dataPlan == null ? 0 : dataPlan.size();
		}

		@Override
		public Object getItem(int pos) {
			return pos;
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@SuppressLint("InflateParams")
		@Override
		public View getView(int pos, View v, ViewGroup group) {
			
			if (v == null)
	        v = inflater.inflate(R.layout.data_plan_view, null);
			TextView waktu =(TextView) v.findViewById(R.id.detWaktu);
			TextView tanggal = (TextView) v.findViewById(R.id.detTgl);
			TextView nama = (TextView) v.findViewById(R.id.detNameTrip);
			TextView jumlah = (TextView) v.findViewById(R.id.detJmlDes);
			TextView kendaraan = (TextView) v.findViewById(R.id.detKendaraan);
			ImageView gambar = (ImageView) v.findViewById(R.id.imagePlan);
		
	        Model_Planning trans = dataPlan.get(pos);
			waktu.setText(trans.getWktPerjalanan());
			tanggal.setText(trans.getTglplan());
			nama.setText(trans.getNama_trip());
			jumlah.setText(trans.getJml_destinasi()+" Destination");
			kendaraan.setText(trans.getKendaraan());
	        
		    if (trans.getKendaraan().equals("1")) {
		    	gambar.setImageDrawable(getResources().getDrawable(R.drawable.ico_walk));
		    	kendaraan.setText("Jalan Kaki");
		    } else if (trans.getKendaraan().equals("2")) {
		    	gambar.setImageDrawable(getResources().getDrawable(R.drawable.ico_bicycle));
		    	kendaraan.setText("Sepeda");
		    } else if (trans.getKendaraan().equals("3")) {
		    	gambar.setImageDrawable(getResources().getDrawable(R.drawable.ico_moto));
		    	kendaraan.setText("Sepeda Motor");
		    } else if (trans.getKendaraan().equals("4")) {
		    	gambar.setImageDrawable(getResources().getDrawable(R.drawable.ico_car));
		    	kendaraan.setText("Mobil");
		    } else if (trans.getKendaraan().equals("5")) {
		    	gambar.setImageDrawable(getResources().getDrawable(R.drawable.ico_bus));
		    	kendaraan.setText("Bus");
		    }
		    
		    return v;
		}
	}


	@Override
	protected void onDestroy() {
		dbPlan.close();
		super.onDestroy();
	}
	
	@Override
	public void notifyDataSetChanged() {
		
//		dataPlanString = db.getAllKabToId();
		
		dataPlan = dbPlan.getAllPlanTracked();
		adapter.notifyDataSetChanged();
	}

}