//package com.activity.client;
//
//import java.io.File;
//
//import com.activity.client.Activity_Artikel_Create.MyLocationListener;
//import com.database.DB_ObjWisata;
//import com.database.Model_ObjWisata;
//import com.database.Model_Planning;
//import com.google.android.gms.maps.CameraUpdateFactory;
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.MapFragment;
//import com.google.android.gms.maps.model.BitmapDescriptor;
//import com.google.android.gms.maps.model.BitmapDescriptorFactory;
//import com.google.android.gms.maps.model.CameraPosition;
//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.maps.model.Marker;
//import com.google.android.gms.maps.model.MarkerOptions;
//import com.google.android.gms.maps.model.Polyline;
//import com.google.android.gms.maps.model.PolylineOptions;
//import com.google.android.gms.maps.model.Tile;
//import com.Admin.R;
//
//import android.app.ActionBar;
//import android.app.AlertDialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.graphics.Color;
//import android.location.Location;
//import android.location.LocationListener;
//import android.location.LocationManager;
//import android.net.Uri;
//import android.os.Bundle;
//import android.os.Environment;
//import android.provider.MediaStore;
//import android.support.v4.app.FragmentActivity;
//import android.view.MenuItem;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
// 
//public class Activity_Play_Records_2 extends FragmentActivity {
//	 // Google Map
//    private GoogleMap googleMap;
//    private TextView txLatitude;
//    private TextView txLongitude;
//    private TextView txdurasi;
//    private TextView txstatus;
//    
//    private Model_ObjWisata obj;
// 
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.data_lokasi_tracking);
//        
//        txstatus = (TextView) findViewById(R.id.trackStatus);
//        txLatitude = (TextView) findViewById(R.id.trackLat);
//        txLongitude = (TextView) findViewById(R.id.trackLong);
//        
//        LocationManager myLocationManager =
//        		(LocationManager)getSystemService(Context.LOCATION_SERVICE);
//        		LocationListener myLocationListener = new MyLocationListener();
//        		myLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
//        		0, 0, myLocationListener);
//
//        //Menampilkan ActionBar
//        ActionBar actionBar = getActionBar();
//        actionBar.setDisplayHomeAsUpEnabled(true);
// 
//        try { 
//        	// Loading map
//        	initilizeMap();
//        	addPolyLine();
//        	addMarker();
//			
//			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); //Tipe Maps
//			googleMap.setMyLocationEnabled(true); //Arahkan Lokasi Saya Saat ini
//			googleMap.getUiSettings().setZoomControlsEnabled(false); //Menampilkan button - +
//			googleMap.getUiSettings().setMyLocationButtonEnabled(true); //Menampilkan button lokasi saya
//			googleMap.getUiSettings().setCompassEnabled(true); //Menampilkan Icon Compass
//			googleMap.getUiSettings().setRotateGesturesEnabled(true); //Lihat Rotate Gesture
//			googleMap.getUiSettings().setZoomGesturesEnabled(true); //zooming gesture
//			googleMap.getUiSettings().setMapToolbarEnabled(true); //maps toolbars
//
//      } catch (Exception e) {
//         e.printStackTrace();
//      }
//                 
//      //Membuat dialog picture
//        final String [] pilih = new String [] {"Artikel", "Gambar"};
//		ArrayAdapter<String> arr_adapter = new ArrayAdapter<String> (this, android.R.layout.select_dialog_item,pilih);
//		AlertDialog.Builder builder = new AlertDialog.Builder(this);
//
//		builder.setTitle("Pilih Post");
//		builder.setAdapter( arr_adapter, new DialogInterface.OnClickListener()
//		{
//			public void onClick( DialogInterface dialog, int pilihan )
//			{
//				if (pilihan == 0)
//				{
//					startActivity(new Intent(Activity_Play_Records_2.this, Activity_Artikel_Create.class));	
//				}
//				else if(pilihan == 1)
//				{
//					startActivity(new Intent(Activity_Play_Records_2.this, Activity_Gambar_Create.class));	
//				}
//			}
//		} );
//
//		final AlertDialog dialog = builder.create();
//
//		//SetImageView = (ImageView) findViewById(R.id.img_set);
//		Button tmb_pilih = (Button) findViewById(R.id.btn_pilih_post);
//		tmb_pilih.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				dialog.show();
//			}
//		});
//		
//    }
//    
//    private void initilizeMap() {
//		if (googleMap == null) {
//			googleMap = ((MapFragment) getFragmentManager().findFragmentById(
//					R.id.map)).getMap();
//
//			// check if map is created successfully or not
//			if (googleMap == null) {
//				Toast.makeText(getApplicationContext(),
//						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
//						.show();
//			}
//		}
//	}
//    
//    public void addMarker(){
//		double latitude = -7.758375;
//		double longitude = 110.406231;
//		
//		double latitude_2 = -7.770324;
//		double longitude_2 = 110.384774;
//    	// Adding a marker
//		MarkerOptions marker = new MarkerOptions().position(
//				new LatLng(latitude, longitude))
//				.title("Start").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_artikel));
//
//		MarkerOptions markerOptions = new MarkerOptions().position(
//				new LatLng(latitude_2, longitude_2))
//				.title("Event (1)").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));
//		
//		MarkerOptions marker1 = new MarkerOptions().position(new LatLng(-7.849, 110.2978))
//				.title("Finish").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_artikel));
//		
//		MarkerOptions marker2 = new MarkerOptions().position(new LatLng(-7.789, 110.350))
//				.title("Event (3)").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));
//		
//		MarkerOptions marker3 = new MarkerOptions().position(new LatLng(-7.70324, 110.384774))
//				.title("Event (2)").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));
//				
//		googleMap.addMarker(new MarkerOptions().position(new LatLng(-7.70324, 110.384774))
//		.title("Event (2)").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi)));
//		
//		googleMap.addMarker(marker);
//		googleMap.addMarker(markerOptions);
//		googleMap.addMarker(marker1);
//		googleMap.addMarker(marker2);
//		googleMap.addMarker(marker3);
//		
//		// Adding Colour Marker
//		marker.icon(BitmapDescriptorFactory
//				.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));		
//    				
//		// Move the camera to last position with a zoom level
//		CameraPosition cameraPosition = new CameraPosition.Builder()
//				.target(new LatLng(latitude,longitude)).zoom(15).build();
//		googleMap.animateCamera(CameraUpdateFactory
//				.newCameraPosition(cameraPosition));
//    }
//    
//    public void addPolyLine(){
////    	MarkerOptions marker3 = new MarkerOptions().position(new LatLng(-7.70324, 110.384774))
////				.title("Event (2)").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_latitude));
//		
//    	
//    	Polyline polyline = googleMap.addPolyline(new PolylineOptions().add(
//    			new LatLng(-7.758375, 110.406231),
//    			new LatLng(-7.770324, 110.384774),
//    			new LatLng(-7.780324, 110.374774),
//    			new LatLng(-7.790, 110.364),
//    			new LatLng(-7.789, 110.350),
//    			new LatLng(-7.849, 110.2978)
//    			)
//    			.width(5).color(Color.GREEN));
//    }
//    
//    public class MyLocationListener implements LocationListener {
//    	// Dipanggil saat ada perubahan lokasi geografis pengguna
//    	@Override
//    	public void onLocationChanged(Location location) {
//			double latitude = location.getLatitude();
//			double longitude = location.getLongitude();
//			txLatitude.setText(String.valueOf(latitude));
//			txLongitude.setText(String.valueOf(longitude));
//    	}
//
//    	@Override
//    	public void onProviderDisabled(String provider) {
//    		Toast.makeText(getApplicationContext(),"GPS disabled", Toast.LENGTH_LONG).show();
//    	}
//    	
//    	@Override
//    	public void onProviderEnabled(String provider) {
//    		Toast.makeText(getApplicationContext(),"GPS enabled", Toast.LENGTH_LONG).show();
//    	}
//    	
//		@Override
//		public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
//			// TODO Auto-generated method stub
//			
//		}
//    }
//
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Take appropriate action for each action item click
//        switch (item.getItemId()) {
//        case R.id.action_location_found:
//            // location found
//            Intent i = new Intent(Activity_Play_Records_2.this, LocationFound.class);
//            startActivity(i);
//            return true;
//        case R.id.action_help:
//            // help action
//            return true;
//        case R.id.action_check_updates:
//            // check for updates action
//            return true;
//        default:
//            return super.onOptionsItemSelected(item);
//        }
//    }
//    
//    @Override
//	protected void onResume() {
//		super.onResume();
//	}
//
//	@Override
//	protected void onPause() {
//		super.onPause();
//	}
//
//	@Override
//	protected void onDestroy() {
//		super.onDestroy();
//	}
//
// 
//}