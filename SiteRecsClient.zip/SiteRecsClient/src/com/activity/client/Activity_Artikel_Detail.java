package com.activity.client;

import java.util.ArrayList;
import java.util.List;

import com.database.DBHelper;
import com.database.DB_Artikel;
import com.database.DB_Kabupaten;
import com.database.DB_ObjWisata;
import com.database.DB_Planning;
import com.database.DB_Reminder;
import com.database.Model_Artikel;
import com.database.Model_Planning;
import com.menu.Activity_Menu_Tab;
import com.Client.R;
import com.Client.R.layout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v4.widget.SimpleCursorAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_Artikel_Detail extends AlertDialog.Builder implements OnClickListener, OnCancelListener{
	private Context ctx;
	private DB_Planning db;

	private DB_Artikel dbArtikel;
	
	private Model_Artikel artikel;
	private View v;
	private TextView vId;
	private TextView vWaktu;
	private TextView vTgl;
	private EditText vJudul;
	private EditText vDeskripsi;
	private TextView vLatitude;
	private TextView vLongitude;
	
//	static String vIdPlan = vId.getText().toString();
	
	public Activity_Artikel_Detail(Context context) {		
		super(context);
		ctx = context;
		db = new DB_Planning(context);			db.openWrite(); db.openRead();
		dbArtikel = new DB_Artikel(context);	dbArtikel.openWrite(); dbArtikel.openRead();
		
		v = LayoutInflater.from(context).inflate(R.layout.data_artikel_detail, null);
		vId = (TextView) v.findViewById(R.id.detArtikelId);
		vWaktu = (TextView) v.findViewById(R.id.detArtikelWaktu);
		vTgl = (TextView) v.findViewById(R.id.detArtikelTanggal);
		vJudul = (EditText) v.findViewById(R.id.detArtikelJudul);
		vDeskripsi = (EditText) v.findViewById(R.id.detArtikelDeskripsi);
		vLatitude = (TextView) v.findViewById(R.id.detArtikellat);
		vLongitude = (TextView) v.findViewById(R.id.detArtikellong);
		setView(v);
		setOnCancelListener(this);	
	}
	

	public AlertDialog show(Model_Artikel artikel) {
		
		this.artikel = artikel;
		
		vId.setText(String.valueOf(artikel.getId()));
		vWaktu.setText(artikel.getWaktu());
		vTgl.setText(artikel.getTanggal());
		vJudul.setText(artikel.getJudul());
		vDeskripsi.setText(artikel.getDeskripsi());
		vLatitude.setText(String.valueOf(artikel.getLatitude()));
		vLongitude.setText(String.valueOf(artikel.getLongitude()));
		setTitle(artikel.getJudul());
		setPositiveButton("Edit", this);
		setNegativeButton("Hapus", this);
		return super.show();
	}
	
	public AlertDialog showArtikel(){
    	
        Model_Artikel artikel = dbArtikel.getDetailArtikel(Activity_Records_Detail.namaMarkerArtikel);
        
		vId.setText(String.valueOf(artikel.getId()));
		vWaktu.setText(artikel.getWaktu());
		vTgl.setText(artikel.getTanggal());
		vJudul.setText(artikel.getJudul());
		vDeskripsi.setText(artikel.getDeskripsi());
		vLatitude.setText(String.valueOf(artikel.getLatitude()));
		vLongitude.setText(String.valueOf(artikel.getLongitude()));
		setTitle(artikel.getJudul());
		setPositiveButton("Edit", this);
		setNegativeButton("Hapus", this);
		return super.show();
        
    }	

	public AlertDialog add() {
		setTitle("Tambah Planning");
		setPositiveButton("Tambah", this);
		return super.show();
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		
		switch (which) {
				case DialogInterface.BUTTON_NEGATIVE:
					vWaktu = (TextView) v.findViewById(R.id.itemWaktu);
					dbArtikel.deleteArtikel(vId.getText().toString());  
					dbArtikel.close();
					((Notifier) ctx).notifyDataSetChanged();
				break;
				case DialogInterface.BUTTON_POSITIVE:
					artikel.setWaktu(vWaktu.getText().toString());
					artikel.setTanggal(vTgl.getText().toString());
					artikel.setJudul(vJudul.getText().toString());
					artikel.setDeskripsi(vDeskripsi.getText().toString());
					artikel.setLangit(Double.valueOf(vLatitude.getText().toString()));
					artikel.setLangit(Double.valueOf(vLongitude.getText().toString()));
					dbArtikel.updateArtikel(artikel, vId.getText().toString());
	                dbArtikel.close();
	        		((Notifier) ctx).notifyDataSetChanged();
				break;
		}
	}
	
	@Override
	public void onCancel(DialogInterface dialog) {
		db.close();
		((Notifier) ctx).notifyDataSetChanged();
		
	}


}
