package com.activity.client;

import java.util.List;

import com.database.DB_Artikel;
import com.database.DB_ObjWisata;
import com.database.DB_Photos;
import com.database.Model_Artikel;
import com.database.Model_ObjWisata;
import com.database.Model_Photos;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.Client.R;

import android.app.ActionBar;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.MenuItem;
import android.widget.Toast;
 
public class Activity_Lokasi_History extends FragmentActivity {
	 // Google Map
    private GoogleMap googleMap;
	private DB_ObjWisata db;
	private DB_Photos dbPhoto;
	private DB_Artikel dbArtikel;
	private List<Model_ObjWisata> data;
	private List<Model_Photos> dataPhoto;
	private List<Model_Artikel> dataArtikels ;
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_maps);
//        ActionBar actionBar = getActionBar(); 
//        actionBar.setDisplayHomeAsUpEnabled(true);    

        db = new DB_ObjWisata(this);
        db.openRead();
		data = db.getAllObjek();
		
        dbPhoto = new DB_Photos(this);
        dbPhoto.openRead();
		dataPhoto = dbPhoto.getAllPhoto();
		
        dbArtikel = new DB_Artikel(this);
        dbArtikel.openRead();
		dataArtikels = dbArtikel.getAllArtikel();
 
        try { 
        	// Loading map
        	initilizeMap();
        	addMarker();

			// Changing map type
			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
			googleMap.setMyLocationEnabled(true);
			googleMap.getUiSettings().setZoomControlsEnabled(true);
			googleMap.getUiSettings().setMyLocationButtonEnabled(true);
			googleMap.getUiSettings().setCompassEnabled(true);
			googleMap.getUiSettings().setRotateGesturesEnabled(true);
			googleMap.getUiSettings().setZoomGesturesEnabled(true);
			googleMap.getUiSettings().setMapToolbarEnabled(true);

      } catch (Exception e) {
         e.printStackTrace();
      }
       
    }
    
    private void initilizeMap() {
		if (googleMap == null) {
			googleMap = ((MapFragment) getFragmentManager().findFragmentById(
					R.id.map)).getMap();

			// check if map is created successfully or not
			if (googleMap == null) {
				Toast.makeText(getApplicationContext(),
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			}
		}
	}
    
    public void addMarker(){
		//Marker tempat wisata
		for (int i = 0; i < data.size(); i++) {
			Model_ObjWisata objek = data.get(i);
			MarkerOptions marker = new MarkerOptions()
				.position(new LatLng(objek.getLat(), objek.getLong()))
				.title(objek.getNama())
				.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));		
			googleMap.addMarker(marker);	
		}
			
			//Marker Foto
		for (int i = 0; i < dataPhoto.size(); i++) {
			Model_Photos photo = dataPhoto.get(i);
			MarkerOptions markerPhoto = new MarkerOptions()
				.position(new LatLng(photo.getLat(), photo.getLong()))
				.title(photo.getNama())
				.snippet(photo.getDeskripsi())
				.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_photo));
			googleMap.addMarker(markerPhoto);	
		}
		
		//Marker Artikel
		for (int i = 0; i < dataArtikels.size(); i++) {
			Model_Artikel artikel = dataArtikels.get(i);
			MarkerOptions markerArtikel = new MarkerOptions()
				.position(new LatLng(artikel.getLatitude(), artikel.getLongitude()))
				.title(artikel.getJudul())
				.snippet(artikel.getDeskripsi())
				.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_artikel));
			googleMap.addMarker(markerArtikel);	
		}
		CameraPosition cameraPosition = new CameraPosition.Builder()
				.target(new LatLng(-7.758375, 110.406231))
				.zoom(12).build();
		googleMap.animateCamera(CameraUpdateFactory
				.newCameraPosition(cameraPosition));
    }
    
    
    @Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}
	

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Take appropriate action for each action item click
//        switch (item.getItemId()) {
//        case android.R.id.home:
//        	this.finish();
//            return true;
//        default:
//            return super.onOptionsItemSelected(item);
//        }
//    }

	@Override
	protected void onDestroy() {
		db.close();
		dbPhoto.close();
		dbArtikel.close();
		super.onDestroy();
	}
  
}