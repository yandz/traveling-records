package com.activity.client;

import java.util.ArrayList;
import java.util.List;

import com.database.DBHelper;
import com.database.DB_Artikel;
import com.database.DB_Kabupaten;
import com.database.DB_ObjWisata;
import com.database.DB_Photos;
import com.database.DB_Planning;
import com.database.DB_Reminder;
import com.database.Model_Artikel;
import com.database.Model_Photos;
import com.database.Model_Planning;
import com.menu.Activity_Menu_Tab;
import com.Client.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v4.widget.SimpleCursorAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_Gambar_Detail extends AlertDialog.Builder implements OnClickListener, OnCancelListener{
	private Context ctx;
	private DB_Photos db;

	private DB_Photos dbPhoto;
	
	private Model_Photos photo;
	private View v;
	private TextView vId;
	private TextView vWaktu;
	private TextView vTgl;
	private EditText vJudul;
	private EditText vDeskripsi;
	private TextView vUrl;
	private TextView vLatitude;
	private TextView vLongitude;
	private ImageView vImage;
	
//	static String vIdPlan = vId.getText().toString();
	
	public Activity_Gambar_Detail(Context context) {		
		super(context);
		ctx = context;
		db = new DB_Photos(context);			db.openWrite(); db.openRead();
		dbPhoto = new DB_Photos(context);	dbPhoto.openWrite(); dbPhoto.openRead();

		v = LayoutInflater.from(context).inflate(R.layout.data_gambar_detail, null);
		vId = (TextView) v.findViewById(R.id.detGbrId);
		vWaktu = (TextView) v.findViewById(R.id.detGbrWkt);
		vTgl = (TextView) v.findViewById(R.id.detGbrTgl);
		vJudul = (EditText) v.findViewById(R.id.detGbrJudul);
		vDeskripsi = (EditText) v.findViewById(R.id.detGbrDesk);
		vUrl = (TextView) v.findViewById(R.id.detGbrUrl);
		vLatitude = (TextView) v.findViewById(R.id.detGbrLat);
		vLongitude = (TextView) v.findViewById(R.id.detGbrLong);
		vImage = (ImageView) v.findViewById(R.id.detGbrImg);
		
		setView(v);
		setOnCancelListener(this);	
	}
	

	public AlertDialog show(Model_Photos photo) {
		
		this.photo = photo;
		
		vId.setText(String.valueOf(photo.getId()));
		vWaktu.setText(photo.getWaktu());
		vTgl.setText(photo.getTanggal());
		vJudul.setText(photo.getNama());
		vDeskripsi.setText(photo.getDeskripsi());
		vUrl.setText(photo.getUrl());
		vLatitude.setText(String.valueOf(photo.getLat()));
		vLongitude.setText(String.valueOf(photo.getLong()));
		
		Bitmap bitmap  = BitmapFactory.decodeFile(photo.getUrl());
		vImage.setImageBitmap(bitmap);
		
		setTitle(photo.getNama());
		setPositiveButton("Edit", this);
		setNegativeButton("Hapus", this);
		return super.show();
	}

	public AlertDialog add() {
		setTitle("Tambah Planning");
		setPositiveButton("Tambah", this);
		return super.show();
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		
		switch (which) {
				case DialogInterface.BUTTON_NEGATIVE:
					vWaktu = (TextView) v.findViewById(R.id.itemWaktu);
					dbPhoto.deletePhoto(vId.getText().toString());  
					dbPhoto.close();
					((Notifier) ctx).notifyDataSetChanged();
				break;
				case DialogInterface.BUTTON_POSITIVE:
					photo.setWaktu(vWaktu.getText().toString());
					photo.setTanggal(vTgl.getText().toString());
					photo.setNama(vJudul.getText().toString());
					photo.setDeskripsi(vDeskripsi.getText().toString());
					photo.setUrl(vUrl.getText().toString());
					photo.setLat(Double.valueOf(vLatitude.getText().toString()));
					photo.setLong(Double.valueOf(vLongitude.getText().toString()));
					dbPhoto.updatePhoto(photo, vId.getText().toString());
	                dbPhoto.close();
	        		((Notifier) ctx).notifyDataSetChanged();
				break;
		}
	}
	
	@Override
	public void onCancel(DialogInterface dialog) {
		db.close();
		((Notifier) ctx).notifyDataSetChanged();
		
	}


}
