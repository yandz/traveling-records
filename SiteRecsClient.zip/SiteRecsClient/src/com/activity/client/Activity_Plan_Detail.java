package com.activity.client;

import com.database.DB_Destinasi;
import com.database.DB_ObjWisata;
import com.database.DB_Planning;
import com.database.DB_Tracks;
import com.database.Model_Planning;
import com.Client.R;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("InflateParams")
public class Activity_Plan_Detail extends AlertDialog.Builder implements OnClickListener, OnCancelListener, OnItemSelectedListener{
	private Context ctx;
	private DB_Planning db;
	private DB_Destinasi dbDestinasi;
	private DB_Planning dbPlanning;
	private DB_ObjWisata dbObjWisata;	
	private DB_Tracks dbTracks;
	
	private Model_Planning plan;
	private View v;
	private TextView vId;
	private TextView vWaktu;
	private EditText vNama;
	private TextView vTgl;
	private TextView vJml;
	private Spinner vSpinner;
	
	public Activity_Plan_Detail(Context context) {		
		super(context);
		ctx = context;
		db = new DB_Planning(context);				db.openWrite(); 			db.openRead();
		dbDestinasi = new DB_Destinasi(context);	dbDestinasi.openWrite();	dbDestinasi.openRead();
		dbPlanning = new DB_Planning(context);		dbPlanning.openWrite();		dbPlanning.openRead();
		dbObjWisata = new DB_ObjWisata(context);	dbObjWisata.openWrite();	dbObjWisata.openRead();
		dbTracks = new DB_Tracks(context);			dbTracks.openWrite(); 		dbTracks.openRead();
		
		v = LayoutInflater.from(context).inflate(R.layout.data_plan_detail, null);
		vId = (TextView) v.findViewById(R.id.itemId);
		vWaktu = (TextView) v.findViewById(R.id.itemWaktu);
		vTgl = (TextView) v.findViewById(R.id.itemTgl);
		vNama = (EditText) v.findViewById(R.id.itemNameTrip);
		vJml = (TextView) v.findViewById(R.id.itemJmlDes);
		vSpinner = (Spinner) v.findViewById(R.id.itemKendaraan);
		setView(v);
		setOnCancelListener(this);
	}
	

	public AlertDialog show(Model_Planning trans) {
		
		this.plan = trans;
		
		vId.setText(String.valueOf(trans.getId()));
		vWaktu.setText(trans.getWktPerjalanan());
		vNama.setText(trans.getNama_trip());
		vTgl.setText(trans.getTglplan());
		vJml.setText(String.valueOf(trans.getJml_destinasi())+" Destinasi");
		vSpinner.setSelection(Integer.valueOf(trans.getKendaraan())-1);		
		setTitle(trans.getNama_trip());
		setPositiveButton("Edit", this);
		setNegativeButton("Hapus", this);
		return super.show();
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		
		switch (which) {
				case DialogInterface.BUTTON_NEGATIVE:
					vWaktu = (TextView) v.findViewById(R.id.itemWaktu);
					db.deletePlan(vId.getText().toString());  
					dbDestinasi.deletePilihan(vId.getText().toString());
					dbTracks.deleteTracks(vId.getText().toString());
					
		    		Toast.makeText(getContext(), "Berhasil Hapus", Toast.LENGTH_SHORT).show();
					db.close();
					((Notifier) ctx).notifyDataSetChanged();
				break;
				case DialogInterface.BUTTON_POSITIVE:
					plan.setNama_trip(vNama.getText().toString());
					plan.setWktPerjalanan(vWaktu.getText().toString());
					plan.setTglplan(vTgl.getText().toString());
					plan.setKendaraan(String.valueOf(vSpinner.getSelectedItemPosition()+1));
	                db.updatePlan(plan, vId.getText().toString());
	                db.close();
	        		((Notifier) ctx).notifyDataSetChanged();
				break;
		}
	}
	
	@Override
	public void onCancel(DialogInterface dialog) {
//		db.close();
		((Notifier) ctx).notifyDataSetChanged();
		
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long arg3) {

		String item = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
        vSpinner.setOnItemSelectedListener(this);
		
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		
	}


}
