package com.activity.client;
 
import java.util.List;

import com.database.DB_Photos;
import com.database.Model_Photos;
import com.Client.R;

import android.app.ActionBar;
import android.app.ListActivity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
 
public class Activity_Gambar_List extends ListActivity implements OnItemClickListener,Notifier {

	private DB_Photos db;
	private List<Model_Photos> data;
	private LazyAdapter adapter;
	Button buttonMake;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.data_view_btn_none);
          ActionBar actionBar = getActionBar(); 
          actionBar.setDisplayHomeAsUpEnabled(true);        
                              
          db = new DB_Photos(this);
          db.openRead();
          ListView listView = (ListView) findViewById(android.R.id.list);
          adapter = new LazyAdapter(this);
          listView.setAdapter(adapter);
          listView.setOnItemClickListener(this);
          notifyDataSetChanged();
    }
    
    @Override
	public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
		new Activity_Gambar_Detail(this).show(data.get(pos));
	}

	public class LazyAdapter extends BaseAdapter {

		protected LayoutInflater inflater;

		public LazyAdapter(Context context) {
			inflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return data == null ? 0 : data.size();
		}

		@Override
		public Object getItem(int pos) {
			return pos;
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@Override
		public View getView(int pos, View v, ViewGroup group) {
			if (v == null)
				v = inflater.inflate(R.layout.data_gambar_view, null);
			TextView waktu = (TextView) v.findViewById(R.id.viewGbrWkt);
			TextView tanggal = (TextView) v.findViewById(R.id.viewGbrTgl);
			TextView judul = (TextView) v.findViewById(R.id.viewGbrJudul);
			TextView deskripsi = (TextView) v.findViewById(R.id.viewGbrDesk);
			TextView latitude = (TextView) v.findViewById(R.id.viewGbrLat);
			TextView longitude = (TextView) v.findViewById(R.id.viewGbrLong);
			ImageView gambar = (ImageView) v.findViewById(R.id.viewGbrImg);
			
			Model_Photos artikel = data.get(pos);
			waktu.setText(artikel.getWaktu());
			tanggal.setText(artikel.getTanggal());
			judul.setText(artikel.getNama());
			deskripsi.setText("''"+artikel.getDeskripsi()+"''");
			latitude.setText(""+artikel.getLat());
			longitude.setText(""+artikel.getLong());
			

			Bitmap bitmap  = BitmapFactory.decodeFile(artikel.getUrl());
			gambar.setImageBitmap(bitmap);
			
			return v;
		}
	}

	@Override
	public void notifyDataSetChanged() {
		data = db.getAllPhoto();
		adapter.notifyDataSetChanged();
	}
	
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Take appropriate action for each action item click
        switch (item.getItemId()) {
        case android.R.id.home:
        	this.finish();
            return true;
        default:
            return super.onOptionsItemSelected(item);
        }
    }
	
	@Override
	protected void onDestroy() {
		db.close();
		super.onDestroy();
	}

}