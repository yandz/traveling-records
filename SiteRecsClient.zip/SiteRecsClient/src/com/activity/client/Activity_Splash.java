package com.activity.client;


import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.content.Intent;

import com.activity.client.*;
import com.menu.Activity_Menu_Tab;
import com.Client.R;
import com.Client.R.layout;

public class Activity_Splash extends Activity {
	
	/* kode untuk menampilkan splash screen salama 3 detik */
	  private final int SPLASH_DISPLAY_LENGHT = 3000; 
	 
	  /** Called when the activity is first created. */
	  @Override
	  public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.splash);
	  /* handler untuk menjalankan splashscreen selama 3 detik lalu 
	   * membuat HomeActivity 
	   */
	    new Handler().postDelayed(new Runnable() {
	      @Override
	      public void run() {
	        Intent mainIntent = null;
	 
	        mainIntent = new Intent(Activity_Splash.this,
	          Activity_Menu_Tab.class);
	 
	        Activity_Splash.this.startActivity(mainIntent);
	        Activity_Splash.this.finish();
	      }
	    }, SPLASH_DISPLAY_LENGHT);
	  }
	  protected void onDestroy() {
	        super.onDestroy();         
	    }  
}