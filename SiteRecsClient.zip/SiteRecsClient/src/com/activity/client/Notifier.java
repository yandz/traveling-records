package com.activity.client;

public interface Notifier {
	void notifyDataSetChanged();
}
