package com.activity.client;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.Client.R;
import com.activity.client.Activity_Artikel_Create.MyLocationListener;
import com.database.DB_Artikel;
import com.database.DB_Photos;
import com.database.DB_Tracks;
import com.database.Model_Artikel;
import com.database.Model_Photos;
import com.google.android.gms.fitness.data.DataSource;

import android.R.integer;
import android.R.string;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_Gambar_Create extends Activity implements OnClickListener {

	private Uri UrlGambar;
	private ImageView SetImageView;
	
	private TextView edWaktu;
	private TextView edTanggal;
	private Button buttonSubmit;
	private EditText edJudul;
	private EditText edDeskripsi;
	private TextView edLatitude;
	private TextView edLongitude;
	
	static int idPlanToGbr;

	private DB_Photos dataSource;
	private DB_Tracks dbTracks; 
	private static final int CAMERA = 1;
	private static final int FILE = 2;
	static String pathGambar;

    @SuppressLint({ "CutPasteId", "SimpleDateFormat" })
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_gambar_create);
        ActionBar actionBar = getActionBar(); 
        actionBar.setDisplayHomeAsUpEnabled(true);
        
        edWaktu = (TextView) findViewById(R.id.gbrWaktu);
        edTanggal = (TextView) findViewById(R.id.gbrTanggal);
        edJudul = (EditText) findViewById(R.id.gbrNama);
        edDeskripsi = (EditText) findViewById(R.id.gbrDeskripsi);
        edLatitude = (TextView) findViewById(R.id.gbrLat);
        edLongitude = (TextView) findViewById(R.id.gbrLong);
//        edIdtracks = (EditText) findViewById(R.id.gbrIdtracks);
		        
        buttonSubmit = (Button) findViewById(R.id.btn_pilih);
        buttonSubmit.setOnClickListener(this);  
        
        dataSource = new DB_Photos(this);	dataSource.openWrite();
        dbTracks = new DB_Tracks(this);	dbTracks.openWrite();

        final String [] pilih = new String [] {"Camera", "SD Card"};
		ArrayAdapter<String> arr_adapter = new ArrayAdapter<String> (this, android.R.layout.select_dialog_item,pilih);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Pilih Gambar");
		builder.setAdapter( arr_adapter, new DialogInterface.OnClickListener()
		{
			public void onClick( DialogInterface dialog, int pilihan )
			{
				if (pilihan == 0)
				{
					Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	                File file = new File(Environment.getExternalStorageDirectory(),"img_"+String.valueOf(System.currentTimeMillis())+".jpg");
	                UrlGambar = Uri.fromFile(file);	 
	                try {
	                    intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, UrlGambar);
	                    intent.putExtra("return-data", true);
	                    startActivityForResult(intent, CAMERA);
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
					dialog.cancel();
				}
				else if(pilihan == 1)
				{
					Intent intent = new Intent();
	                intent.setType("image/*");
	                intent.setAction(Intent.ACTION_GET_CONTENT);
	                startActivityForResult(Intent.createChooser(intent, "Pilih Aplikasi"), FILE);
				}
			}
		} );

		final AlertDialog dialog = builder.create();

		SetImageView = (ImageView) findViewById(R.id.img_set);
		ImageView tmb_pilih = (ImageView) findViewById(R.id.img_set);
		tmb_pilih.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.show();
			}
		});		
		
		 Calendar calender = Calendar.getInstance();
		 SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMM yyyy");
		 String strdate1 = sdf1.format(calender.getTime());
		 edTanggal.setText(strdate1);
		 
		 Calendar jam = Calendar.getInstance();
		 SimpleDateFormat sdfJam = new SimpleDateFormat("HH:mm");
		 String strdateJam = sdfJam.format(jam.getTime());
		 edWaktu.setText(strdateJam);
		 
		 LocationManager myLocationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		 LocationListener myLocationListener = new MyLocationListener();
		 myLocationManager.requestLocationUpdates(
				 LocationManager.GPS_PROVIDER, 0, 0, myLocationListener);
	        		
    }
    
    public class MyLocationListener implements LocationListener {
    	@Override
    	public void onLocationChanged(Location location) {
	    	double latitude = location.getLatitude();
	    	double longitude = location.getLongitude();
	    	edLatitude.setText(String.valueOf(latitude));
	    	edLongitude.setText(String.valueOf(longitude));
    	}

    	@Override
    	public void onProviderDisabled(String provider) {
    		Toast.makeText(getApplicationContext(),"GPS Tidak Aktif", Toast.LENGTH_SHORT).show();
    	}
    	 
    	@Override
    	public void onProviderEnabled(String provider) {
    		Toast.makeText(getApplicationContext(),"GPS Aktif", Toast.LENGTH_SHORT).show();
    	}
    	
		@Override
		public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
			
		}
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_main_action, menu);
 
        return super.onCreateOptionsMenu(menu);
    }

    @Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    if (resultCode != RESULT_OK) return;
		Bitmap bitmap 	= null;
		String path		= "";
		if (requestCode == FILE)
		{
			UrlGambar = data.getData();
			path = getRealPath(UrlGambar);

			if (path == null)
			{
				path = UrlGambar.getPath();
			}
			else
			{
				bitmap 	= BitmapFactory.decodeFile(path);
			}
		}
		else
		{
			path	= UrlGambar.getPath();
			bitmap  = BitmapFactory.decodeFile(path);
		}

		Toast.makeText(this, path,Toast.LENGTH_SHORT).show();
		SetImageView.setImageBitmap(bitmap);
		pathGambar = path;
	}

    public String getRealPath(Uri contentUri)
    {
        String path = null;
        String[] images_data = { MediaStore.Images.Media.DATA };
        Cursor cursor = getContentResolver().query(contentUri, images_data, null, null, null);
        if(cursor.moveToFirst())
        {
           int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
           path = cursor.getString(column_index);
        }
        cursor.close();
        return path;
    }
    
   
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Take appropriate action for each action item click
        switch (item.getItemId()) {
        case android.R.id.home:
        	this.finish();
            return true;
        default:
            return super.onOptionsItemSelected(item);
        }
    }
 
	@Override
	public void onClick(View v) {
		
        
		String waktu = null;
		String tanggal = null;
		String judul = null;
		String deskripsi = null;
		String latitude = null;
		String longitude = null;
		@SuppressWarnings("unused")
				
		Model_Photos photos = null; 		
		if(edTanggal.getText()!=null && edJudul.getText()!=null && edDeskripsi.getText()!=null && edLatitude.getText()!=null && edLongitude.getText()!=null)
		{
			waktu = edWaktu.getText().toString();
			tanggal = edTanggal.getText().toString();
			judul = edJudul.getText().toString();
			deskripsi = edDeskripsi.getText().toString();
//			url = edJudul.getText().toString();
			latitude = edLatitude.getText().toString();
			longitude = edLongitude.getText().toString();
		}		
		switch(v.getId())
		{
			case R.id.btn_pilih:
				Log.d("Ceking", String.valueOf(idPlanToGbr));
				dbTracks.createTracks(latitude, longitude, idPlanToGbr);
				photos = dataSource.createPhoto(waktu, tanggal, judul, deskripsi, pathGambar, latitude, longitude, Integer.valueOf(dbTracks.getIdTerakhir()));				
				this.finish();
				Toast.makeText(getApplicationContext(), "Berhasil simpan gambar '" + photos.getNama()+"'", Toast.LENGTH_SHORT).show();
		        break;
		}
		
	}
    
}