package com.activity.client;

import java.util.ArrayList;

import com.activity.client.Activity_Records_Detail.MarkerArtikel;
import com.activity.client.Activity_Records_Detail.MarkerPhoto;
import com.activity.client.Activity_Records_Detail.PinMarker;
import com.activity.client.Activity_Records_Detail.PinStartRecords;
import com.activity.client.Activity_Records_Detail.PolyRecords;
import com.database.DBHelper;
import com.database.DB_Artikel;
import com.database.DB_Destinasi;
import com.database.DB_ObjWisata;
import com.database.DB_Photos;
import com.database.DB_Planning;
import com.database.DB_Tracks;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.menu.Activity_Menu_Tab;
import com.Client.R;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
 
public class Activity_Lokasi_Tracking extends FragmentActivity {
	 // Google Map
    private GoogleMap googleMap;
    private TextView txLatitude;
    private TextView txLongitude;
    private TextView txStatus;
    private Button start;
    private Button stop;
    private int klik = 0;

	GPSTracker gps;

	Location lokasi;
	
//    public static double latitude;
//    public static double longitude;
    
    private DB_Tracks dbTracks;
    
    AlertDialog DialogStop;
    
    AlertDialog.Builder AlertGps;
    private ArrayList<LatLng> arrayPoints = null;
    
    ArrayList<PolyRecords> mPolyRecordsList;
    ArrayList<MarkerArtikel> mPinArtikelList;
    ArrayList<MarkerPhoto> mPinPhotoList;
    ArrayList<PinStartRecords> mPinStartRecordsList;
    
    
    static int idPlanningMaps;

    Marker markerArtikel;
    Marker markerPhoto;
    
    SQLiteDatabase mDatabase;
    DBHelper mDbHelper ;
    ArrayList<PinMarker> mPinMarkerList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_lokasi_tracking);
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        
        arrayPoints = new ArrayList<LatLng>();
        
        dbTracks = new DB_Tracks(this); dbTracks.openWrite(); dbTracks.openRead();
        mDbHelper = new DBHelper(this);
        
        txLatitude = (TextView) findViewById(R.id.trackLat);
        txLongitude = (TextView) findViewById(R.id.trackLong);      
        txStatus = (TextView) findViewById(R.id.trackStatus);      
        
        LocationManager myLocationManager =
        		(LocationManager)getSystemService(Context.LOCATION_SERVICE);
        		LocationListener myLocationListener = new MyLocationListener();
        		myLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
        		0, 0, myLocationListener);

 
        try { 
        	
        	initilizeMap();
        	setPinOnMap();
			
			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); //Tipe Maps
			googleMap.setMyLocationEnabled(true); //Arahkan Lokasi Saya Saat ini
			googleMap.getUiSettings().setZoomControlsEnabled(true); //Menampilkan button - +
			googleMap.getUiSettings().setMyLocationButtonEnabled(true); //Menampilkan button lokasi saya
			googleMap.getUiSettings().setCompassEnabled(true); //Menampilkan Icon Compass
			googleMap.getUiSettings().setRotateGesturesEnabled(true); //Lihat Rotate Gesture
			googleMap.getUiSettings().setZoomGesturesEnabled(true); //zooming gesture
			googleMap.getUiSettings().setMapToolbarEnabled(true); //maps toolbars

      } catch (Exception e) {
         e.printStackTrace();
      }
                 
        //Dialog POSTING =========================
        final String [] pilih = new String [] {"Artikel", "Gambar"};
		ArrayAdapter<String> arr_adapter = new ArrayAdapter<String> (this, android.R.layout.select_dialog_item,pilih);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		builder.setTitle("Pilih Post");
		builder.setAdapter( arr_adapter, new DialogInterface.OnClickListener()
		{
			public void onClick( DialogInterface dialog, int pilihan )
			{
				if (pilihan == 0)
				{
					Activity_Artikel_Create.idPlanToArt = idPlanningMaps;
					startActivity(new Intent(Activity_Lokasi_Tracking.this, Activity_Artikel_Create.class));	
				}
				else if(pilihan == 1)
				{
					Activity_Gambar_Create.idPlanToGbr = idPlanningMaps;
					startActivity(new Intent(Activity_Lokasi_Tracking.this, Activity_Gambar_Create.class));	
				}
			}
		} );

		final AlertDialog dialog = builder.create();
		
		
		//Alert On Stop ========================
		AlertDialog.Builder PesanOnStop = new AlertDialog.Builder(this);
		PesanOnStop.setTitle("Konfirmasi");
		PesanOnStop.setMessage("Apakah anda yakin ingin berhenti merekam jejak?");
		PesanOnStop.setPositiveButton("Ya", new DialogInterface.OnClickListener() {	
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				Activity_Lokasi_Tracking.this.finish();
			}
		});
		PesanOnStop.setNegativeButton("Tidak",	new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
								
			}
		});
		final AlertDialog DialogOnStop = PesanOnStop.create();
		DialogStop = DialogOnStop;
		
		//Alert GPS Listener ========================
		AlertGps = new AlertDialog.Builder(this);
		AlertGps.setTitle("GPS Konfirmasi");
		AlertGps.setMessage("GPS anda belum aktif, apakah ingin diaktifkan?");
		AlertGps.setPositiveButton("Ya", new DialogInterface.OnClickListener() {	
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				Toast.makeText(getApplicationContext(),"GPS listener activation!", Toast.LENGTH_SHORT).show();				
			}
		});
		AlertGps.setNegativeButton("Tidak",	new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
								
			}
		});
		@SuppressWarnings("unused")
		final AlertDialog DialogGps = AlertGps.create();	

		//Button Post ========================
		Button tmb_pilih = (Button) findViewById(R.id.btn_pilih_post);
		tmb_pilih.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Activity_Artikel_Create.idPlanToArt = idPlanningMaps;
				Log.d("ID Plan", String.valueOf(idPlanningMaps));
				dialog.show();
			}
		});
		
		//Button Start ========================
		start = (Button) findViewById(R.id.btnStart);
		start.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (klik == 1) //Saat TRACKING Ingin PAUSE TRACKING
				{	
					klik = 0; //rekam paus
					txStatus.setText("PAUSE Tracking, Klik ( RESUME ) untuk melanjutkan.");
					start.setText("RE\nSUME");
					Toast.makeText(getApplicationContext(),"Tracking On Pause!", Toast.LENGTH_SHORT).show();
					
				} else if (klik == 0) //Saat PAUSE ingin Tracking LAgi
				{					
					
					klik = 1; //rekam aktif
//					dbTracks.createTracks(String.valueOf(lokasi.getLatitude()), String.valueOf(lokasi.getLongitude()), idPlanningMaps);
					
					txStatus.setText("Recording..");
					start.setText("PAUSE");
					Toast.makeText(getApplicationContext(),"Tracking On Recording..!", Toast.LENGTH_SHORT).show();
//					Toast.makeText(getApplicationContext(),"Tracking On Recording..!\n"+gps.getLatitude()+" | "+gps.getLongitude(), Toast.LENGTH_SHORT).show();
				}
			}
		});

		//Button Stop ========================
		stop = (Button) findViewById(R.id.btnStop);
		stop.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				DialogOnStop.show();
			}
		});
    }
    
    private void initilizeMap() {
		if (googleMap == null) {
			googleMap = ((MapFragment) getFragmentManager().findFragmentById(
					R.id.map)).getMap();

			// check if map is created successfully or not
			if (googleMap == null) {
				Toast.makeText(getApplicationContext(),
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			}
		}
	}
    
/*======================================================= PIN MARKER TUJUAN ====================================================*/
    public class PinMarker {

    	private LatLng mCoordinates = null;
    	private MarkerOptions mTestPinOptions=null;
    	private Double mLatitude;
    	private Double mLongitude;

    	public PinMarker(String testName, String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mTestPinOptions = new MarkerOptions();
    	    mTestPinOptions.position(mCoordinates);
    	    mTestPinOptions.title(testName);
    	    mTestPinOptions.snippet( latitude + ", " + latitude);
    	    mTestPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mTestPinOptions;
    	}
    }
    
	public Cursor getPinFromDatabase(int id)
    {		
		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
		String selectQuery = 
				 "SELECT * "
				+"FROM "+ DB_Planning.TABLE_PLANNING +" PL, "+ DB_ObjWisata.TABLE_OBJEK +" OB, "+ DB_Destinasi.TABLE_DESTINASI +" DS "
				+"WHERE PL.id_plan = DS.id_plan AND OB.id_obj = DS.id_obj AND PL.id_plan = "+ id;
		Log.e("LOG", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	Log.d("Objek Wisatanya", cursor.getString(7).toString()+" "+cursor.getString(9).toString()+" "+cursor.getString(10).toString());
            }        
        }
		db.close();
        return cursor;   

    }
	
    public void setPinOnMap(){
//        try{
            Cursor pinRecordCursor = getPinFromDatabase(idPlanningMaps);
//            Cursor pinRecordCursor = (Cursor) dbPlanning.getDestinasiFromIdPlan(Integer.valueOf(idPlanningMaps));
            mPinMarkerList = new ArrayList<PinMarker>();
            if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
            {
                do
                {//String testName, String testType, String latitude, String longitude
                    PinMarker markers = new PinMarker(pinRecordCursor.getString(7),pinRecordCursor.getString(9),pinRecordCursor.getString(10));
                    mPinMarkerList.add(markers);
                    googleMap.addMarker(markers.getMarkerOption());
                    
//                    Log.d("pin", pinRecordCursor.getString(1)+" "+pinRecordCursor.getString(8)+" "+pinRecordCursor.getString(9));
                    
                    
                }
                while(pinRecordCursor.moveToNext());
                pinRecordCursor.close();
            }
    }
    
    /*==================================================== MARKER EVENT ARTIKEL ===================================================== */

    public class MarkerArtikel {
    	private LatLng mCoordinates = null;
    	private MarkerOptions mArtikelPinOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;

    	public MarkerArtikel(String Name, String Jam, String Deskripsi, String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mArtikelPinOptions = new MarkerOptions();
    	    mArtikelPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_artikel));
    	    mArtikelPinOptions.position(mCoordinates);
    	    mArtikelPinOptions.title(Name);
    	    mArtikelPinOptions.snippet(Jam + "\n" + Deskripsi);
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mArtikelPinOptions;
    	}
    }
    
	public Cursor getArtikelFromDB(int id)
    {		
		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
		String selectQuery = 
				"SELECT * FROM "
			   + DB_Planning.TABLE_PLANNING +" PL, "+ DB_Tracks.TABLE_TRACKS +" TR, "+ DB_Artikel.TABLE_ARTIKEL +" AR "+
				"WHERE PL.`id_plan` = TR.`id_plan` AND AR.`id_tracks` = TR.`id_tracks` AND PL.id_plan = "+ id;
		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	Log.d("marker", "marker "+String.valueOf(i));
            }        
        }
  		db.close();
        return cursor; 
    }	
	
    public void setMarkerArtikel(){
            final Cursor pinArtikelCursor = getArtikelFromDB(idPlanningMaps);
            mPinArtikelList = new ArrayList<MarkerArtikel>();
            if(pinArtikelCursor != null && pinArtikelCursor.moveToFirst())
            {
                do
                {//String testName, String testType, String latitude, String longitude
                    MarkerArtikel markers = new MarkerArtikel(
                    		pinArtikelCursor.getString(13),
                    		pinArtikelCursor.getString(11),
                    		pinArtikelCursor.getString(14),
                    		pinArtikelCursor.getString(15),
                    		pinArtikelCursor.getString(16));
                    mPinArtikelList.add(markers);
                    
                    markerArtikel = googleMap.addMarker(markers.getMarkerOption()); 
                    
                } while (pinArtikelCursor.moveToNext());
                pinArtikelCursor.close();
            }
    }
    

    /*==================================================== MARKER EVENT PHOTO ===================================================== */

    public class MarkerPhoto {
    	private LatLng mCoordinates = null;
    	private MarkerOptions mPhotoPinOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;
    	
    	//waktu(10), nama(12), desk(13), lat(15), LONG(16)
    	public MarkerPhoto(String Name, String Jam, String Deskripsi, String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mPhotoPinOptions = new MarkerOptions();
    	    mPhotoPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_photo));
    	    mPhotoPinOptions.position(mCoordinates);
    	    mPhotoPinOptions.title(Name);
    	    mPhotoPinOptions.snippet(Jam + " | \n " + Deskripsi);
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mPhotoPinOptions;
    	}
    }
    
	public Cursor getPhotoFromDB(int id)
    {		
		Log.d("Masuk DB", "Hallo query");
		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
		String selectQuery = 
				"SELECT * FROM "
			   + DB_Planning.TABLE_PLANNING +" PL, "+ DB_Tracks.TABLE_TRACKS +" TR, "+ DB_Photos.TABLE_PHOTO +" PH "+
				"WHERE PL.`id_plan` = TR.`id_plan` AND PH.`id_tracks` = TR.`id_tracks` AND PL.id_plan = "+ id;
		Log.e("Que Photo", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            }        
        }
  		db.close();
        return cursor; 
    }	
	
    public void setMarkerPhoto(){
            Cursor pinPhotoCursor = getPhotoFromDB(idPlanningMaps);
            mPinPhotoList = new ArrayList<MarkerPhoto>();
            if(pinPhotoCursor != null && pinPhotoCursor.moveToFirst())
            {
                do
                {//waktu(10), nama(12), desk(13), lat(15), LONG(16)
                    MarkerPhoto markers = new MarkerPhoto(
                    		pinPhotoCursor.getString(13),
                    		pinPhotoCursor.getString(11),
                    		pinPhotoCursor.getString(14),
                    		pinPhotoCursor.getString(16),
                    		pinPhotoCursor.getString(17));
                    mPinPhotoList.add(markers);
                    
                    markerPhoto = googleMap.addMarker(markers.getMarkerOption());
                    
                } while (pinPhotoCursor.moveToNext());
                pinPhotoCursor.close();
            } 
    }
    
    /*==================================================== PIN START RECORDS ===================================================== */
    public class PinStartRecords {
    	private LatLng mCoordinates = null;
    	private MarkerOptions mRecordsPinOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;
    	
    	
    	public PinStartRecords(String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mRecordsPinOptions = new MarkerOptions();
    	    mRecordsPinOptions.position(mCoordinates);
    	    mRecordsPinOptions.title("Awal");
//    	    mRecordsPinOptions.snippet(latitude+" , "+longitude);
    	    mRecordsPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_start));
//    	    mRecordsPinOptions.icon(BitmapDescriptorFactory.defaultMarker());
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mRecordsPinOptions;
    	}
    }
    
	public Cursor getPinStartRecords(int id)
    {		
  		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
  		String selectQuery = 
  				"SELECT MIN(TR.id_plan), TR.latitude, TR.Longitude FROM "+ DB_Planning.TABLE_PLANNING+ " PL, "+ DB_Tracks.TABLE_TRACKS +" TR " +
  				"WHERE PL.`id_plan` = TR.`id_plan` AND PL.id_plan = "+ id;
  		Log.e("LOG Query", selectQuery);
  		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            }        
        }
  		db.close();
        return cursor;   
    }
	
    public void setPinStartRecordsOnMap(){
        Cursor pinRecordCursor = getPinStartRecords(idPlanningMaps);
        mPinStartRecordsList = new ArrayList<PinStartRecords>();
        if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
        {
            do
            {//String testName, String testType, String latitude, String longitude
                PinStartRecords markers = new PinStartRecords(pinRecordCursor.getString(1),pinRecordCursor.getString(2));
                mPinStartRecordsList.add(markers);
                googleMap.addMarker(markers.getMarkerOption()).showInfoWindow();
            } while (pinRecordCursor.moveToNext());
            pinRecordCursor.close();
        }
    }		
    
    
/*==================================================== PIN MARKER DESTINASI ===================================================== */ 
    public class PinMarkerDes {

    	private LatLng mCoordinates = null;
    	private MarkerOptions mTestPinOptions=null;
    	public Double mLatitude;
    	public Double mLongitude;

    	public PinMarkerDes(String testName, String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mTestPinOptions = new MarkerOptions();
    	    mTestPinOptions.position(mCoordinates);
    	    mTestPinOptions.title(testName);
    	    mTestPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mTestPinOptions;
    	}
    }
    
	public Cursor getPinFromDatabaseDes(int id)
    {		
		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
		String selectQuery = 
				 "SELECT * "
				+"FROM "+ DB_Planning.TABLE_PLANNING +" PL, "+ DB_ObjWisata.TABLE_OBJEK +" OB, "+ DB_Destinasi.TABLE_DESTINASI +" DS "
				+"WHERE PL.id_plan = DS.id_plan AND OB.id_obj = DS.id_obj AND PL.id_plan = "+ id;
		Cursor cursor = db.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	Log.d("Destinasinya", cursor.getString(7).toString()+" "+cursor.getString(9).toString()+" "+cursor.getString(10).toString());
        	}        
        }
		db.close();
        return cursor;   
    }
	
    public void setPinDestinasiOnMap(){
        Cursor pinRecordCursor = getPinFromDatabase(idPlanningMaps);
        mPinMarkerList = new ArrayList<PinMarker>();
        if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
        {
            do
            {//String testName, String testType, String latitude, String longitude
                PinMarker markers = new PinMarker(pinRecordCursor.getString(7),pinRecordCursor.getString(9),pinRecordCursor.getString(10));
                mPinMarkerList.add(markers);    
                
            } while (pinRecordCursor.moveToNext());
            pinRecordCursor.close();
        }
    }

    /*==================================================== POLYLINE RECORDS ===================================================== */
    public class PolyRecords {
    	private LatLng mCoordinates = null;
    	private PolylineOptions mRecordsPolyOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;
    	
    	public PolyRecords(String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);    	    
    	    mRecordsPolyOptions = new PolylineOptions();
    	    arrayPoints.add(mCoordinates);
    	    mRecordsPolyOptions.addAll(arrayPoints);
    	    mRecordsPolyOptions.width(6);
    	    mRecordsPolyOptions.color(Color.RED);
    	}
    	public PolylineOptions getPolyOption()
    	{
    	    return mRecordsPolyOptions;
    	}
    }
    
	public Cursor getPolyRecords(int id)
    {		
  		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
  		String selectQuery = 
  				"SELECT * FROM "+ DB_Planning.TABLE_PLANNING+ " PL, "+ DB_Tracks.TABLE_TRACKS +" TR " +
  				"WHERE PL.`id_plan` = TR.`id_plan` AND PL.id_plan = "+ id;
  		Log.e("LOG", selectQuery);
  		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            }        
        }
  		db.close();
        return cursor;   
    }
	
    public void setPolyRecordsOnMap(){
        Cursor pinRecordCursor = getPolyRecords(idPlanningMaps);
        if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
        {
            do
            {//String testName, String testType, String latitude, String longitude
                PolyRecords polyline = new PolyRecords(pinRecordCursor.getString(7),pinRecordCursor.getString(8));
                googleMap.addPolyline(polyline.getPolyOption());
            } while (pinRecordCursor.moveToNext());
            pinRecordCursor.close();
        }
        	
    }
    
    //============================================================
    		
    public class MyLocationListener implements LocationListener {
    	// Dipanggil saat ada perubahan lokasi geografis pengguna
    	
    	@Override
    	public void onLocationChanged(Location location) {
			double latitude = location.getLatitude();
			double longitude = location.getLongitude();
			
			googleMap.clear();
			setMarkerArtikel();
			setMarkerPhoto();
			setPinDestinasiOnMap();
//			setPolyRecordsOnMap();
			
			txLatitude.setText(String.valueOf(latitude));
			txLongitude.setText(String.valueOf(longitude));
			Log.d("GPSTracking", latitude+" , "+longitude);
			
			
			if (klik == 1) //ON TRACKING
			{

//				setPinStartRecordsOnMap();
				dbTracks.createTracks(String.valueOf(location.getLatitude()), String.valueOf(location.getLongitude()), idPlanningMaps);
				Log.d("Status", "Tracking Your Movement");
//				try {
//					setPinStartRecordsOnMap();
//					dbTracks.createTracks(String.valueOf(location.getLatitude()), String.valueOf(location.getLongitude()), idPlanningMaps);
//					Log.d("Status", "Tracking Your Movement");
//
//				} catch (Exception e) {
//					Log.e("Create Log", String.valueOf(latitude)+" "+String.valueOf(longitude)+" "+String.valueOf(idPlanningMaps));
//				}

				// setting polyline on maps
				PolylineOptions polylineOptions = new PolylineOptions();
				polylineOptions.color(Color.RED);
				polylineOptions.width(6);
				arrayPoints.add(new LatLng(latitude, longitude));
				polylineOptions.addAll(arrayPoints);
				googleMap.addPolyline(polylineOptions);

				
			} else if (klik == 0) //ON STOP
			{
				
				Log.d("Status", "Klik Start To Play");
				
			}
			
			
    	}

    	@Override
    	public void onProviderDisabled(String provider) {
    		Toast.makeText(getApplicationContext(),"GPS disabled", Toast.LENGTH_LONG).show();

            gps = new GPSTracker(Activity_Lokasi_Tracking.this);
            gps.showSettingsAlert();
    		
//    		final AlertDialog DialogGps = AlertGps.create();
//    		DialogGps.show();
    	}
    	
    	@Override
    	public void onProviderEnabled(String provider) {
    		Toast.makeText(getApplicationContext(),"GPS enabled", Toast.LENGTH_LONG).show();
    	}
    	
		@Override
		public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
			
		}
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_tracking, menu);
        
        return super.onCreateOptionsMenu(menu);
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case android.R.id.home:
        	DialogStop.show();
//            return true;
        case R.id.action_location_found:

        	// create class object
            gps = new GPSTracker(Activity_Lokasi_Tracking.this);

            // check if GPS enabled     
            if(gps.canGetLocation()){
                 
                double latitude = gps.getLatitude();
                double longitude = gps.getLongitude();
                 
                // \n is for new line
                Toast.makeText(getApplicationContext(), "Your Mu : \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();    
            }else{
                // can't get location
                // GPS or Network is not enabled
                // Ask user to enable GPS/network in settings
                gps.showSettingsAlert();
            }
            return true;
        case R.id.action_help:
        	Intent i = new Intent(Activity_Lokasi_Tracking.this, Help.class);
        	startActivity(i);
            return true;
//          case R.id.action_check_updates:
//        	  DialogStop.show();
//          return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    
    @Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}
	

	@Override
	protected void onDestroy() {
		dbTracks.close();
		super.onDestroy();
	}

 
}