package com.activity.client;
//package com.activity;
// 
//import java.util.List;
//
//import com.activity.admin.Activity_Objek_Detail;
//import com.database.DBHelper;
//import com.database.DB_Artikel;
//import com.database.DB_ObjWisata;
//import com.database.DB_Photos;
//import com.database.Model_Artikel;
//import com.database.Model_ObjWisata;
//import com.database.Model_Photos;
//import com.Admin.R;
//
//import android.app.ListActivity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.content.Context;
//import android.database.sqlite.SQLiteDatabase;
//import android.widget.Button;
//import android.widget.ListView;
//import android.widget.AdapterView;
//import android.widget.AdapterView.OnItemClickListener;
//import android.widget.BaseAdapter;
//import android.widget.TextView;
//import android.view.Menu;
//import android.view.MenuInflater;
//import android.view.View;
//import android.view.LayoutInflater;
//import android.view.ViewGroup;
// 
//public class Activity_Destinasi_View extends ListActivity implements OnItemClickListener,Notifier {
//
//	Activity_Objek_Detail detailLokasi;
//	private DB_Photos db;
//	private List<Model_Photos> data;
//	private LazyAdapter adapter;
//	Button buttonMake;
//	
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//          super.onCreate(savedInstanceState);
//          setContentView(R.layout.data_view_btn_none);        
//                              
//          db = new DB_Photos(this);
//          db.openRead();
//          ListView listView = (ListView) findViewById(android.R.id.list);
//          adapter = new LazyAdapter(this);
//          listView.setAdapter(adapter);
//          listView.setOnItemClickListener(this);
//          notifyDataSetChanged();
//  		
//          
//    }
//    
//    @Override
//	public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
//		//new Activity_Lokasi_Detail(this).show(data.get(pos));
//	}
//	
//	@Override
//	protected void onDestroy() {
//		db.close();
//		super.onDestroy();
//	}
//
//	public class LazyAdapter extends BaseAdapter {
//
//		protected LayoutInflater inflater;
//
//		public LazyAdapter(Context context) {
//			inflater = LayoutInflater.from(context);
//		}
//
//		@Override
//		public int getCount() {
//			return data == null ? 0 : data.size();
//		}
//
//		@Override
//		public Object getItem(int pos) {
//			return pos;
//		}
//
//		@Override
//		public long getItemId(int pos) {
//			return pos;
//		}
//
//		@Override
//		public View getView(int pos, View v, ViewGroup group) {
//			if (v == null)
//				v = inflater.inflate(R.layout.data_gambar_detail, null);
//			TextView waktu = (TextView) v.findViewById(R.id.gbrViewWkt);
//			TextView tanggal = (TextView) v.findViewById(R.id.gbrViewTgl);
//			TextView judul = (TextView) v.findViewById(R.id.gbrViewJudul);
//			TextView deskripsi = (TextView) v.findViewById(R.id.gbrViewDesk);
//			TextView latitude = (TextView) v.findViewById(R.id.gbrViewLat);
//			TextView longitude = (TextView) v.findViewById(R.id.gbrViewLong);
//			TextView idalamat = (TextView) v.findViewById(R.id.detIdalamat);
//			Model_Photos artikel = data.get(pos);
//			waktu.setText(artikel.getWaktu());
//			tanggal.setText(artikel.getTanggal());
//			judul.setText(artikel.getNama());
//			latitude.setText(""+artikel.getLat());
//			longitude.setText(""+artikel.getLong());
//			deskripsi.setText("''"+artikel.getDeskripsi()+"''");
//			return v;
//		}
//	}
//
//	@Override
//	public void notifyDataSetChanged() {
//		data = db.getAllPhoto();
//		adapter.notifyDataSetChanged();
//	}
//	
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.activity_main_action, menu);
// 
//        return super.onCreateOptionsMenu(menu);
//    }
//
//}