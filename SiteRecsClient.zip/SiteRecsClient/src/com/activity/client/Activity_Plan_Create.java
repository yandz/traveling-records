package com.activity.client;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.database.DB_Destinasi;
import com.database.DB_Kabupaten;
import com.database.DB_ObjWisata;
import com.database.DB_Planning;
import com.database.DB_Provinsi;
import com.database.Model_Planning;
import com.menu.Activity_Menu_Tab;
import com.Client.R;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

public class Activity_Plan_Create extends Activity implements OnClickListener, OnItemSelectedListener {

	private Button buttonSubmit;
	private EditText edNama;
	private EditText edJmldest;
    private EditText edTanggal;
	private EditText edWaktu;
	private Spinner eSpinner;
	
	int hour, minute, mYear,mMonth, mDay, i;
    static final int TIME_DIALOG_ID = 0;
    static final int DATE_DIALOG_ID = 1;
	private String[] arrMonth = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

	private DB_Planning dataSource;
	private DB_Provinsi dbProvinsi;
	private DB_Kabupaten dbKabupaten;
	private DB_ObjWisata dbObjWisata;
	private DB_Destinasi dbDestinasi;
	private Activity_Menu_Tab menutab;
	
	static String idProvinsi, idKabupaten, idObjwisata;
	static int idObj;
	
	List<String> obj, kab, prov;
	
	LinearLayout alertPilih;
	
	int loop = 0;

	Spinner spinProv; 
	Spinner spinKab;
    Spinner spinObj;
    
	
//	public LazyAdapter adapter;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_plan_create);    
        
                
        edNama = (EditText) findViewById(R.id.nama_trip);
        edJmldest = (EditText) findViewById(R.id.jml_dest);
        edTanggal = (EditText) findViewById(R.id.edTanggal);
        edWaktu = (EditText) findViewById(R.id.edWaktu);
        eSpinner = (Spinner) findViewById(R.id.spinner);
        
        buttonSubmit = (Button) findViewById(R.id.buttom_submit);
        buttonSubmit.setOnClickListener(this);
        
        dataSource = new DB_Planning(this);	dataSource.openWrite();
        dbProvinsi = new DB_Provinsi(this);	dbProvinsi.openWrite();                   
        dbKabupaten = new DB_Kabupaten(this); dbKabupaten.openWrite();                
        dbObjWisata = new DB_ObjWisata(this); dbObjWisata.openWrite();             
        dbDestinasi = new DB_Destinasi(this); dbDestinasi.openWrite();
        
        
		final Calendar c = Calendar.getInstance();
	    mYear = c.get(Calendar.YEAR);
	    mMonth = c.get(Calendar.MONTH);
	    mDay = c.get(Calendar.DAY_OF_MONTH);

        edTanggal.setOnTouchListener(new OnTouchListener() {

			@SuppressLint("ClickableViewAccessibility")
			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {
				showDialog(DATE_DIALOG_ID);
				return true;
			}
        });

        edWaktu.setOnTouchListener(new OnTouchListener() {

			@SuppressLint("ClickableViewAccessibility")
			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {
				showDialog(TIME_DIALOG_ID);
				return true;
			}
        });
        
        List<String>categories = new ArrayList<String>();
        categories.add("Pilih Kendaraan");
        categories.add("Jalan Kaki");
        categories.add("Bersepeda");
        categories.add("Sepeda Motor");
        categories.add("Mobil");
        categories.add("Bus");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eSpinner.setAdapter(dataAdapter);
        
    
    }
    
    public boolean validasiForm(EditText editText){
		String text = editText.getText().toString().trim();
		editText.setError(null);
		if (text.length() == 0){
			editText.setError(Html.fromHtml("<font colour='white'> Tidak Boleh Kosong </font>"));
			return false;
		}
		return true;
    	
    }
    
    
    class provinsiClickListene implements OnItemSelectedListener{
    	
    	Activity_Plan_Create planActivity;
    	
    	public provinsiClickListene(Activity_Plan_Create planActivity){
    		this.planActivity = planActivity;
    	}

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
  		
			prov = dbProvinsi.getAllProv();
			Log.d("Select Prov", DB_Provinsi.idProv[position].toString());
	        kab = dbKabupaten.getAllKabById(DB_Provinsi.idProv[position].toString());
			idProvinsi = DB_Provinsi.idProv[position].toString();				
	        ArrayAdapter<String> dataAdapterKab = new ArrayAdapter<String>(planActivity,android.R.layout.simple_spinner_item, kab);
	        dataAdapterKab.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	        spinKab.setAdapter(dataAdapterKab);    			
			 
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
    }
    
    class kabupatenClickListene implements OnItemSelectedListener{
    	
    	Activity_Plan_Create planActivity;
    	
    	public kabupatenClickListene(Activity_Plan_Create planActivity){
    		this.planActivity = planActivity;
    	}

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int position,
				long arg3) {

			obj = dbObjWisata.getAllObjById(DB_Kabupaten.idKab[position].toString());
			Log.d("cek", DB_Kabupaten.idKab[position].toString());
			idKabupaten = DB_Kabupaten.idKab[position].toString();				
	        ArrayAdapter<String> dataAdapObj = new ArrayAdapter<String>(planActivity,android.R.layout.simple_spinner_item, obj);
	        dataAdapObj.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	        spinObj.setAdapter(dataAdapObj);					 
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
		}
    }
    
    public void loopPilih(){

    	loop++;
		AlertDialog.Builder builder = new AlertDialog.Builder(this);

		LinearLayout alertPilih = new LinearLayout(this);  
		alertPilih.setOrientation(LinearLayout.VERTICAL);  
				
		//spinner Pilih Provinsi 		
		spinProv = new Spinner(this);
		alertPilih.addView(spinProv);		
		prov = dbProvinsi.getAllProv();
        ArrayAdapter<String> dataAdapterProv = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, prov);
        dataAdapterProv.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinProv.setAdapter(dataAdapterProv);		        
        spinProv.setOnItemSelectedListener(new provinsiClickListene(this));
	  
		//spinner Pilih Kabupaten
        spinKab = new Spinner(this);          
		alertPilih.addView(spinKab);
        kab = dbKabupaten.getAllKabById(idProvinsi);
        ArrayAdapter<String> dataAdapterKab = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, kab);
        dataAdapterKab.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinKab.setAdapter(dataAdapterKab);    
        spinKab.setOnItemSelectedListener(new kabupatenClickListene(this));
	  
		//spinner Objek Wisata
        spinObj = new Spinner(this); 
		alertPilih.addView(spinObj);
        obj = dbObjWisata.getAllObjById(idKabupaten);
        ArrayAdapter<String> dataAdapObj = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, obj);
        dataAdapObj.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinObj.setAdapter(dataAdapObj);
		
        spinObj.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int position, long arg3) {

				Log.d("ID Objek", DB_ObjWisata.idObjek[position].toString());
				idObj = Integer.valueOf(DB_ObjWisata.idObjek[position].toString());	
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
				  
		        
		builder.setTitle("Pilih Objek Wisata").setView(alertPilih).setCancelable(false);
		builder.setPositiveButton("Simpan", new DialogInterface.OnClickListener() {  
			@Override  
			public void onClick(DialogInterface dialog, int which) {     					    				
				if (dbDestinasi != null){
					dbDestinasi.createPilihan(idObj, Integer.valueOf(dataSource.getIdTerakhir()));
				}								

				int dest = Integer.valueOf(edJmldest.getText().toString());
				if (loop < dest){
					loopPilih();
				} else {
					edNama.setText("");
					edTanggal.setText("");
					edWaktu.setText("");
					edJmldest.setText("");
					eSpinner.setSelection(0);
					loop = 0;
				}

			}
		});

		final AlertDialog dialog = builder.create();
		dialog.show();
	}
    
    public void validasi(){
    	if (edNama.length() == 0){
    		
    		validasiForm(edNama);
    		
    	} else if (edTanggal.length() == 0){
    		
    		validasiForm(edTanggal);
    		Toast.makeText(this, "Mohon isikan Tanggal Keberangkatan", Toast.LENGTH_SHORT).show();
    		
    	} else if (edWaktu.length() ==0 ){
    		
    		validasiForm(edWaktu);
    		Toast.makeText(this, "Mohon isikan Waktu Keberangkatan", Toast.LENGTH_SHORT).show();
    		
    	} else if (edJmldest.length() == 0 || edJmldest.getText().equals("") || edJmldest.length()<0 ){
    		
    		validasiForm(edJmldest);    		
    		
    	} else if (eSpinner.getSelectedItemPosition() == 0){
    		
    		Toast.makeText(this, "Mohon pilih kendaraan dahulu", Toast.LENGTH_SHORT).show();	
    		
    	} 
    }

    @Override
    public void onClick(View v) {
		
    	String nama = null;
		String jml_dest = null;
		String tgl_trip = null;
		String waktu = null;
		int jenis = 0;

		Model_Planning plan = null;
		
		switch(v.getId())
		{
			case R.id.buttom_submit:

			validasi();
		    	
			if(edNama.getText()==null && edTanggal.getText()==null && edWaktu.getText()==null && edJmldest.getText()==null && eSpinner.getSelectedItemPosition()==0)
			{
				Toast.makeText(this, "Maaf tidak bisa simpan data planning", Toast.LENGTH_SHORT).show();
				
			} else if(edNama.getText()!=null && edTanggal.getText()!=null && edWaktu.getText()!=null && edJmldest.getText()!=null && eSpinner.getSelectedItemPosition()!=0)
			{
				
				nama = edNama.getText().toString();
				tgl_trip = edTanggal.getText().toString();
				waktu = edWaktu.getText().toString();
				jml_dest = edJmldest.getText().toString();
				jenis = eSpinner.getSelectedItemPosition();
				plan = dataSource.createPlan(nama, waktu, tgl_trip, jml_dest, jenis); //simpan ke tabel planning
				
				Toast.makeText(this, "Berhasil simpan planning ''" + plan.getNama_trip() + "''", Toast.LENGTH_LONG).show();
  				loopPilih();
				
			}
			
			break;
		} 
	}  
	
    @Override
    protected Dialog onCreateDialog(int id)
    {
        switch (id) {
            case TIME_DIALOG_ID:
                return new TimePickerDialog(
                    this, mTimeSetListener, hour, minute, true);
            case DATE_DIALOG_ID:
                return new DatePickerDialog(
                    this, mDateSetListener, mYear, mMonth, mDay);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener mDateSetListener =
        new DatePickerDialog.OnDateSetListener()
        {

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			String sdate = LPad(mDay + "", "0", 2) + " " + arrMonth[mMonth] + " " + mYear;
			edTanggal.setText(sdate);
		}
	};

    private TimePickerDialog.OnTimeSetListener mTimeSetListener =
    new TimePickerDialog.OnTimeSetListener()
    {
        public void onTimeSet(TimePicker view, int hourOfDay, int minuteOfHour)
        {
            hour = hourOfDay;
            minute = minuteOfHour;
            String stime = LPad(""+hour, "0", 2) + ":"+ LPad(""+minute, "0", 2);
            edWaktu.setText(stime);
        }
    };

	private static String LPad(String schar, String spad, int len) {
		String sret = schar;
		for (int i = sret.length(); i < len; i++) {
			sret = spad + sret;
		}
		return new String(sret);
	}
	
	

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.activity_main_action, menu);
// 
//        return super.onCreateOptionsMenu(menu);
//    }

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long arg3) {
		
		String item = parent.getItemAtPosition(position).toString();
        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
        eSpinner.setOnItemSelectedListener(this);
 
		
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void onDestroy() {
		dataSource.close();
		dbProvinsi.close();
		dbKabupaten.close();
		dbObjWisata.close();
		super.onDestroy();
	}
	

    @Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}


}