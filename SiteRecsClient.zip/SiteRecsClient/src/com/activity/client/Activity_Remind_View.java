package com.activity.client;
 
import java.sql.Time;
import java.text.DateFormat;
import java.util.List;

import com.database.DBHelper;
import com.database.DB_Planning;
import com.database.DB_Reminder;
import com.database.Model_Planning;
import com.database.Model_Reminder;
import com.Client.R;
import com.Client.R.drawable;

import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
 
public class Activity_Remind_View extends ListActivity implements OnItemClickListener, Notifier {

	Activity_Remind_View detailPlan;
	private DB_Planning db;
	private List<Model_Planning> data;
	private LazyAdapter adapter;
	Button buttonMake;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.data_view_btn_none);                
          
          db = new DB_Planning(this);
          db.openRead();
          ListView listView = (ListView) findViewById(android.R.id.list);
          adapter = new LazyAdapter(this);
          listView.setAdapter(adapter);
          listView.setOnItemClickListener(this);
          notifyDataSetChanged();
  		
//          buttonMake = (Button) findViewById(R.id.buttom_make);
//          buttonMake.setOnClickListener(new View.OnClickListener() {        	          	  
//              public void onClick(View v) {
//            	  startActivity(new Intent(Activity_Remind_View.this, Activity_Plan_Create.class));
//              }
//          });               
    }
        
    @Override
	public void onItemClick(AdapterView<?> arg0, View v, int pos, long arg3) {
	}
	
	@Override
	protected void onDestroy() {
		db.close();
		super.onDestroy();
	}

	public class LazyAdapter extends BaseAdapter {

		protected LayoutInflater inflater;

		public LazyAdapter(Context context) {
			inflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return data == null ? 0 : data.size();
		}

		@Override
		public Object getItem(int pos) {
			return pos;
		}

		@Override
		public long getItemId(int pos) {
			return pos;
		}

		@Override
		public View getView(int pos, View v, ViewGroup group) {
			
			if (v == null)
				v = inflater.inflate(R.layout.list_reminder, null);
			TextView tentang = (TextView) v.findViewById(R.id.remTentang);
			TextView tanggal = (TextView) v.findViewById(R.id.remTgl);
			TextView waktu = (TextView) v.findViewById(R.id.remWaktu);
			
			int alarm = 2;
			Model_Planning plan = data.get(pos);
			tentang.setText(plan.getNama_trip());
			tanggal.setText(plan.getTglplan());
			waktu.setText(plan.getWktPerjalanan()+" WIB");
			
			//if (kendaraan.getText());			
			
			return v;
		}
	}

	@Override
	public void notifyDataSetChanged() {
		data = db.getAllPlanning();
		adapter.notifyDataSetChanged();
	}

}