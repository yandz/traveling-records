package com.activity.client;

import com.Client.R;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
 
 
@SuppressLint("ShowToast")
public class Activity_Menu_List extends ListActivity {

	@Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_menu_list);
     
        Button listAlamat = (Button) findViewById(R.id.btnAlamat);
        listAlamat.setOnClickListener(new View.OnClickListener() {        	          	  
            public void onClick(View v) {
            	startActivity(new Intent(Activity_Menu_List.this, Activity_Destinasi_List.class));
            }
        });
        

        Button btnLokasi = (Button) findViewById(R.id.btnLokasi);
        btnLokasi.setOnClickListener(new View.OnClickListener() {        	          	  
            public void onClick(View v) {
          	  startActivity(new Intent(Activity_Menu_List.this, Activity_Lokasi_History.class));
            }
        });
        
        Button btnPhoto = (Button) findViewById(R.id.btnPhoto);
        btnPhoto.setOnClickListener(new View.OnClickListener() {        	          	  
            public void onClick(View v) {
          	  startActivity(new Intent(Activity_Menu_List.this, Activity_Gambar_List.class));
          	}
        });
        
//        Button listPhoto = (Button) findViewById(R.id.listPhoto);
//        listPhoto.setOnClickListener(new View.OnClickListener() {        	          	  
//            public void onClick(View v) {
//            	startActivity(new Intent(Activity_Menu_List.this, Activity_Gambar_Create.class));
//            }
//        });

        Button btnArtikel = (Button) findViewById(R.id.btnArtikel);
        btnArtikel.setOnClickListener(new View.OnClickListener() {        	          	  
            public void onClick(View v) {
            	startActivity(new Intent(Activity_Menu_List.this, Activity_Artikel_List.class));
            }
        });
        
//        Button listArtikel = (Button) findViewById(R.id.listArtikel);
//        listArtikel.setOnClickListener(new View.OnClickListener() {        	          	  
//            public void onClick(View v) {
//            	startActivity(new Intent(Activity_Menu_List.this, Activity_Artikel_Create.class));
//            }
//        });

        Button btnPengaturan = (Button) findViewById(R.id.btnPengaturan);
        btnPengaturan.setOnClickListener(new View.OnClickListener() {        	          	  
            public void onClick(View v) {
            	startActivity(new Intent(Activity_Menu_List.this, Help.class));
            }
        });
         
    }
	
}