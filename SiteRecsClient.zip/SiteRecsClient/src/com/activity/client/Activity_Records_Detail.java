package com.activity.client;

import java.util.ArrayList;
import java.util.List;

import com.database.DBHelper;
import com.database.DB_Artikel;
import com.database.DB_Destinasi;
import com.database.DB_ObjWisata;
import com.database.DB_Photos;
import com.database.DB_Planning;
import com.database.DB_Tracks;
import com.database.Model_Artikel;
import com.database.Model_ObjWisata;
import com.database.Model_Photos;
import com.database.Model_Planning;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.Client.R;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
 
public class Activity_Records_Detail extends FragmentActivity {
	 // Google Map
    private GoogleMap googleMap;
    
    public static double latitude;
    public static double longitude;

    private DB_Planning dbPlan;
    private DB_Tracks dbTracks;
    private DB_Artikel dbArtikel;
    private DB_Photos dbPhoto;

    private List<Model_Artikel> dataArtikel;
    private List<Model_Photos> dataPhoto;
    
    public ArrayList<LatLng> arrayPoints = null;
    
    static int idPlanToPlay;
    static double camLat;
    static double camLong;
    static double desCamLat;
    static double desCamLong;   
    
    String nm_plan, des_plan, waktu, tanggal, kendaraan;
    private TextView vNama, vDestinasi, vWaktu, vTanggal, vKendaraan;
    private ImageView vImgKendaraan;
    
    static String namaMarkerArtikel;
    static String namaMarkerPhoto;
    static int idMarkerArtikel;
    Marker markerArtikel;
    Marker markerPhoto;
    Marker markerDestinasi;
    
    SQLiteDatabase mDatabase;
    DBHelper mDbHelper ;
    ArrayList<PinMarker> mPinMarkerList;
    ArrayList<PolyRecords> mPolyRecordsList;
    ArrayList<MarkerArtikel> mPinArtikelList;
    ArrayList<MarkerPhoto> mPinPhotoList;
    ArrayList<PinStartRecords> mPinStartRecordsList;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_records_detail);
        ActionBar actionBar = getActionBar(); 
        actionBar.setDisplayHomeAsUpEnabled(true);    
        
        vNama = (TextView) findViewById(R.id.detNameMarker);
        vWaktu = (TextView) findViewById(R.id.detLatMarker);
        vTanggal = (TextView) findViewById(R.id.detLongMarker);
        vKendaraan = (TextView) findViewById(R.id.detDesMarker);
        vImgKendaraan = (ImageView) findViewById(R.id.detImageMarker);
        
        arrayPoints = new ArrayList<LatLng>();
        
        dbTracks = new DB_Tracks(this); dbTracks.openWrite(); dbTracks.openRead();
        dbArtikel = new DB_Artikel(this); dbArtikel.openRead(); dbArtikel.openRead();
        dbPhoto = new DB_Photos(this); dbPhoto.openRead(); dbPhoto.openRead();
        dbPlan = new DB_Planning(this); dbPlan.openRead(); dbPlan.openRead();
        
		dataArtikel = dbArtikel.getAllArtikel();
		dataPhoto = dbPhoto.getAllPhoto();
        
        mDbHelper = new DBHelper(this);

        try { 
        	initilizeMap();
        	setDataPlan();
        	setPinStartRecordsOnMap();
        	setPinDestinasiOnMap();
        	setMarkerArtikel();
        	setMarkerPhoto();
        	setPolyRecordsOnMap();
			
			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); //Tipe Maps
			googleMap.setMyLocationEnabled(false); //Arahkan Lokasi Saya Saat ini
			googleMap.getUiSettings().setZoomControlsEnabled(true); //Menampilkan button - +
			googleMap.getUiSettings().setMyLocationButtonEnabled(true); //Menampilkan button lokasi saya
			googleMap.getUiSettings().setCompassEnabled(true); //Menampilkan Icon Compass
			googleMap.getUiSettings().setRotateGesturesEnabled(true); //Lihat Rotate Gesture
			googleMap.getUiSettings().setZoomGesturesEnabled(true); //zooming gesture
			googleMap.getUiSettings().setMapToolbarEnabled(true); //maps toolbars
			
			LatLng posisi = new LatLng(camLat, camLong);
			googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(posisi, 14));			

			googleMap.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
				
				@Override
				public void onInfoWindowClick(Marker marker) {
					
		            LatLng latLon = marker.getPosition();
					
		            for (int i = 0; i < dataArtikel.size(); i++) {
						Model_Artikel artikel = dataArtikel.get(i);
						LatLng mCoordinates;
			    	    mCoordinates = new LatLng(artikel.getLatitude(), artikel.getLongitude());
						if (latLon.equals(mCoordinates)){

		    				idMarkerArtikel = artikel.getId();
		    				
		    	            Context context = Activity_Records_Detail.this;
		    	            new Activity_Artikel_Detail(context).showArtikel(Integer.valueOf(artikel.getId()));		
		    	            
		    	            
						} 
					}
		            
		            for (int i = 0; i < dataPhoto.size(); i++) {
						Model_Photos photo = dataPhoto.get(i);
						LatLng mCoordinates;
			    	    mCoordinates = new LatLng(photo.getLat(), photo.getLong());
						if (latLon.equals(mCoordinates)){

		    				namaMarkerPhoto = photo.getNama();
		    				
		    	            Context context = Activity_Records_Detail.this;
		    	            new Activity_Gambar_Detail(context).showPhoto();		
						} 
					}
					
//	    			if (marker.equals(markerArtikel)) {
//	    				
//	    				namaMarkerArtikel = markerArtikel.getTitle();
//	    				
//	    	            Context context = Activity_Records_Detail.this;
//	    	            new Activity_Artikel_Detail(context).showArtikel();			    	    		    	            
//	    	            	
//	    			} else if (marker.equals(markerPhoto)){
//
//	    				namaMarkerPhoto = markerPhoto.getTitle();
//	    				
//	    				Context context = Activity_Records_Detail.this;
//	    				new Activity_Gambar_Detail(context).showPhoto();
//    	    		
//	    			} else if (marker.equals(markerDestinasi)){
//	    				
//	    				Log.d("Destinasi", "ini idnya "+markerDestinasi.getId());
//	    				
//	    			} else
//	    			
//	    				Toast.makeText(getApplicationContext(),"Sorry, ada kesalahan\n"+marker.getTitle(), Toast.LENGTH_SHORT).show();
    				
				}
			});


      } catch (Exception e) {
         e.printStackTrace();
      }

    }
    
    /*==================================================== Metode Inisialisasi Google Maps ===================================================== */
    private void initilizeMap() {
    	
    	if (googleMap == null) {
			googleMap = ((MapFragment) getFragmentManager()
					.findFragmentById(R.id.mapPlayRecords)).getMap();

			// check if map is created successfully or not
			if (googleMap == null) {
				Toast.makeText(getApplicationContext(),
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			}
		}
	}  
    
    /*==================================================== Local Class Detail ARTIKEL ===================================================== */
    public class Activity_Artikel_Detail extends AlertDialog.Builder implements OnClickListener, OnCancelListener{
    	private Context ctx;
    	private DB_Planning db;

    	private DB_Artikel dbArtikel;
    	
    	private Model_Artikel artikel;
    	private View v;
    	private TextView vId;
    	private TextView vWaktu;
    	private TextView vTgl;
    	private EditText vJudul;
    	private EditText vDeskripsi;
    	private TextView vLatitude;
    	private TextView vLongitude;
        DBHelper mDbHelper ;
        private SQLiteDatabase database;
    	
    	@SuppressLint("InflateParams")
		public Activity_Artikel_Detail(Context context) {		
    		super(context);
    		ctx = context;
    		db = new DB_Planning(context);			db.openWrite(); db.openRead();
    		dbArtikel = new DB_Artikel(context);	dbArtikel.openWrite(); dbArtikel.openRead();
    		
    		v = LayoutInflater.from(context).inflate(R.layout.data_artikel_detail, null);
    		vId = (TextView) v.findViewById(R.id.detArtikelId);
    		vWaktu = (TextView) v.findViewById(R.id.detArtikelWaktu);
    		vTgl = (TextView) v.findViewById(R.id.detArtikelTanggal);
    		vJudul = (EditText) v.findViewById(R.id.detArtikelJudul);
    		vDeskripsi = (EditText) v.findViewById(R.id.detArtikelDeskripsi);
    		vLatitude = (TextView) v.findViewById(R.id.detArtikellat);
    		vLongitude = (TextView) v.findViewById(R.id.detArtikellong);
    		setView(v);
    		setOnCancelListener(this);	
    	}
    	
        public AlertDialog showArtikel(int id){
        	
	        Model_Artikel artikel = dbArtikel.getDetail(id);
	        
    		vId.setText(String.valueOf(artikel.getId()));
    		vWaktu.setText(artikel.getWaktu());
    		vTgl.setText(artikel.getTanggal());
    		vJudul.setText(artikel.getJudul());
    		vDeskripsi.setText(artikel.getDeskripsi());
    		vLatitude.setText(String.valueOf(artikel.getLatitude()));
    		vLongitude.setText(String.valueOf(artikel.getLongitude()));
    		setTitle(artikel.getJudul());
    		setPositiveButton("Edit", this);
    		setNegativeButton("Hapus", this);
    		return super.show();
	        
        }	
        
//    	public AlertDialog show(Model_Artikel artikel) {
//    		
//    		this.artikel = artikel;
//    		
//    		vId.setText(String.valueOf(artikel.getId()));
//    		vWaktu.setText(artikel.getWaktu());
//    		vTgl.setText(artikel.getTanggal());
//    		vJudul.setText(artikel.getJudul());
//    		vDeskripsi.setText(artikel.getDeskripsi());
//    		vLatitude.setText(String.valueOf(artikel.getLatitude()));
//    		vLongitude.setText(String.valueOf(artikel.getLongitude()));
//    		setTitle(artikel.getJudul());
//    		setPositiveButton("Edit", this);
//    		setNegativeButton("Hapus", this);
//    		return super.show();
//    	}

    	@Override
    	public void onClick(DialogInterface dialog, int which) {
    		
    		switch (which) {
    				case DialogInterface.BUTTON_NEGATIVE:
    					dbArtikel.deleteArtikel(vId.getText().toString());  
    					dbArtikel.close();

    	                googleMap.clear();
    	                onRefreshMaps();
    				break;
    				case DialogInterface.BUTTON_POSITIVE:
//    			        Model_Artikel artikel = dbArtikel.getDetail(idMarkerArtikel);
//    					artikel.setWaktu(vWaktu.getText().toString());
//    					artikel.setTanggal(vTgl.getText().toString());
//    					artikel.setJudul(vJudul.getText().toString());
//    					artikel.setDeskripsi(vDeskripsi.getText().toString());
//    					artikel.setLangit(Double.valueOf(vLatitude.getText().toString()));
//    					artikel.setLangit(Double.valueOf(vLongitude.getText().toString()));
//    					dbArtikel.updateArtikel(artikel, vId.getText().toString());
//    	                dbArtikel.close();
//    	        		((Notifier) ctx).notifyDataSetChanged();
    					Toast.makeText(getApplicationContext(), "Artikel Update", Toast.LENGTH_SHORT).show();
    	                googleMap.clear();
    	                onRefreshMaps();

    				break;
    		}
    	}
    	
    	@Override
    	public void onCancel(DialogInterface dialog) {
    		db.close();
//    		((Notifier) ctx).notifyDataSetChanged();
    		
    	}


    }
    
    /*==================================================== Local Class Detail PHOTO ===================================================== */
    public class Activity_Gambar_Detail extends AlertDialog.Builder implements OnClickListener, OnCancelListener{
    	private Context ctx;
    	private DB_Planning db;

    	private DB_Photos dbPhoto;
    	
    	private Model_Photos photo;
    	private View v;
    	private TextView vId;
    	private TextView vWaktu;
    	private TextView vTgl;
    	private EditText vJudul;
    	private EditText vDeskripsi;
    	private TextView vUrl;
    	private TextView vLatitude;
    	private TextView vLongitude;
    	private ImageView vImage;
    	private boolean zoomOut =  false;
    	
    	@SuppressLint("InflateParams")
		public Activity_Gambar_Detail(Context context) {		
    		super(context);
    		ctx = context;
    		db = new DB_Planning(context);			db.openWrite(); db.openRead();
    		dbPhoto = new DB_Photos(context);	dbPhoto.openWrite(); dbPhoto.openRead();

    		v = LayoutInflater.from(context).inflate(R.layout.data_gambar_detail, null);
    		vId = (TextView) v.findViewById(R.id.detGbrId);
    		vWaktu = (TextView) v.findViewById(R.id.detGbrWkt);
    		vTgl = (TextView) v.findViewById(R.id.detGbrTgl);
    		vJudul = (EditText) v.findViewById(R.id.detGbrJudul);
    		vDeskripsi = (EditText) v.findViewById(R.id.detGbrDesk);
    		vUrl = (TextView) v.findViewById(R.id.detGbrUrl);
    		vLatitude = (TextView) v.findViewById(R.id.detGbrLat);
    		vLongitude = (TextView) v.findViewById(R.id.detGbrLong);
    		vImage = (ImageView) v.findViewById(R.id.detGbrImg);
    		
    		setView(v);
    		setOnCancelListener(this);	
    		
    		vImage.setOnClickListener(new View.OnClickListener() {
 	            @Override
 	            public void onClick(View v) {
// 	            	if(zoomOut) {
// 	            		 Toast.makeText(getApplicationContext(), "NORMAL SIZE!", Toast.LENGTH_LONG).show();
// 	            		 vImage.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
// 	            		 vImage.setAdjustViewBounds(true);
// 	            		 zoomOut =false;
// 	            	}else{
// 	            		Toast.makeText(getApplicationContext(), "FULLSCREEN!", Toast.LENGTH_LONG).show();
// 	            		vImage.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
// 	            		vImage.setScaleType(ImageView.ScaleType.FIT_XY);
// 	            		zoomOut = true;
// 	            	}
 	            	
 	            	Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.parse("file://"+String.valueOf(vUrl.getText())), "image/*");
                    startActivity(intent);
 	            	
 	            	
 	            }
 	        });
    	}
    	
        public AlertDialog showPhoto(){
        	
	        Model_Photos photo = dbPhoto.getPhotoByName(namaMarkerPhoto);
	        
	        vId.setText(String.valueOf(photo.getId()));
    		vWaktu.setText(photo.getWaktu());
    		vTgl.setText(photo.getTanggal());
    		vJudul.setText(photo.getNama());
    		vDeskripsi.setText(photo.getDeskripsi());
    		vUrl.setText(photo.getUrl());
    		vLatitude.setText(String.valueOf(photo.getLat()));
    		vLongitude.setText(String.valueOf(photo.getLong()));
    		
    		Bitmap bitmap  = BitmapFactory.decodeFile(photo.getUrl());
    		vImage.setImageBitmap(bitmap);
    		
    		
        
    		setTitle(photo.getNama());
    		setPositiveButton("Edit", this);
    		setNegativeButton("Hapus", this);
    		return super.show();
        }	

    	public AlertDialog show(Model_Photos photo) {
    		
    		this.photo = photo;
    		
//    		vId.setText(String.valueOf(photo.getId()));
//    		vWaktu.setText(photo.getWaktu());
//    		vTgl.setText(photo.getTanggal());
//    		vJudul.setText(photo.getNama());
//    		vDeskripsi.setText(photo.getDeskripsi());
//    		vUrl.setText(photo.getUrl());
//    		vLatitude.setText(String.valueOf(photo.getLat()));
//    		vLongitude.setText(String.valueOf(photo.getLong()));
//    		
//    		Bitmap bitmap  = BitmapFactory.decodeFile(photo.getUrl());
//    		vImage.setImageBitmap(bitmap);
//    		
//    		setTitle(photo.getNama());
    		setPositiveButton("Edit", this);
    		setNegativeButton("Hapus", this);
    		return super.show();
    	}
    	
    	@Override
    	public void onClick(DialogInterface dialog, int which) {
    		
    		switch (which) {
    				case DialogInterface.BUTTON_NEGATIVE:
    					vWaktu = (TextView) v.findViewById(R.id.itemWaktu);
    					dbPhoto.deletePhoto(vId.getText().toString());  
    					dbPhoto.close();
    					
    	                googleMap.clear();
    	                onRefreshMaps();
    				break;
    				case DialogInterface.BUTTON_POSITIVE:
    					
    					Model_Photos photo = dbPhoto.getPhotoByName(namaMarkerPhoto);
    					photo.setWaktu(vWaktu.getText().toString());
    					photo.setTanggal(vTgl.getText().toString());
    					photo.setNama(vJudul.getText().toString());
    					photo.setDeskripsi(vDeskripsi.getText().toString());
    					photo.setUrl(vUrl.getText().toString());
    					photo.setLat(Double.valueOf(vLatitude.getText().toString()));
    					photo.setLong(Double.valueOf(vLongitude.getText().toString()));
    					dbPhoto.updatePhoto(photo, vId.getText().toString());
    	                dbPhoto.close();
    	
    	                googleMap.clear();
    	                onRefreshMaps();
    	                
    	            break;
    		}
    	}
    	
    	@Override
    	public void onCancel(DialogInterface dialog) {
    		db.close();
//    		((Notifier) ctx).notifyDataSetChanged();	
    	}
    }
    
    
    /*==================================================== DATA PLANNING ===================================================== */
    
	public Cursor getDataPlanning(int id)
    {		
  		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
  		String selectQuery = 
  				"SELECT * FROM "+ DB_Planning.TABLE_PLANNING+
  				" WHERE id_plan = "+ id;
  		Log.e("LOG Query", selectQuery);
  		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	
            }        
        }
  		db.close();
        return cursor;   
    }
	
	public void setDataPlan(){
		Cursor planCursor = getDataPlanning(idPlanToPlay);
		if (planCursor != null && planCursor.moveToFirst()){
			do {
            	
            	nm_plan = planCursor.getString(1);
            	waktu = planCursor.getString(2);
            	tanggal = planCursor.getString(3);
            	kendaraan = planCursor.getString(5);
				
            	vNama.setText(nm_plan);
            	vWaktu.setText(waktu);
            	vTanggal.setText(tanggal);
            	
            	if (kendaraan.equals("1")) {
    		    	vImgKendaraan.setImageDrawable(getResources().getDrawable(R.drawable.ico_walk));
    		    	vKendaraan.setText("Jalan Kaki");
    		    } else if (kendaraan.equals("2")) {
    		    	vImgKendaraan.setImageDrawable(getResources().getDrawable(R.drawable.ico_bicycle));
    		    	vKendaraan.setText("Sepeda");
    		    } else if (kendaraan.equals("3")) {
    		    	vImgKendaraan.setImageDrawable(getResources().getDrawable(R.drawable.ico_moto));
    		    	vKendaraan.setText("Sepeda Motor");
    		    } else if (kendaraan.equals("4")) {
    		    	vImgKendaraan.setImageDrawable(getResources().getDrawable(R.drawable.ico_car));
    		    	vKendaraan.setText("Mobil");
    		    } else if (kendaraan.equals("5")) {
    		    	vImgKendaraan.setImageDrawable(getResources().getDrawable(R.drawable.ico_bus));
    		    	vKendaraan.setText("Bus");
    		    }
            	
			} while (planCursor.moveToNext());
			planCursor.close();
		}
	}
//    public void setPinStartRecordsOnMap(){
//        Cursor pinRecordCursor = getPinStartRecords(idPlanToPlay);
//        mPinStartRecordsList = new ArrayList<PinStartRecords>();
//        if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
//        {
//            do
//            {//String testName, String testType, String latitude, String longitude
//                PinStartRecords markers = new PinStartRecords(pinRecordCursor.getString(1),pinRecordCursor.getString(2));
//                mPinStartRecordsList.add(markers);
//                googleMap.addMarker(markers.getMarkerOption());
//                camLat = pinRecordCursor.getDouble(1);
//                camLong = pinRecordCursor.getDouble(2);
//            } while (pinRecordCursor.moveToNext());
//            pinRecordCursor.close();
//        }
//    }		
    
    
    /*==================================================== PIN START RECORDS ===================================================== */
    public class PinStartRecords {
    	private LatLng mCoordinates = null;
    	private MarkerOptions mRecordsPinOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;
    	
    	
    	public PinStartRecords(String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mRecordsPinOptions = new MarkerOptions();
    	    mRecordsPinOptions.position(mCoordinates);
    	    mRecordsPinOptions.title("Awal");
//    	    mRecordsPinOptions.snippet(latitude+" , "+longitude);
    	    mRecordsPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_start));
//    	    mRecordsPinOptions.icon(BitmapDescriptorFactory.defaultMarker());
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mRecordsPinOptions;
    	}
    }
    
	public Cursor getPinStartRecords(int id)
    {		
  		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
  		String selectQuery = 
  				"SELECT MIN(TR.id_plan), TR.latitude, TR.Longitude FROM "+ DB_Planning.TABLE_PLANNING+ " PL, "+ DB_Tracks.TABLE_TRACKS +" TR " +
  				"WHERE PL.`id_plan` = TR.`id_plan` AND PL.id_plan = "+ id;
  		Log.e("LOG Query", selectQuery);
  		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            }        
        }
  		db.close();
        return cursor;   
    }
	
    public void setPinStartRecordsOnMap(){
        Cursor pinRecordCursor = getPinStartRecords(idPlanToPlay);
        mPinStartRecordsList = new ArrayList<PinStartRecords>();
        if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
        {
            do
            {//String testName, String testType, String latitude, String longitude
                PinStartRecords markers = new PinStartRecords(pinRecordCursor.getString(1),pinRecordCursor.getString(2));
                mPinStartRecordsList.add(markers);
                googleMap.addMarker(markers.getMarkerOption()).showInfoWindow();
                camLat = pinRecordCursor.getDouble(1);
                camLong = pinRecordCursor.getDouble(2);
            } while (pinRecordCursor.moveToNext());
            pinRecordCursor.close();
        }
    }		
    
    
/*==================================================== PIN MARKER DESTINASI ===================================================== */ 
    public class PinMarker {

    	private LatLng mCoordinates = null;
    	private MarkerOptions mTestPinOptions=null;
    	public Double mLatitude;
    	public Double mLongitude;

    	public PinMarker(String testName, String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mTestPinOptions = new MarkerOptions();
    	    mTestPinOptions.position(mCoordinates);
    	    mTestPinOptions.title(testName);
    	    mTestPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_destinasi));
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mTestPinOptions;
    	}
    }
    
	public Cursor getPinFromDatabase(int id)
    {		
		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
		String selectQuery = 
				 "SELECT * "
				+"FROM "+ DB_Planning.TABLE_PLANNING +" PL, "+ DB_ObjWisata.TABLE_OBJEK +" OB, "+ DB_Destinasi.TABLE_DESTINASI +" DS "
				+"WHERE PL.id_plan = DS.id_plan AND OB.id_obj = DS.id_obj AND PL.id_plan = "+ id;
		Cursor cursor = db.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            	Log.d("Destinasinya", cursor.getString(7).toString()+" "+cursor.getString(9).toString()+" "+cursor.getString(10).toString());
        	}        
        }
		db.close();
        return cursor;   
    }
	
    public void setPinDestinasiOnMap(){
        Cursor pinRecordCursor = getPinFromDatabase(idPlanToPlay);
        mPinMarkerList = new ArrayList<PinMarker>();
        if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
        {
            do
            {//String testName, String testType, String latitude, String longitude
                PinMarker markers = new PinMarker(pinRecordCursor.getString(7),pinRecordCursor.getString(9),pinRecordCursor.getString(10));
                mPinMarkerList.add(markers);
                
                markerDestinasi = googleMap.addMarker(markers.getMarkerOption());            
                
                desCamLat = pinRecordCursor.getDouble(9);
                desCamLong = pinRecordCursor.getDouble(10);
            } while (pinRecordCursor.moveToNext());
            pinRecordCursor.close();
        }
    }

    /*==================================================== POLYLINE RECORDS ===================================================== */
    public class PolyRecords {
    	private LatLng mCoordinates = null;
    	private PolylineOptions mRecordsPolyOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;
    	
    	public PolyRecords(String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);    	    
    	    mRecordsPolyOptions = new PolylineOptions();
    	    arrayPoints.add(mCoordinates);
    	    mRecordsPolyOptions.addAll(arrayPoints);
    	    mRecordsPolyOptions.width(6);
    	    mRecordsPolyOptions.color(Color.RED);
    	}
    	public PolylineOptions getPolyOption()
    	{
    	    return mRecordsPolyOptions;
    	}
    }
    
	public Cursor getPolyRecords(int id)
    {		
  		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
  		String selectQuery = 
  				"SELECT * FROM "+ DB_Planning.TABLE_PLANNING+ " PL, "+ DB_Tracks.TABLE_TRACKS +" TR " +
  				"WHERE PL.`id_plan` = TR.`id_plan` AND PL.id_plan = "+ id;
  		Log.e("LOG", selectQuery);
  		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            }        
        }
  		db.close();
        return cursor;   
    }
	
    public void setPolyRecordsOnMap(){
        Cursor pinRecordCursor = getPolyRecords(idPlanToPlay);
        if(pinRecordCursor != null && pinRecordCursor.moveToFirst())
        {
            do
            {//String testName, String testType, String latitude, String longitude
                PolyRecords polyline = new PolyRecords(pinRecordCursor.getString(7),pinRecordCursor.getString(8));
                googleMap.addPolyline(polyline.getPolyOption());
            } while (pinRecordCursor.moveToNext());
            pinRecordCursor.close();
        }
        	
    }
    
    
    /*==================================================== MARKER EVENT ARTIKEL ===================================================== */
    public class MarkerArtikel {
    	private LatLng mCoordinates = null;
    	private MarkerOptions mArtikelPinOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;

    	public MarkerArtikel(String Name, String Jam, String Deskripsi, String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mArtikelPinOptions = new MarkerOptions();
    	    mArtikelPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_artikel));
    	    mArtikelPinOptions.position(mCoordinates);
    	    mArtikelPinOptions.title(Name);
    	    mArtikelPinOptions.snippet(Jam + " | " + Deskripsi);
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mArtikelPinOptions;
    	}
    }
    
	public Cursor getArtikelFromDB(int id)
    {		
		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
		String selectQuery = 
				"SELECT * FROM "
			   + DB_Planning.TABLE_PLANNING +" PL, "+ DB_Tracks.TABLE_TRACKS +" TR, "+ DB_Artikel.TABLE_ARTIKEL +" AR "+
				"WHERE PL.`id_plan` = TR.`id_plan` AND AR.`id_tracks` = TR.`id_tracks` AND PL.id_plan = "+ id;
		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            }        
        }
  		db.close();
        return cursor; 
    }	
	
    public void setMarkerArtikel(){
            final Cursor pinArtikelCursor = getArtikelFromDB(idPlanToPlay);
            mPinArtikelList = new ArrayList<MarkerArtikel>();
            if(pinArtikelCursor != null && pinArtikelCursor.moveToFirst())
            {
                do
                {//String testName, String testType, String latitude, String longitude
                    MarkerArtikel markers = new MarkerArtikel(
                    		pinArtikelCursor.getString(13),
                    		pinArtikelCursor.getString(11),
                    		pinArtikelCursor.getString(14),
                    		pinArtikelCursor.getString(15),
                    		pinArtikelCursor.getString(16));
                    mPinArtikelList.add(markers);
                    
                    markerArtikel = googleMap.addMarker(markers.getMarkerOption()); 
                    
                } while (pinArtikelCursor.moveToNext());
                pinArtikelCursor.close();
            }
    }
    
    /*==================================================== MARKER EVENT PHOTO ===================================================== */
    public class MarkerPhoto {
    	private LatLng mCoordinates = null;
    	private MarkerOptions mPhotoPinOptions = null;
    	private Double mLatitude;
    	private Double mLongitude;
    	
    	//waktu(10), nama(12), desk(13), lat(15), LONG(16)
    	public MarkerPhoto(String Name, String Jam, String Deskripsi, String latitude, String longitude)
    	{
    	    mLatitude = Double.parseDouble(latitude);
    	    mLongitude = Double.parseDouble(longitude);
    	    mCoordinates = new LatLng(mLatitude, mLongitude);
    	    mPhotoPinOptions = new MarkerOptions();
    	    mPhotoPinOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker_photo));
    	    mPhotoPinOptions.position(mCoordinates);
    	    mPhotoPinOptions.title(Name);
    	    mPhotoPinOptions.snippet(Jam  + " | " + Deskripsi);
    	}
    	public MarkerOptions getMarkerOption()
    	{
    	    return mPhotoPinOptions;
    	}
    }
    
	public Cursor getPhotoFromDB(int id)
    {		
		Log.d("Masuk DB", "Hallo query");
		SQLiteDatabase db = this.mDbHelper.getReadableDatabase();
		String selectQuery = 
				"SELECT * FROM "
			   + DB_Planning.TABLE_PLANNING +" PL, "+ DB_Tracks.TABLE_TRACKS +" TR, "+ DB_Photos.TABLE_PHOTO +" PH "+
				"WHERE PL.`id_plan` = TR.`id_plan` AND PH.`id_tracks` = TR.`id_tracks` AND PL.id_plan = "+ id;
		Log.e("Que Photo", selectQuery);
		Cursor cursor = db.rawQuery(selectQuery, null);
  		if (cursor.moveToFirst()) {
        	for (int i = 0 ; i < cursor.getCount(); i++ ){
            	cursor.moveToPosition(i);
            }        
        }
  		db.close();
        return cursor; 
    }	
	
    public void setMarkerPhoto(){
            Cursor pinPhotoCursor = getPhotoFromDB(idPlanToPlay);
            mPinPhotoList = new ArrayList<MarkerPhoto>();
            if(pinPhotoCursor != null && pinPhotoCursor.moveToFirst())
            {
                do
                {//waktu(10), nama(12), desk(13), lat(15), LONG(16)
                    MarkerPhoto markers = new MarkerPhoto(
                    		pinPhotoCursor.getString(13),
                    		pinPhotoCursor.getString(11),
                    		pinPhotoCursor.getString(14),
                    		pinPhotoCursor.getString(16),
                    		pinPhotoCursor.getString(17));
                    mPinPhotoList.add(markers);
                    
                    markerPhoto = googleMap.addMarker(markers.getMarkerOption());
                    
                } while (pinPhotoCursor.moveToNext());
                pinPhotoCursor.close();
            } 
    }
    
    /*==================================================== Marker Event ===================================================== */  

    
    public class MyLocationListener implements LocationListener {
    	
    	@Override
    	public void onLocationChanged(Location location) {
    		
    	}

    	@Override
    	public void onProviderDisabled(String provider) {
    		Toast.makeText(getApplicationContext(),"GPS disabled", Toast.LENGTH_SHORT).show();
    	}
    	
    	@Override
    	public void onProviderEnabled(String provider) {
    		Toast.makeText(getApplicationContext(),"GPS enabled", Toast.LENGTH_SHORT).show();
    	}
    	
		@Override
		public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
			
		}
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case android.R.id.home:
            this.finish();
            return true;
        case android.R.id.icon1:
            Intent i = new Intent(Activity_Records_Detail.this, LocationFound.class);
            startActivity(i);
            return true;
        case R.id.action_help:
        	startActivity(new Intent(Activity_Records_Detail.this, Help.class));
            return true;
        case R.id.action_check_updates:
            // check for updates action
        	this.closeContextMenu();
            return true;
        default:
            return super.onOptionsItemSelected(item);
        }
    }
 
    private void onRefreshMaps() {
    	
    	initilizeMap();
    	setPinStartRecordsOnMap();
    	setPinDestinasiOnMap();
    	setMarkerArtikel();
    	setMarkerPhoto();
    	setPolyRecordsOnMap();		
	}
    
    @Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}
	

	@Override
	protected void onDestroy() {
		super.onDestroy();
		dbArtikel.close();
		dbPhoto.close();
		dbTracks.close();
	}

 
}